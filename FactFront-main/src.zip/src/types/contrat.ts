
import { EventConfig } from "./event-config";

export type ContractSatus = 'Active' | 'Disable';
export type CalculationModeType = 'Date' | 'Quantity' | 'DateByTEU' | 'Special';


export interface Contract {
    id: string,
    name: string,
    description: string,
    calculationMode: CalculationMode;
    status: ContractSatus,
    startDate: Date,
    endDate: Date  
}

export interface CalculationMode {
    type: CalculationModeType,
    subType: string,
    eventConfig: EventConfig,
    parameters: {
        gracePeriod: 0,
        minimumDays: 1
    }
}
