<script setup lang="ts">
import { ref, onMounted, onUnmounted, nextTick, watch } from 'vue';
import templateService from '../services/invoiceTemplateService';

/* ------- GrapesJS Studio SDK: robust import ------- */
import * as StudioMod from '@grapesjs/studio-sdk';
import '@grapesjs/studio-sdk/style';
const createStudio: any =
  (StudioMod as any).default ??
  (StudioMod as any).createStudioEditor ??
  (StudioMod as any); // fallback for different bundle shapes

interface FieldGroup { label: string; fields: { token: string; label: string }[]; }

const props = defineProps<{ id?: string }>();
const emit = defineEmits<{ (e: 'close'): void; (e: 'update:id', id: string): void }>();

const templateId = ref<string | undefined>(props.id);
const name = ref('');
const bindings = ref<Record<string, any>>({});
const pageSettings = ref({ size: 'A4', margins: 40 });

const isSaving = ref(false);
const isExporting = ref(false);
const errorMsg = ref<string | null>(null);
const specificInvoiceId = ref('');

/* Root element: id (optional) + ref (reliable) */
const studioRootId = 'studio-editor';
const studioRootRef = ref<HTMLElement | null>(null);

let studio: any = null;
let editor: any = null;

/* -----------------------------
   Utilities & data transforms
------------------------------*/
function transformInvoiceToGlobalData(raw: any) {
  const total = Number(raw?.TotalAmount ?? raw?.totalAmount ?? 0);
  const items = Array.isArray(raw?.items) ? raw.items
    : Array.isArray(raw?.lines)
      ? raw.lines.map((l: any, i: number) => ({
          position: i + 1,
          description: l?.description ?? l?.itemNumber ?? 'Line',
          qty: Number(l?.quantity ?? l?.qty ?? 1),
          price: Number(l?.unitPrice ?? l?.price ?? 0),
          amount: Number(l?.amount ?? (Number(l?.quantity ?? 1) * Number(l?.unitPrice ?? 0)))
        }))
      : [{
          position: 1, description: 'Service', qty: 1, price: total, amount: total
        }];

  return {
    invoice: {
      number: raw?.finalNumber || raw?.draftNumber || 'INV-XXXX',
      issueDate: raw?.createdDate || new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30*24*60*60*1000).toISOString().split('T')[0],
      status: raw?.status || 'DRAFT',
      customer: {
        name: raw?.customerName || raw?.customer?.name || 'Customer Name',
        address: raw?.customer?.address || 'Address',
        city: raw?.customer?.city || 'City',
        postalCode: raw?.customer?.postalCode || 'Postal Code',
        country: raw?.customer?.country || 'Country',
        email: raw?.customer?.email || 'email@example.com',
        phone: raw?.customer?.phone || '+33 X XX XX XX XX'
      },
      facility: raw?.facility || 'Facility',
      totals: {
        subtotal: total / 1.2,
        tax: (total * 0.2) / 1.2,
        grand: total
      }
    },
    items
  };
}

function getDefaultGlobalData() {
  return {
    invoice: {
      number: 'INV-2025-001',
      issueDate: '2025-01-15',
      dueDate: '2025-02-14',
      status: 'DRAFT',
      customer: {
        name: 'Acme Corporation',
        address: '123 Business Street',
        city: 'Commerce City',
        postalCode: '75001',
        country: 'France',
        email: 'billing@acme.corp',
        phone: '+33 1 23 45 67 89'
      },
      facility: 'Main Warehouse',
      totals: {
        subtotal: 3000.00,
        tax: 600.00,
        grand: 3600.00
      }
    },
    items: [
      { position: 1, description: 'Professional Services', qty: 10, price: 150.00, amount: 1500.00 },
      { position: 2, description: 'Consultation Hours',   qty: 5,  price: 200.00, amount: 1000.00 },
      { position: 3, description: 'Software License',     qty: 1,  price: 500.00, amount: 500.00  }
    ]
  };
}

/** Ensure a single “globals” datasource with one “root” record. */
function updateGlobalData(newData: any) {
  try {
    if (!editor) throw new Error('Editor not initialized');
    const dsm = editor.DataSources;
    if (!dsm) throw new Error('DataSources not available');

    const GLOBAL_DS_ID = 'globals';
    const ROOT_ID = 'root';

    let ds = dsm.get(GLOBAL_DS_ID);
    if (!ds) {
      ds = dsm.add({ id: GLOBAL_DS_ID, records: [{ id: ROOT_ID, ...newData }] });
    } else {
      ds.setRecords([{ id: ROOT_ID, ...newData }]);
    }

    editor.trigger('update');
    console.log('Global data updated:', newData);
  } catch (error: any) {
    console.error('Failed to update global data:', error);
    errorMsg.value = `Failed to update global data: ${error.message}`;
  }
}

async function loadInvoiceData(invoiceId?: string) {
  try {
    let invoiceData;
    if (invoiceId) {
      const response = await fetch(`/api/invoices/${encodeURIComponent(invoiceId)}`);
      if (!response.ok) throw new Error(`Failed to load invoice ${invoiceId}: ${response.statusText}`);
      const rawInvoice = await response.json();
      invoiceData = transformInvoiceToGlobalData(rawInvoice);
    } else {
      const response = await fetch('/api/invoices?page=1&pageSize=1&sort=createdDate:desc');
      if (!response.ok) throw new Error(`Failed to load recent invoice: ${response.statusText}`);
      const data = await response.json();
      if (!data?.items?.length) throw new Error('No invoices found');
      invoiceData = transformInvoiceToGlobalData(data.items[0]);
    }
    if (invoiceData && editor) updateGlobalData(invoiceData);
  } catch (error: any) {
    console.error('Failed to load invoice data:', error);
    errorMsg.value = `Failed to load invoice data: ${error.message}`;
  }
}

function setDefaultContent() {
  if (!editor) return;
  editor.setComponents(`
    <div style="padding:${pageSettings.value.margins}px; font-family:Arial, Helvetica, sans-serif;">
      <h1 style="margin:0 0 8px 0;">Invoice Template</h1>
      <div class="text-sm" style="opacity:.8">Use the Blocks panel → Data to bind fields.</div>
      <hr style="margin:12px 0"/>
      <div>Try adding:</div>
      <ul style="margin:6px 0 0 16px; line-height:1.6">
        <li><strong>Data Variable</strong> pointing to <code>globals.root.invoice.number</code></li>
        <li><strong>Data Collection</strong> pointing to <code>globals.root.items</code></li>
      </ul>
      <div style="height:12px"></div>
    </div>
  `);
  editor.setStyle(`
    body { color: #111; }
    .items th, .items td { font-size: 12px; }
    .watermark { position: fixed; top: 40%; left: 15%; opacity: .1; font-size: 120px; transform: rotate(-20deg); }
  `);
}

function tryAddingManualBlocks() {
  if (!editor?.BlockManager) return;
  try {
    const bm = editor.BlockManager;
    bm.add('manual-invoice-number', {
      label: 'Invoice Number (text)',
      category: 'Invoice Fields',
      content: '<span style="border:1px dashed #ccc; padding:4px; background:#f9f9f9;">globals.root.invoice.number</span>'
    });
    bm.add('manual-customer-name', {
      label: 'Customer Name (text)',
      category: 'Invoice Fields',
      content: '<span style="border:1px dashed #ccc; padding:4px; background:#f9f9f9;">globals.root.invoice.customer.name</span>'
    });
  } catch (err) {
    console.warn('Manual blocks add failed:', err);
  }
}

/* -----------------------------
   Template CRUD
------------------------------*/
async function loadTemplate() {
  if (!templateId.value) {
    name.value = 'New Template';
    pageSettings.value = { size: 'A4', margins: 40 };
    bindings.value = {};
    await nextTick();
    if (editor) {
      editor.setComponents('');
      editor.setStyle('');
      setDefaultContent();
      updateGlobalData(getDefaultGlobalData());
    }
    return;
  }

  try {
    const data = await templateService.getTemplate(templateId.value);
    name.value = data?.name ?? '';
    pageSettings.value = data?.pageSettings || { size: 'A4', margins: 40 };
    bindings.value = data?.bindings || {};

    await nextTick();
    if (editor) {
      if (data?.studioProject) {
        editor.loadProjectData(data.studioProject);
      } else {
        setDefaultContent();
      }
    }
  } catch (error) {
    console.error('Error loading template:', error);
    errorMsg.value = 'Failed to load template';
  }
}

/* -----------------------------
   Studio init & re-init helpers
------------------------------*/
function getProjectId(): string {
  return templateId.value || crypto.randomUUID();
}

async function initStudio(projectId?: string) {
  await nextTick();

  // ✅ Use ref, not querySelector
  const rootEl = studioRootRef.value;
  if (!rootEl) {
    errorMsg.value = 'Studio container not found';
    console.error('Studio container ref is null');
    return;
  }

  const licenseKey = import.meta.env.VITE_GJS_STUDIO_KEY;
  if (!licenseKey) {
    errorMsg.value = 'Studio license key not configured. Please set VITE_GJS_STUDIO_KEY.';
    return;
  }

  const config: any = {
    root: rootEl,                 // ✅ element, not selector
    licenseKey,
    project: {
      type: 'document',
      id: projectId || getProjectId(),
      default: {
        pages: [{ name: 'Invoice', component: '<div class="p-6 text-sm">Start here</div>' }]
      }
    },
    storage: { type: 'local' },
    dataSources: { blocks: true }
  };

  // Covers sync/async factory return across builds
  let maybeInstance: any;
  try {
    maybeInstance = createStudio(config);
  } catch (err) {
    console.error('createStudio threw:', err);
    errorMsg.value = 'Studio initialization failed on factory call.';
    return;
  }
  const instance = (maybeInstance && typeof maybeInstance.then === 'function') ? await maybeInstance : maybeInstance;

  if (!instance || !instance.editor) {
    console.error('Studio instance invalid:', instance);
    errorMsg.value = 'Failed to create Studio instance (factory returned invalid result).';
    return;
  }

  studio = instance;
  editor = instance.editor;

  setTimeout(tryAddingManualBlocks, 1000);
  await loadTemplate();
}

async function reinitStudioWithNewProject(newId: string, projectData: any) {
  try { studio?.destroy?.(); } catch { /* ignore */ }
  studio = null;
  editor = null;

  await initStudio(newId);

  if (editor && projectData) {
    editor.loadProjectData(projectData);
  }
}

/* -----------------------------
   Toolbar actions
------------------------------*/
async function doSave(closeAfter = false) {
  if (!studio?.storage?.save) { errorMsg.value = 'Studio not properly initialized'; return; }
  isSaving.value = true; errorMsg.value = null;
  try {
    await studio.storage.save();
    if (closeAfter) emit('close');
  } catch (e: any) {
    console.error('Save error:', e);
    errorMsg.value = e?.message || 'Save failed';
  } finally {
    isSaving.value = false;
  }
}

async function doSaveAs() {
  if (!editor || !studio?.storage) { errorMsg.value = 'Studio not properly initialized'; return; }
  isSaving.value = true; errorMsg.value = null;
  try {
    const projectData = editor.getProjectData();
    const newId = crypto.randomUUID();

    name.value = `${name.value || 'Template'} (Copy)`;
    templateId.value = newId;

    await reinitStudioWithNewProject(newId, projectData);
    await studio.storage.save();
    emit('update:id', newId);
  } catch (e: any) {
    console.error('Save As error:', e);
    errorMsg.value = e?.message || 'Save As failed';
  } finally {
    isSaving.value = false;
  }
}

async function doExport() {
  if (!templateId.value) { alert('Save the template first.'); return; }
  isExporting.value = true; errorMsg.value = null;
  try {
    const blob: Blob = await templateService.previewTemplate(templateId.value, { format: 'pdf', mode: 'draft' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (e: any) {
    console.error('Export error:', e);
    errorMsg.value = e?.message || 'Export failed';
  } finally {
    isExporting.value = false;
  }
}

function toggleBlocks() {
  try {
    const openId = 'open-blocks';
    const btn = editor?.Panels?.getButton('views', openId);
    if (btn?.get('active')) { editor.Commands.stop(openId); btn.set('active', false); }
    else { editor.Commands.run(openId); btn?.set('active', true); }
  } catch (error) {
    console.error('Toggle blocks error:', error);
    errorMsg.value = 'Failed to toggle blocks panel';
  }
}

function toggleDataSources() {
  try {
    const cmd = editor?.Commands;
    if (!cmd) return;
    if (cmd.get('open-data-sources')) cmd.run('open-data-sources');
    else if (cmd.get('show-data-sources')) cmd.run('show-data-sources');
    else if (cmd.get('data-sources')) cmd.run('data-sources');
    else {
      const panels = editor?.Panels;
      const dsPanel = panels?.getPanel('data-sources');
      if (dsPanel) dsPanel.set('visible', !dsPanel.get('visible'));
      else console.warn('Data sources UI not found');
    }
  } catch (error) {
    console.error('Failed to toggle data sources:', error);
    errorMsg.value = 'Failed to toggle data sources panel';
  }
}

function debugDataSources() {
  try {
    console.log('=== DataSources Debug ===');
    if (!editor) { console.log('Editor not initialized'); return; }
    const blockManager = editor.BlockManager;
    console.log('Block count:', blockManager?.getAll()?.length);
    const dsm = editor.DataSources;
    console.log('DataSources manager:', dsm);
    if (dsm) {
      const globals = dsm.get('globals');
      console.log('globals records:', globals?.getRecords?.());
    }
    console.log('=== End Debug ===');
  } catch (error) {
    console.error('Debug error:', error);
    errorMsg.value = 'Debug failed - check console for details';
  }
}

/* -----------------------------
   Lifecycle
------------------------------*/
onMounted(async () => {
  await initStudio();
  updateGlobalData(getDefaultGlobalData());
});

onUnmounted(() => {
  try { studio?.destroy?.(); } catch { /* ignore */ }
  studio = null; editor = null;
});

watch(() => props.id, async (val, old) => {
  if (val === old) return;
  templateId.value = val;
  await loadTemplate();
});
</script>

<template>
  <div class="flex flex-col h-screen">
    <!-- Top toolbar -->
    <div class="flex items-center gap-3 px-3 py-2 border-b bg-white">
      <div class="flex items-center gap-2">
        <span class="font-semibold">Template:</span>
        <input v-model="name" class="border rounded px-2 py-1 text-sm w-64" placeholder="Template name" />
      </div>

      <div class="flex-1" />

      <!-- Toggle Blocks -->
      <button class="p-2 rounded hover:bg-gray-100" title="Toggle Blocks" @click="toggleBlocks">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M4 4h6v6H4V4Zm10 0h6v6h-6V4ZM4 14h6v6H4v-6Zm10 0h6v6h-6v-6Z" stroke="currentColor" stroke-width="2"/>
        </svg>
      </button>

      <!-- Toggle DataSources -->
      <button class="p-2 rounded hover:bg-gray-100" title="Toggle Data Sources" @click="toggleDataSources">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M3 3h18v18H3V3zm2 2v14h14V5H5zm2 2h10v2H7V7zm0 4h10v2H7v-2zm0 4h6v2H7v-2z" stroke="currentColor" stroke-width="2"/>
        </svg>
      </button>

      <!-- Debug Button -->
      <button class="p-2 rounded hover:bg-gray-100" title="Debug DataSources" @click="debugDataSources">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M12 2a10 10 0 1 0 .001 20.001A10 10 0 0 0 12 2Zm-1 15h2v2h-2v-2Zm0-8h2v6h-2V9Z" stroke="currentColor" stroke-width="2"/>
        </svg>
      </button>

      <!-- Save -->
      <button class="p-2 rounded hover:bg-gray-100 disabled:opacity-60" :disabled="isSaving" title="Save" @click="doSave(false)">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M5 20h14V7l-3-3H5v16Zm0 0v-7h14v7M9 4v4m0 0h6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
      </button>

      <!-- Save As -->
      <button class="p-2 rounded hover:bg-gray-100 disabled:opacity-60" :disabled="isSaving" title="Save As" @click="doSaveAs">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M12 5v14m7-7H5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
      </button>

      <!-- Export PDF -->
      <button class="p-2 rounded hover:bg-gray-100 disabled:opacity-60" :disabled="!templateId || isExporting" title="Export PDF" @click="doExport">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M12 3v12m0 0 4-4m-4 4-4-4M4 21h16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
      </button>

      <!-- Close -->
      <button class="p-2 rounded hover:bg-gray-100" title="Close" @click="$emit('close')">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
      </button>
    </div>

    <!-- Main area -->
    <div class="flex-1 flex">
      <!-- Studio Editor -->
      <div class="flex-1">
        <!-- ✅ use ref for reliable mount -->
        <div :id="studioRootId" ref="studioRootRef" class="w-full h-full min-h-[700px]"></div>
      </div>

      <!-- Data panel -->
      <div class="w-80 border-l bg-gray-50 p-4">
        <div class="bg-white border rounded-lg shadow-sm">
          <div class="p-3 border-b">
            <h3 class="text-sm font-medium text-gray-900">Data Sources</h3>
            <p class="text-xs text-gray-500 mt-1">Load real invoice data for preview</p>
          </div>

          <div class="p-3 space-y-3">
            <div>
              <label class="block text-xs font-medium text-gray-700 mb-1">Load Data</label>
              <div class="flex gap-1">
                <button
                  @click="loadInvoiceData()"
                  class="flex-1 px-2 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700">
                  Recent Invoice
                </button>
                <button
                  @click="updateGlobalData(getDefaultGlobalData())"
                  class="flex-1 px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded hover:bg-gray-200">
                  Sample Data
                </button>
              </div>
            </div>

            <div>
              <label class="block text-xs font-medium text-gray-700 mb-1">Specific Invoice</label>
              <div class="flex gap-1">
                <input
                  v-model="specificInvoiceId"
                  type="text"
                  placeholder="Invoice ID"
                  class="flex-1 px-2 py-1 text-xs border border-gray-300 rounded"
                />
                <button
                  @click="loadInvoiceData(specificInvoiceId)"
                  :disabled="!specificInvoiceId"
                  class="px-2 py-1 text-xs bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50">
                  Load
                </button>
              </div>
            </div>

            <div class="text-xs text-gray-500 pt-2 border-t leading-5">
              Use the blocks panel to drag <strong>Data Variable</strong>, <strong>Data Condition</strong>, and
              <strong>Data Collection</strong> elements. Common paths:
              <ul class="list-disc ml-5 mt-1">
                <li><code>globals.root.invoice.number</code></li>
                <li><code>globals.root.invoice.customer.name</code></li>
                <li><code>globals.root.items</code> (as collection)</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-if="errorMsg" class="px-3 py-2 text-sm text-red-600 border-t bg-rose-50">
      {{ errorMsg }}
    </div>
  </div>
</template>

<style scoped>
#studio-editor, .gjs-editor, .gjs-cv-canvas { height: 100% !important; width: 100% !important; }
.gjs-pn-panels { z-index: 10; }
.gjs-blocks-c { min-width: 260px; }
</style>
