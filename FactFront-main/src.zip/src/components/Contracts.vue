<script setup lang="ts">
import { ref, inject, onMounted } from 'vue';
import { 
  Search, 
  Filter, 
  Download,
  Plus,
  Pencil,
  Trash2,
  CheckCircle,
  XCircle,
  ArrowDownCircle,
  ArrowUpCircle,
  CircleDot
} from 'lucide-vue-next';
import AdvancedFilter from './AdvancedFilter.vue';
import ContractForm from './ContractForm.vue';
import type { EventConfig } from '../types/event-config';

interface Contract {
  id: string;
  name: string;
  description: string;
  calculationMode: {
    type: string;
    subType: string;
    eventConfig: EventConfig;
    parameters?: Record<string, any>;
  };
  status: 'Active' | 'Disable';
  startDate: string;
  endDate: string;
}

const showForm = ref(false);
const editingContract = ref<Contract | null>(null);
const showDeleteConfirm = ref(false);
const contractToDelete = ref<Contract | null>(null);
const isSaving = ref(false);

const $axios = inject<any>('$axios');

const contracts = ref<Contract[]>([]);

const fetchContracts = async () => {
  try {
    const response = await $axios.get('/contract');
    contracts.value = response.data;
  } catch (error) {
    alert('Failed to load contracts');
  }
};

onMounted(fetchContracts);

const handleFilter = (filters: any[]) => {
  console.log('Applying filters:', filters);
  // Implement filter logic here
};

const getStatusBadgeClasses = (status: string) => {
  const baseClasses = "px-2 py-1 text-xs font-medium rounded-full";
  switch (status) {
    case 'Active':
      return `${baseClasses} bg-green-100 text-green-800`;
    case 'Disable':
      return `${baseClasses} bg-gray-100 text-gray-800`;
    default:
      return baseClasses;
  }
};

const getEventTypeIcon = (type: string | undefined) => {
  switch (type) {
    case 'IN':
      return ArrowDownCircle;
    case 'OUT':
      return ArrowUpCircle;
    default:
      return CircleDot;
  }
};

const getEventTypeClasses = (type: string | undefined) => {
  const baseClasses = "flex items-center space-x-1";
  switch (type) {
    case 'IN':
      return `${baseClasses} text-green-600`;
    case 'OUT':
      return `${baseClasses} text-red-600`;
    case 'INTERMEDIATE':
      return `${baseClasses} text-blue-600`;
    default:
      return baseClasses;
  }
};

const handleAdd = () => {
  editingContract.value = null;
  showForm.value = true;
};

const handleEdit = (contract: any) => {
  const id = contract?.id ?? contract?._id ?? contract?.contractId;
  editingContract.value = { ...contract, id };
  showForm.value = true;
};

const handleDelete = (contract: Contract) => {
  contractToDelete.value = contract;
  showDeleteConfirm.value = true;
};

const confirmDelete = async () => {
  if (contractToDelete.value) {
    try {
      await $axios.delete(`/contract/${contractToDelete.value.id}`);
      alert('Contract deleted successfully');
      await fetchContracts();
    } catch (error) {
      console.error('Failed to delete contract:', error);
      alert('Failed to delete contract');
    } finally {
      showDeleteConfirm.value = false;
      contractToDelete.value = null;
    }
  }
};

const handleFormSubmit = async (formData: Contract) => {
  if (editingContract.value) {
    const id = editingContract.value.id;
    if (!id) {
      alert('Cannot update contract: missing identifier');
      return;
    }
    isSaving.value = true;
    try {
      await $axios.put(`/contract/${id}`, formData);
      alert('Contract updated successfully');
      showForm.value = false;
      editingContract.value = null;
      await fetchContracts();
    } catch (error: any) {
      console.error('Failed to update contract:', error);
      if (error?.response?.status === 404) {
        alert('Contract not found');
      } else {
        alert('Failed to update contract');
      }
    } finally {
      isSaving.value = false;
    }
  } else {
    isSaving.value = true;
    try {
      await $axios.post('/contract', formData);
      alert('Contract created successfully');
      showForm.value = false;
      await fetchContracts();
    } catch (error) {
      console.error('Failed to create contract:', error);
      alert('Failed to create contract');
    } finally {
      isSaving.value = false;
      editingContract.value = null;
    }
  }
};

const handleFormCancel = () => {
  showForm.value = false;
  editingContract.value = null;
};
</script>

<template>
  <div>
    <!-- List View -->
    <div v-if="!showForm" class="bg-white shadow rounded-lg">
      <!-- Header -->
      <div class="px-6 py-4 border-b border-gray-200">
        <div class="flex justify-between items-center">
          <h2 class="text-lg font-semibold text-gray-900">Contracts</h2>
          <div class="flex space-x-4">
            <div class="relative">
              <input
                type="text"
                placeholder="Search contracts..."
                class="w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
              <Search class="h-5 w-5 text-gray-400 absolute left-3 top-2.5" />
            </div>
            <button class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
              <Download class="h-4 w-4 mr-2" />
              Export
            </button>
            <button 
              @click="handleAdd"
              class="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
            >
              <Plus class="h-4 w-4 mr-2" />
              Add Contract
            </button>
          </div>
        </div>
      </div>

      <!-- Advanced Filter -->
      <AdvancedFilter type="contracts" @filter="handleFilter" />

      <!-- Table -->
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th v-for="header in [
                'Contract Name', 'Event', 'Calculation Mode', 'Status', 'Start Date', 'End Date', 'Actions'
              ]" :key="header" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {{ header }}
              </th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <tr v-for="contract in contracts" :key="contract.id" class="hover:bg-gray-50">
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm font-medium text-gray-900">{{ contract.name }}</div>
                <div class="text-sm text-gray-500">{{ contract.description }}</div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <div :class="getEventTypeClasses(contract.calculationMode.eventConfig?.eventType)">
                  <component
                    :is="getEventTypeIcon(contract.calculationMode.eventConfig?.eventType)"
                    class="h-4 w-4"
                  />
                  <span class="text-sm">{{ contract.calculationMode.eventConfig?.eventName }}</span>
                </div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900">{{ contract.calculationMode.type }}</div>
                <div class="text-sm text-gray-500">{{ contract.calculationMode.subType.replace(/_/g, ' ') }}</div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <span :class="getStatusBadgeClasses(contract.status)">
                  {{ contract.status }}
                </span>
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {{ new Date(contract.startDate).toLocaleDateString() }}
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {{ new Date(contract.endDate).toLocaleDateString() }}
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <button
                  @click="handleEdit(contract)"
                  class="text-blue-600 hover:text-blue-900 mr-3"
                >
                  <Pencil class="h-5 w-5" />
                </button>
                <button
                  @click="handleDelete(contract)"
                  class="text-red-600 hover:text-red-900"
                >
                  <Trash2 class="h-5 w-5" />
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Form View -->
    <ContractForm
      v-else
      :edit-mode="!!editingContract"
      :initial-data="editingContract"
      :loading="isSaving"
      @submit="handleFormSubmit"
      @cancel="handleFormCancel"
    />

    <!-- Delete Confirmation Modal -->
    <Teleport to="body">
      <div v-if="showDeleteConfirm" class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg p-6 max-w-md w-full">
          <div class="text-center">
            <XCircle class="mx-auto h-12 w-12 text-red-500" />
            <h3 class="mt-4 text-lg font-medium text-gray-900">Delete Contract</h3>
            <p class="mt-2 text-sm text-gray-500">
              Are you sure you want to delete {{ contractToDelete?.name }}? This action cannot be undone.
            </p>
          </div>
          <div class="mt-6 flex justify-end space-x-3">
            <button
              @click="showDeleteConfirm = false"
              class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              @click="confirmDelete"
              class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>