<script setup lang="ts">
import { ref } from 'vue';
import type { EntityDef, FieldDef } from '../types/i18nFields';
import { useI18nFieldsStore } from '../stores/i18nFieldsStore';

const props = defineProps<{ languageCode: string; entity: EntityDef }>();
const emit = defineEmits<{ (e: 'change'): void }>();
const store = useI18nFieldsStore();

const editing = ref<FieldDef | null>(null);
const tmp = ref<FieldDef>({ field: '', name: '', type: 'text', required: false });

function openAdd() {
  editing.value = null;
  tmp.value = { field: '', name: '', type: 'text', required: false };
}
function openEdit(f: FieldDef) {
  editing.value = f;
  tmp.value = { ...f };
}
async function save() {
  const fields = editing.value
    ? props.entity.fields.map((f) => (f.field === editing.value!.field ? tmp.value : f))
    : [...props.entity.fields, tmp.value];
  await store.bulkUpsertFields(props.languageCode, props.entity.entity, fields, 'put');
  editing.value = null;
  emit('change');
}
async function remove(f: FieldDef) {
  await store.deleteField(props.languageCode, props.entity.entity, f.field);
  emit('change');
}
</script>

<template>
  <div>
    <div class="flex justify-between">
      <span class="font-medium">Fields</span>
      <button class="border px-2 py-1" @click="openAdd">Add Field</button>
    </div>
    <table class="w-full border mt-1">
      <thead>
        <tr class="bg-gray-100 text-left">
          <th class="p-1">Field</th>
          <th class="p-1">Name</th>
          <th class="p-1">Type</th>
          <th class="p-1">Required</th>
          <th class="p-1"></th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="f in entity.fields" :key="f.field" class="border-t">
          <td class="p-1">{{ f.field }}</td>
          <td class="p-1">{{ f.name }}</td>
          <td class="p-1">{{ f.type }}</td>
          <td class="p-1">{{ f.required }}</td>
          <td class="p-1 space-x-1">
            <button class="border px-2 py-1" @click="openEdit(f)">Edit</button>
            <button class="border px-2 py-1" @click="remove(f)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>

    <div v-if="editing !== null" class="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
      <div class="bg-white p-4 rounded w-80">
        <h4 class="font-bold mb-2">{{ editing ? 'Edit' : 'Add' }} Field</h4>
        <div class="space-y-2">
          <label class="block">
            <span class="text-sm">Field</span>
            <input v-model="tmp.field" :disabled="!!editing" class="border p-1 w-full" />
          </label>
          <label class="block">
            <span class="text-sm">Name</span>
            <input v-model="tmp.name" class="border p-1 w-full" />
          </label>
          <label class="block">
            <span class="text-sm">Type</span>
            <select v-model="tmp.type" class="border p-1 w-full">
              <option value="text">text</option>
              <option value="number">number</option>
              <option value="boolean">boolean</option>
              <option value="date">date</option>
              <option value="datetime">datetime</option>
              <option value="currency">currency</option>
              <option value="select">select</option>
              <option value="multiselect">multiselect</option>
              <option value="textarea">textarea</option>
            </select>
          </label>
          <label class="inline-flex items-center gap-2">
            <input type="checkbox" v-model="tmp.required" />
            <span>Required</span>
          </label>
        </div>
        <div class="mt-4 flex justify-end gap-2">
          <button class="px-3 py-1 border" @click="editing=null">Cancel</button>
          <button class="px-3 py-1 bg-blue-500 text-white" @click="save">Save</button>
        </div>
      </div>
    </div>
  </div>
</template>
