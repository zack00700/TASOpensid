// src/services/vesselVisitService.ts

/**
 * Types
 */
export interface VesselVisit {
  id: string;
  vesselName: string;
  imo?: string | null;
  callSign?: string | null;
  voyageIn?: string | null;
  voyageOut?: string | null;
  operator?: string | null;
  port?: string | null;
  terminal?: string | null;
  berth?: string | null;
  eta?: string | null; // ISO
  etd?: string | null; // ISO
  ata?: string | null; // ISO
  atd?: string | null; // ISO
}

/**
 * Small helper to clean user input so your backend never receives
 * things like "Neptune (N/A" or dangling "(" which were causing 500s.
 *
 * Rules:
 * - cut everything from the first "("
 * - remove any parentheses just in case
 * - remove literal "N/A"
 * - collapse whitespace
 */
export function sanitizeVesselQuery(raw: string): string {
  return String(raw || "")
    .replace(/\(.*/g, "")     // cut from first "("
    .replace(/[()]/g, "")     // strip any remaining parentheses
    .replace(/\bN\/A\b/gi, "")// drop N/A tokens
    .replace(/\s+/g, " ")
    .trim();
}

const BASE = "/api/vessel-visits";

/**
 * Search vessel visits by a free-text query.
 * - Returns [] for very short queries (length < 2)
 * - Throws if the response is not OK
 */
async function search(raw: string): Promise<VesselVisit[]> {
  const q = sanitizeVesselQuery(raw);
  if (q.length < 2) return [];

  const url = `${BASE}/search?q=${encodeURIComponent(q)}`;
  const res = await fetch(url, { method: "GET" });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Vessel search failed (${res.status}): ${text || url}`);
  }

  const data = (await res.json()) as VesselVisit[] | { data: VesselVisit[] };
  // Accept both plain array or { data: [] } API shapes
  // @ts-expect-error runtime shape check
  return Array.isArray(data) ? (data as VesselVisit[]) : (data as any).data ?? [];
}

/**
 * Optional: fetch a single visit by id
 */
async function getById(id: string): Promise<VesselVisit | null> {
  if (!id) return null;
  const res = await fetch(`${BASE}/${encodeURIComponent(id)}`, { method: "GET" });
  if (!res.ok) return null;
  return (await res.json()) as VesselVisit;
}

/**
 * Convenience: minimal snapshot mapper (if you need it here).
 * If you already have this in billOfLadingService, you can remove this export.
 */
export function toSnapshot(v: VesselVisit) {
  return {
    id: v.id,
    vesselName: v.vesselName || "",
    imo: v.imo || "",
    callSign: v.callSign || "",
    voyageIn: v.voyageIn || "",
    voyageOut: v.voyageOut || "",
    operator: v.operator || "",
    port: v.port || "",
    terminal: v.terminal || "",
    berth: v.berth || "",
    eta: v.eta || null,
    etd: v.etd || null,
    ata: v.ata || null,
    atd: v.atd || null,
  };
}

const vesselVisitService = {
  search,
  getById,
  sanitizeVesselQuery,
  toSnapshot,
};

export default vesselVisitService;
