export interface Vessel {
  id?: string; // Ajout du champ id manquant
  name: string;
  imoNumber: string;
  callSign: string;
  flag: string;
  owner: string;
  operator: string;
  vesselType: string;
  status: 'Active' | 'Inactive';
}