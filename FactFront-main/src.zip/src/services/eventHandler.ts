

import axios from 'axios';
import api from '../plugin/axios';
import { Event, Item } from '../types/item';

enum EventTypeEnum {
  IN = 'IN',
  OUT = 'OUT',
  INTERMEDIATE = 'INTERMEDIATE'
}

export class EventHandler {
  private static instance: EventHandler;

  private constructor() {}

  public static getInstance(): EventHandler {
    if (!EventHandler.instance) {
      EventHandler.instance = new EventHandler();
    }
    return EventHandler.instance;
  }

  public processEvent(event: Event, item: Item): Promise<string> {
    const eventType = (event.eventType || '').toUpperCase() as EventTypeEnum;
    switch (eventType) {
      case EventTypeEnum.IN:
        return this.handleInEvent(eventType, event, item);
      case EventTypeEnum.OUT:
        return this.handleOutEvent(eventType, event, item);
      case EventTypeEnum.INTERMEDIATE:
        return this.handleIntermediateEvent(eventType, event, item);
      default:
        throw new Error(`Invalid event type: ${event.eventType}`);
    }
  }


  private getErrorMessage(error: unknown): string {
    if (axios.isAxiosError(error)) {
      return error.response?.data?.message ?? error.message;
    }
    if (error instanceof Error) {
      return error.message;
    }
    return 'An unexpected error occurred';
  }

  private async handleInEvent(eventType: EventTypeEnum, event: Event, item: Item): Promise<string> {

    let ret;
    const eventToAdd = {
      type: eventType,
      timeStamp: event.timestamp,
      location: event.location,
      notes: event.notes
    };

    try {
      await api.put(`/item/${item.id}`, eventToAdd);
      ret = 'success';
    } catch (e) {

      ret = this.getErrorMessage(e);

    }

    return ret;
  }

  private async handleOutEvent(eventType: EventTypeEnum, event: Event, item: Item): Promise<string> {
    const eventToAdd = {
      type: eventType,
      timeStamp: event.timestamp,
      location: event.location,
      notes: event.notes
    };
    let ret;
    try {
      await api.put(`/item/${item.id}`, eventToAdd);
      ret = 'success';
    } catch (e) {

      console.error(e);
      ret = this.getErrorMessage(e);
    }
    
    return ret;
  }

  private async handleIntermediateEvent(eventType: EventTypeEnum, event: Event, item: Item): Promise<string> {
    let ret;

    const eventToAdd = {
      type: eventType,
      timeStamp: event.timestamp,
      location: event.location,
      notes: event.notes
    };

    try {
      await api.put(`/item/${item.id}`, eventToAdd);

      ret = 'success';
    } catch (e) {
      ret = this.getErrorMessage(e);
    }

    return ret;
  }
}
