<script setup lang="ts">
import { onMounted, watch, computed, ref, nextTick } from 'vue';
import {
  Filter,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  X,
  FileSearch,
  CheckCircle,
  ArrowUp,
  ArrowDown,
  MoreVertical,
  Eye,
  FileText,
  Trash2,
  TrendingUp,
  TrendingDown,
  Search,
  Calendar,
  Users,
  Building,
  Hash,
  DollarSign
} from 'lucide-vue-next';
import { useInvoice, SORTABLE_FIELDS } from '../composables/use.invoice';
import InvoicePreview from './InvoicePreview.vue';
import invoiceService from '../services/invoiceService';
import KebabMenu from './KebabMenu.vue';

const { state, displayedCount, fetchInvoices, clearFilters, hydrateFromUrl } =
  useInvoice();

// controls visibility of the filter panel
const filtersOpen = ref(false);

function toggleFilters() {
  filtersOpen.value = !filtersOpen.value;
}

function toggleStatus(status: string) {
  const idx = state.filters.status.indexOf(status);
  if (idx === -1) state.filters.status.push(status);
  else state.filters.status.splice(idx, 1);
}

function removeFilter(key: string, value?: string) {
  const f = state.filters;
  switch (key) {
    case 'status':
      f.status = f.status.filter((s) => s !== value);
      break;
    case 'customerName':
      f.customerName = '';
      break;
    case 'facility':
      f.facility = '';
      break;
    case 'draftNumber':
      f.draftNumber = '';
      break;
    case 'finalNumber':
      f.finalNumber = '';
      break;
    case 'createdDateFrom':
      f.createdDateFrom = null;
      break;
    case 'createdDateTo':
      f.createdDateTo = null;
      break;
  }
}

const activeFilterChips = computed(() => {
  const chips: { key: string; value?: string; label: string }[] = [];
  const f = state.filters;
  f.status.forEach((s) => chips.push({ key: 'status', value: s, label: s }));
  if (f.customerName)
    chips.push({ key: 'customerName', label: f.customerName });
  if (f.facility) chips.push({ key: 'facility', label: f.facility });
  if (f.draftNumber)
    chips.push({ key: 'draftNumber', label: f.draftNumber });
  if (f.finalNumber)
    chips.push({ key: 'finalNumber', label: f.finalNumber });
  if (f.createdDateFrom)
    chips.push({ key: 'createdDateFrom', label: `From: ${f.createdDateFrom}` });
  if (f.createdDateTo)
    chips.push({ key: 'createdDateTo', label: `To: ${f.createdDateTo}` });
  return chips;
});

const hasActiveFilters = computed(() => activeFilterChips.value.length > 0);

const draftPercent = computed(() =>
  state.totalCount ? Math.round((state.statusCounts.DRAFT / state.totalCount) * 100) : 0
);
const finalPercent = computed(() =>
  state.totalCount ? Math.round((state.statusCounts.FINAL / state.totalCount) * 100) : 0
);

const totalTrend = computed(() => state.trends?.totalAmount ?? 0);
const draftTrend = computed(() => state.trends?.status?.DRAFT ?? 0);
const finalTrend = computed(() => state.trends?.status?.FINAL ?? 0);
const displayedTrend = computed(() => state.trends?.displayed ?? 0);

function getRowAmount(inv: any): number {
  const raw = inv.totalAmount ?? inv.TotalAmount ?? inv.amount;
  const num = typeof raw === 'number' ? raw : parseFloat(raw);
  return Number.isFinite(num) ? num : 0;
}

function formatCurrency(amount: unknown) {
  const num = typeof amount === 'number' ? amount : parseFloat(String(amount));
  return (Number.isFinite(num) ? num : 0).toLocaleString(undefined, {
    style: 'currency',
    currency: 'USD',
  });
}

function formatDate(value: string | number | Date) {
  if (!value) return '—';
  const date = value instanceof Date ? value : new Date(value);
  if (isNaN(date.getTime())) return '—';
  return date.toLocaleString(undefined, {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}

function statusBadgeClass(status: string) {
  switch (status) {
    case 'DRAFT':
      return 'bg-amber-50 text-amber-700 border border-amber-200 text-xs font-medium px-2.5 py-1 rounded-full';
    case 'FINAL':
      return 'bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-medium px-2.5 py-1 rounded-full';
    default:
      return 'bg-slate-50 text-slate-700 border border-slate-200 text-xs font-medium px-2.5 py-1 rounded-full';
  }
}

function toggleSort(field: string) {
  if (!SORTABLE_FIELDS.includes(field)) return;
  const [currentField, currentDir] = state.sort.split(':');
  if (currentField === field) {
    state.sort = `${field}:${currentDir === 'asc' ? 'desc' : 'asc'}`;
  } else {
    state.sort = `${field}:asc`;
  }
}

function getSortDirection(field: string) {
  const [currentField, currentDir] = state.sort.split(':');
  return currentField === field ? currentDir : null;
}

function changePage(delta: number) {
  const newPage = state.page + delta;
  if (newPage < 1) return;
  state.page = newPage;
}

function updateUrl() {
  const params = new URLSearchParams();
  const f = state.filters;
  if (f.status.length) params.set('status', f.status.join(','));
  if (f.customerName) params.set('customerName', f.customerName);
  if (f.facility) params.set('facility', f.facility);
  if (f.draftNumber) params.set('draftNumber', f.draftNumber);
  if (f.finalNumber) params.set('finalNumber', f.finalNumber);
  if (f.createdDateFrom) params.set('createdDateFrom', f.createdDateFrom);
  if (f.createdDateTo) params.set('createdDateTo', f.createdDateTo);
  params.set('page', String(state.page));
  params.set('pageSize', String(state.pageSize));
  params.set('sort', state.sort);
  const query = params.toString();
  const newUrl = `${window.location.pathname}?${query}`;
  window.history.replaceState(null, '', newUrl);
}

function selectStatusFilter(status: 'DRAFT' | 'FINAL') {
  state.filters.status = [status];
  state.page = 1;
  updateUrl();
  fetchInvoices();
}

function showAll() {
  clearFilters();
  updateUrl();
  fetchInvoices();
}

let timer: number | undefined;
function scheduleFetch() {
  clearTimeout(timer);
  timer = window.setTimeout(() => {
    fetchInvoices();
    updateUrl();
  }, 300);
}

// Prevent initial hydration from triggering extra fetches
const isHydrating = ref(true);

const previewInvoice =
  ref<{ id: string; displayId: string; status: string; url: string } | null>(null);
const finalizeTarget = ref<{ id: string; displayId: string } | null>(null);
const deleteTarget = ref<{ id: string; displayId: string } | null>(null);
const isDeleting = ref(false);
const toast = ref<{ message: string; type: 'error' | 'success' } | null>(null);

function showToast(message: string, type: 'error' | 'success' = 'error') {
  toast.value = { message, type };
  setTimeout(() => (toast.value = null), 3000);
}

const displayedTotalAmount = computed(() =>
  state.items.reduce((sum, inv) => sum + getRowAmount(inv), 0)
);

function openPreview(id: string) {
  if (!id) {
    console.error('openPreview: missing invoiceId on row');
    showToast('Invoice ID missing for this row.');
    return;
  }
  const inv =
    state.items.find((i: any) => i._id === id || i.id === id || i.invoiceId === id) || {};
  previewInvoice.value = {
    id: String(id),
    displayId: String(inv.finalNumber || inv.draftNumber || id),
    status: inv.status,
    url: '',
  };
  try {
    const url = invoiceService.getInvoicePreviewUrl(id);
    previewInvoice.value.url = url;
  } catch (e: any) {
    console.error(e);
    previewInvoice.value = null;
    showToast('Failed to open invoice preview.');
  }
}

function openFinalize(inv: any) {
  const id = inv?._id || inv?.id || inv?.invoiceId;
  if (!id) {
    console.error('openFinalize: missing invoiceId on row');
    showToast('Invoice ID missing for this row.');
    return;
  }
  finalizeTarget.value = {
    id: String(id),
    displayId: String(inv.finalNumber || inv.draftNumber || id),
  };
}

function openDelete(inv: any) {
  const id = inv?._id || inv?.id || inv?.invoiceId;
  if (!id) {
    console.error('openDelete: missing invoiceId on row');
    showToast('Invoice ID missing for this row.');
    return;
  }
  deleteTarget.value = {
    id: String(id),
    displayId: String(inv.finalNumber || inv.draftNumber || inv.displayId || id),
  };
}

async function finalizeInvoice() {
  if (!finalizeTarget.value) return;
  try {
    await invoiceService.finalize(finalizeTarget.value.id);
    await fetchInvoices();
    showToast('Invoice finalized successfully', 'success');
  } catch (e: any) {
    console.error(e);
    showToast(e?.response?.data?.message || 'Failed to finalize invoice.');
  } finally {
    finalizeTarget.value = null;
  }
}

async function deleteInvoice() {
  if (!deleteTarget.value) return;
  isDeleting.value = true;
  try {
    await invoiceService.delete(deleteTarget.value.id);
    await fetchInvoices();
    if (previewInvoice.value && previewInvoice.value.id === deleteTarget.value.id) {
      previewInvoice.value = null;
    }
    showToast('Draft deleted', 'success');
  } catch (e: any) {
    const status = e?.response?.status;
    if (status === 404) {
      showToast('Invoice not found');
    } else if (status === 409) {
      showToast('Only draft invoices can be deleted');
    } else {
      showToast(e?.response?.data?.message || 'Failed to delete invoice.');
    }
  } finally {
    isDeleting.value = false;
    deleteTarget.value = null;
  }
}

function closePreview() {
  previewInvoice.value = null;
}

async function finalizePreview() {
  if (!previewInvoice.value) return;
  try {
    await invoiceService.finalize(previewInvoice.value.id);
    await fetchInvoices();
    const inv =
      state.items.find(
        (i: any) => i._id === previewInvoice.value!.id || i.id === previewInvoice.value!.id || i.invoiceId === previewInvoice.value!.id
      ) || {};
    previewInvoice.value.status = inv.status || 'FINAL';
    previewInvoice.value.displayId = String(inv.finalNumber || inv.draftNumber || previewInvoice.value.id);
    try {
      previewInvoice.value.url = invoiceService.getInvoicePreviewUrl(previewInvoice.value.id);
    } catch (e) {
      console.error(e);
    }
  } catch (e) {
    console.error(e);
    showToast('Failed to finalize invoice.');
  }
}

function openDeleteFromPreview() {
  if (previewInvoice.value) {
    openDelete(previewInvoice.value);
  }
}

watch(
  () => state.filters,
  () => {
    if (!isHydrating.value) scheduleFetch();
  },
  { deep: true }
);
watch([() => state.page, () => state.pageSize, () => state.sort], () => {
  if (!isHydrating.value) scheduleFetch();
});

onMounted(async () => {
  hydrateFromUrl();
  await nextTick();
  isHydrating.value = false;
  fetchInvoices();
});
</script>

<template>
  <div class="min-h-screen bg-slate-50">
    <!-- Header with Dashboard Cards -->
    <div class="bg-white border-b border-slate-200">
      <div class="px-6 py-8">
        <div class="mb-8">
          <h1 class="text-2xl font-bold text-slate-900">Invoices</h1>
          <p class="text-slate-600 mt-1">Manage and track your invoice workflow</p>
        </div>
        
        <!-- Dashboard Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <!-- Total Amount Card -->
          <div
            class="group bg-white border border-slate-200 rounded-xl p-6 hover:shadow-md transition-all duration-200 cursor-pointer"
            @click="showAll"
          >
            <div class="flex items-center justify-between">
              <div>
                <p class="text-sm font-medium text-slate-600 mb-1">Total Amount</p>
                <p class="text-2xl font-bold text-slate-900">{{ formatCurrency(state.totalAmount) }}</p>
                <div class="flex items-center mt-2">
                  <div v-if="totalTrend" class="flex items-center text-sm">
                    <TrendingUp v-if="totalTrend > 0" class="w-4 h-4 text-emerald-500 mr-1" />
                    <TrendingDown v-else-if="totalTrend < 0" class="w-4 h-4 text-red-500 mr-1" />
                    <span class="text-slate-600">{{ Math.abs(totalTrend) }}%</span>
                  </div>
                </div>
              </div>
              <div class="flex flex-col items-end">
                <div class="bg-slate-100 p-3 rounded-lg mb-2">
                  <DollarSign class="w-6 h-6 text-slate-600" />
                </div>
                <span class="text-lg font-semibold text-slate-700">{{ state.totalCount }}</span>
              </div>
            </div>
          </div>

          <!-- Draft Card -->
          <div
            class="group bg-white border border-amber-200 rounded-xl p-6 hover:shadow-md transition-all duration-200 cursor-pointer"
            @click="selectStatusFilter('DRAFT')"
          >
            <div class="flex items-center justify-between">
              <div>
                <p class="text-sm font-medium text-amber-700 mb-1">Draft Invoices</p>
                <p class="text-2xl font-bold text-amber-800">{{ formatCurrency(state.statusAmounts.DRAFT) }}</p>
                <div class="flex items-center mt-2">
                  <span class="text-sm text-amber-600">{{ draftPercent }}% of total</span>
                  <div v-if="draftTrend" class="flex items-center text-sm ml-2">
                    <TrendingUp v-if="draftTrend > 0" class="w-4 h-4 text-emerald-500 mr-1" />
                    <TrendingDown v-else-if="draftTrend < 0" class="w-4 h-4 text-red-500 mr-1" />
                  </div>
                </div>
              </div>
              <div class="flex flex-col items-end">
                <div class="bg-amber-100 p-3 rounded-lg mb-2">
                  <FileText class="w-6 h-6 text-amber-600" />
                </div>
                <span class="text-lg font-semibold text-amber-700">{{ state.statusCounts.DRAFT }}</span>
              </div>
            </div>
          </div>

          <!-- Final Card -->
          <div
            class="group bg-white border border-emerald-200 rounded-xl p-6 hover:shadow-md transition-all duration-200 cursor-pointer"
            @click="selectStatusFilter('FINAL')"
          >
            <div class="flex items-center justify-between">
              <div>
                <p class="text-sm font-medium text-emerald-700 mb-1">Final Invoices</p>
                <p class="text-2xl font-bold text-emerald-800">{{ formatCurrency(state.statusAmounts.FINAL) }}</p>
                <div class="flex items-center mt-2">
                  <span class="text-sm text-emerald-600">{{ finalPercent }}% of total</span>
                  <div v-if="finalTrend" class="flex items-center text-sm ml-2">
                    <TrendingUp v-if="finalTrend > 0" class="w-4 h-4 text-emerald-500 mr-1" />
                    <TrendingDown v-else-if="finalTrend < 0" class="w-4 h-4 text-red-500 mr-1" />
                  </div>
                </div>
              </div>
              <div class="flex flex-col items-end">
                <div class="bg-emerald-100 p-3 rounded-lg mb-2">
                  <CheckCircle class="w-6 h-6 text-emerald-600" />
                </div>
                <span class="text-lg font-semibold text-emerald-700">{{ state.statusCounts.FINAL }}</span>
              </div>
            </div>
          </div>

          <!-- Displayed Card -->
          <div
            class="group bg-white border border-slate-200 rounded-xl p-6 hover:shadow-md transition-all duration-200 cursor-pointer"
            @click="showAll"
          >
            <div class="flex items-center justify-between">
              <div>
                <p class="text-sm font-medium text-slate-600 mb-1">Showing</p>
                <p class="text-2xl font-bold text-slate-900">{{ displayedCount }}</p>
                <div class="flex items-center mt-2">
                  <span class="text-sm text-slate-600">invoices</span>
                  <div v-if="displayedTrend" class="flex items-center text-sm ml-2">
                    <TrendingUp v-if="displayedTrend > 0" class="w-4 h-4 text-emerald-500 mr-1" />
                    <TrendingDown v-else-if="displayedTrend < 0" class="w-4 h-4 text-red-500 mr-1" />
                  </div>
                </div>
              </div>
              <div class="flex flex-col items-end">
                <div class="bg-slate-100 p-3 rounded-lg mb-2">
                  <Eye class="w-6 h-6 text-slate-600" />
                </div>
                <span class="text-lg font-semibold text-slate-700">{{ displayedCount }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Status Info -->
        <div class="flex items-center justify-between mt-6">
          <div v-if="state.updatedAt" class="text-sm text-slate-500">
            Last updated {{ state.updatedAt.toLocaleTimeString() }}
          </div>
          <div v-if="state.loading" class="flex items-center text-sm text-blue-600">
            <div class="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
            Loading...
          </div>
        </div>
      </div>
    </div>

    <!-- Main Content -->
    <div class="px-6 py-6 space-y-6">
      <!-- Error Message -->
      <div
        v-if="state.error"
        class="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700"
      >
        {{ state.error }}
      </div>

      <!-- Filters -->
      <div class="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <button
          class="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors"
          @click="toggleFilters"
          :aria-expanded="filtersOpen"
          aria-controls="invoice-filters"
        >
          <div class="flex items-center gap-3">
            <div class="p-2 bg-slate-100 rounded-lg">
              <Filter :class="['w-4 h-4', hasActiveFilters ? 'text-blue-600' : 'text-slate-600']" />
            </div>
            <div>
              <h3 class="font-medium text-slate-900">Filters</h3>
              <p class="text-sm text-slate-600">
                {{ hasActiveFilters ? `${activeFilterChips.length} active` : 'No filters applied' }}
              </p>
            </div>
          </div>
          <ChevronDown v-if="!filtersOpen" class="w-5 h-5 text-slate-400" />
          <ChevronUp v-else class="w-5 h-5 text-slate-400" />
        </button>

        <Transition name="slide">
          <div v-show="filtersOpen" id="invoice-filters" class="border-t border-slate-200">
            <!-- Filter Chips -->
            <div v-if="activeFilterChips.length" class="p-4 border-b border-slate-100">
              <div class="flex items-center gap-2 mb-2">
                <span class="text-sm font-medium text-slate-700">Active filters:</span>
              </div>
              <div class="flex flex-wrap gap-2">
                <span
                  v-for="chip in activeFilterChips"
                  :key="chip.key + chip.value"
                  class="inline-flex items-center gap-1 bg-slate-100 text-slate-700 rounded-full px-3 py-1.5 text-sm"
                >
                  {{ chip.label }}
                  <button
                    class="hover:text-slate-900 ml-1"
                    @click="removeFilter(chip.key, chip.value)"
                    aria-label="Remove filter"
                  >
                    <X class="w-3 h-3" />
                  </button>
                </span>
              </div>
            </div>

            <!-- Filter Controls -->
            <div class="p-4">
              <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                  <label class="flex items-center gap-2 text-sm font-medium text-slate-700 mb-3">
                    <CheckCircle class="w-4 h-4" />
                    Status
                  </label>
                  <div class="flex gap-2">
                    <button
                      v-for="s in ['DRAFT', 'FINAL']"
                      :key="s"
                      @click="toggleStatus(s)"
                      :aria-pressed="state.filters.status.includes(s)"
                      class="px-4 py-2 rounded-lg border text-sm font-medium transition-colors"
                      :class="state.filters.status.includes(s)
                        ? 'bg-blue-600 text-white border-blue-600 hover:bg-blue-700'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'"
                    >
                      {{ s }}
                    </button>
                  </div>
                </div>

                <div>
                  <label class="flex items-center gap-2 text-sm font-medium text-slate-700 mb-3">
                    <Users class="w-4 h-4" />
                    Customer
                  </label>
                  <div class="relative">
                    <Search class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      v-model="state.filters.customerName"
                      class="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
                      placeholder="Search customers..."
                    />
                  </div>
                </div>

                <div>
                  <label class="flex items-center gap-2 text-sm font-medium text-slate-700 mb-3">
                    <Building class="w-4 h-4" />
                    Facility
                  </label>
                  <div class="relative">
                    <Search class="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      v-model="state.filters.facility"
                      class="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
                      placeholder="Search facilities..."
                    />
                  </div>
                </div>

                <div>
                  <label class="flex items-center gap-2 text-sm font-medium text-slate-700 mb-3">
                    <Hash class="w-4 h-4" />
                    Draft Number
                  </label>
                  <input
                    type="text"
                    v-model="state.filters.draftNumber"
                    class="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
                    placeholder="Enter draft number..."
                  />
                </div>

                <div>
                  <label class="flex items-center gap-2 text-sm font-medium text-slate-700 mb-3">
                    <Hash class="w-4 h-4" />
                    Final Number
                  </label>
                  <input
                    type="text"
                    v-model="state.filters.finalNumber"
                    class="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
                    placeholder="Enter final number..."
                  />
                </div>

                <div>
                  <label class="flex items-center gap-2 text-sm font-medium text-slate-700 mb-3">
                    <Calendar class="w-4 h-4" />
                    Date Range
                  </label>
                  <div class="grid grid-cols-2 gap-2">
                    <input
                      type="date"
                      v-model="state.filters.createdDateFrom"
                      class="px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors text-sm"
                    />
                    <input
                      type="date"
                      v-model="state.filters.createdDateTo"
                      class="px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors text-sm"
                    />
                  </div>
                </div>
              </div>

              <div class="mt-6 flex justify-end">
                <button
                  class="flex items-center gap-2 px-4 py-2 text-sm text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
                  @click="clearFilters"
                  aria-label="Reset filters"
                >
                  <RotateCcw class="w-4 h-4" />
                  <span>Reset all filters</span>
                </button>
              </div>
            </div>
          </div>
        </Transition>
      </div>

      <!-- Table -->
      <div class="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-slate-200">
            <thead class="bg-slate-50">
              <tr>
                <th class="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider cursor-pointer hover:bg-slate-100 transition-colors" @click="toggleSort('draftNumber')">
                  <div class="flex items-center gap-1">
                    Draft #
                    <ArrowUp v-if="getSortDirection('draftNumber') === 'asc'" class="w-3 h-3" />
                    <ArrowDown v-else-if="getSortDirection('draftNumber') === 'desc'" class="w-3 h-3" />
                  </div>
                </th>
                <th class="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider cursor-pointer hover:bg-slate-100 transition-colors" @click="toggleSort('finalNumber')">
                  <div class="flex items-center gap-1">
                    Final #
                    <ArrowUp v-if="getSortDirection('finalNumber') === 'asc'" class="w-3 h-3" />
                    <ArrowDown v-else-if="getSortDirection('finalNumber') === 'desc'" class="w-3 h-3" />
                  </div>
                </th>
                <th class="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider cursor-pointer hover:bg-slate-100 transition-colors" @click="toggleSort('status')">
                  <div class="flex items-center gap-1">
                    Status
                    <ArrowUp v-if="getSortDirection('status') === 'asc'" class="w-3 h-3" />
                    <ArrowDown v-else-if="getSortDirection('status') === 'desc'" class="w-3 h-3" />
                  </div>
                </th>
                <th class="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider cursor-pointer hover:bg-slate-100 transition-colors" @click="toggleSort('customerName')">
                  <div class="flex items-center gap-1">
                    Customer
                    <ArrowUp v-if="getSortDirection('customerName') === 'asc'" class="w-3 h-3" />
                    <ArrowDown v-else-if="getSortDirection('customerName') === 'desc'" class="w-3 h-3" />
                  </div>
                </th>
                <th class="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider cursor-pointer hover:bg-slate-100 transition-colors" @click="toggleSort('facility')">
                  <div class="flex items-center gap-1">
                    Facility
                    <ArrowUp v-if="getSortDirection('facility') === 'asc'" class="w-3 h-3" />
                    <ArrowDown v-else-if="getSortDirection('facility') === 'desc'" class="w-3 h-3" />
                  </div>
                </th>
                <th class="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider cursor-pointer hover:bg-slate-100 transition-colors" @click="toggleSort('createdDate')">
                  <div class="flex items-center gap-1">
                    Created Date
                    <ArrowUp v-if="getSortDirection('createdDate') === 'asc'" class="w-3 h-3" />
                    <ArrowDown v-else-if="getSortDirection('createdDate') === 'desc'" class="w-3 h-3" />
                  </div>
                </th>
                <th class="px-6 py-4 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider cursor-pointer hover:bg-slate-100 transition-colors" @click="toggleSort('TotalAmount')">
                  <div class="flex items-center justify-end gap-1">
                    Total Amount
                    <ArrowUp v-if="getSortDirection('TotalAmount') === 'asc'" class="w-3 h-3" />
                    <ArrowDown v-else-if="getSortDirection('TotalAmount') === 'desc'" class="w-3 h-3" />
                  </div>
                </th>
                <th class="px-6 py-4 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider w-24">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-slate-100">
              <tr v-for="inv in state.items" :key="inv.id" class="hover:bg-slate-50 transition-colors">
                <td class="px-6 py-4 whitespace-nowrap">
                  <span class="text-sm font-medium text-slate-900" :title="inv.draftNumber || '—'">
                    {{ inv.draftNumber || '—' }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span class="text-sm font-medium text-slate-900" :title="inv.finalNumber || '—'">
                    {{ inv.finalNumber || '—' }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span :class="statusBadgeClass(inv.status)">{{ inv.status }}</span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <div class="max-w-xs">
                    <a v-if="inv.customerId" :href="`/customers/${inv.customerId}`" class="text-sm font-medium text-blue-600 hover:text-blue-700 hover:underline truncate block">
                      {{ inv.customerName }}
                    </a>
                    <span v-else class="text-sm text-slate-900 truncate block">{{ inv.customerName }}</span>
                  </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <div class="max-w-xs">
                    <a
                      v-if="inv.facilityId"
                      :href="`/facilities/${inv.facilityId}`"
                      class="text-sm font-medium text-blue-600 hover:text-blue-700 hover:underline truncate block"
                    >
                      {{ inv.facility }}
                    </a>
                    <span v-else class="text-sm text-slate-900 truncate block">{{ inv.facility || '—' }}</span>
                  </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                  {{ formatDate(inv.createdDate) }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-slate-900">
                  {{ formatCurrency(getRowAmount(inv)) }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <KebabMenu>
                    <template #trigger="{ toggle, refEl, isOpen }">
                      <button
                        class="text-slate-400 hover:text-slate-600 p-2 rounded-lg hover:bg-slate-100 transition-colors"
                        @click.stop="toggle()"
                        :ref="refEl"
                        aria-label="Invoice actions"
                        :aria-expanded="isOpen ? 'true' : 'false'"
                      >
                        <MoreVertical class="h-5 w-5" />
                      </button>
                    </template>
                    <template #content="{ close }">
                      <div class="py-1">
                        <button
                          class="flex items-center w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-100 gap-3"
                          role="menuitem"
                          aria-label="Preview invoice"
                          @click="openPreview(inv._id || inv.id); close()"
                        >
                          <Eye class="w-4 h-4" />
                          <span>Preview</span>
                        </button>
                        <button
                          v-if="inv.status === 'DRAFT'"
                          class="flex items-center w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-100 gap-3"
                          role="menuitem"
                          aria-label="Finalize invoice"
                          @click="openFinalize(inv); close()"
                        >
                          <FileText class="w-4 h-4" />
                          <span>Finalize</span>
                        </button>
                        <button
                          v-if="inv.status === 'DRAFT'"
                          class="flex items-center w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 gap-3"
                          role="menuitem"
                          aria-label="Delete invoice"
                          :disabled="isDeleting"
                          :class="isDeleting ? 'opacity-50 cursor-not-allowed' : ''"
                          @click="openDelete(inv); close()"
                          title="Delete draft (irreversible)"
                        >
                          <Trash2 class="w-4 h-4" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </template>
                  </KebabMenu>
                </td>
              </tr>
              
              <!-- Empty State -->
              <tr v-if="!state.loading && !state.items.length">
                <td colspan="8" class="text-center py-12">
                  <div class="flex flex-col items-center">
                    <div class="bg-slate-100 p-4 rounded-full mb-4">
                      <FileSearch class="w-8 h-8 text-slate-400" />
                    </div>
                    <h3 class="text-lg font-medium text-slate-900 mb-1">No invoices found</h3>
                    <p class="text-slate-600">Try adjusting your filters to see more results.</p>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Table Footer -->
        <div class="bg-slate-50 border-t border-slate-200 px-6 py-4">
          <div class="flex items-center justify-between">
            <div class="text-sm text-slate-600">
              <span class="font-medium">{{ displayedCount }}</span> invoices • 
              <span class="font-medium">{{ formatCurrency(displayedTotalAmount) }}</span> total
            </div>
            <div class="text-sm text-slate-600">
              Showing {{ ((state.page - 1) * state.pageSize) + 1 }}–{{ Math.min(state.page * state.pageSize, state.totalCount) }} of {{ state.totalCount }} invoices
            </div>
          </div>
        </div>
      </div>

      <!-- Pagination -->
      <div class="bg-white rounded-xl border border-slate-200 px-6 py-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center space-x-3">
            <button
              class="inline-flex items-center px-4 py-2 border border-slate-300 text-sm font-medium rounded-lg text-slate-700 bg-white hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              @click="changePage(-1)"
              :disabled="state.page === 1"
            >
              Previous
            </button>
            <span class="text-sm text-slate-700 px-4 py-2">
              Page <span class="font-medium">{{ state.page }}</span>
            </span>
            <button
              class="inline-flex items-center px-4 py-2 border border-slate-300 text-sm font-medium rounded-lg text-slate-700 bg-white hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              @click="changePage(1)"
              :disabled="state.page * state.pageSize >= state.totalCount"
            >
              Next
            </button>
          </div>
          <div class="flex items-center gap-2">
            <label class="text-sm text-slate-600">Show:</label>
            <select
              v-model.number="state.pageSize"
              class="border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-700 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            >
              <option :value="10">10</option>
              <option :value="25">25</option>
              <option :value="50">50</option>
              <option :value="100">100</option>
            </select>
          </div>
        </div>
      </div>
    </div>

    <!-- Toasts -->
    <Teleport to="body">
      <div
        v-if="toast"
        :class="[
          'fixed top-4 right-4 px-4 py-3 rounded-lg shadow-lg text-white z-50 transform transition-all duration-300',
          toast.type === 'error' ? 'bg-red-500' : 'bg-emerald-500',
        ]"
      >
        {{ toast.message }}
      </div>
    </Teleport>

    <!-- Finalize Modal -->
    <Teleport to="body">
      <div
        v-if="finalizeTarget"
        class="fixed inset-0 bg-slate-900 bg-opacity-50 flex items-center justify-center z-50 p-4"
      >
        <div class="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
          <div class="text-center">
            <div class="bg-emerald-100 p-3 rounded-full w-16 h-16 mx-auto mb-4">
              <CheckCircle class="w-10 h-10 text-emerald-600 mx-auto" />
            </div>
            <h3 class="text-lg font-semibold text-slate-900 mb-2">Finalize Invoice</h3>
            <p class="text-slate-600 mb-6">
              Are you sure you want to finalize invoice <span class="font-medium">{{ finalizeTarget.displayId }}</span>? This action cannot be undone.
            </p>
          </div>
          <div class="flex gap-3">
            <button
              @click="finalizeTarget = null"
              class="flex-1 px-4 py-2 border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              @click="finalizeInvoice"
              aria-label="Confirm finalize"
              class="flex-1 px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition-colors"
            >
              Finalize
            </button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Delete Modal -->
    <Teleport to="body">
      <div
        v-if="deleteTarget"
        class="fixed inset-0 bg-slate-900 bg-opacity-50 flex items-center justify-center z-50 p-4"
      >
        <div class="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
          <div class="text-center">
            <div class="bg-red-100 p-3 rounded-full w-16 h-16 mx-auto mb-4">
              <Trash2 class="w-10 h-10 text-red-600 mx-auto" />
            </div>
            <h3 class="text-lg font-semibold text-slate-900 mb-2">Delete Draft Invoice</h3>
            <p class="text-slate-600 mb-6">
              This will permanently delete draft invoice <span class="font-medium">{{ deleteTarget.displayId }}</span>. This action cannot be undone.
            </p>
          </div>
          <div class="flex gap-3">
            <button
              @click="deleteTarget = null"
              class="flex-1 px-4 py-2 border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              @click="deleteInvoice"
              aria-label="Confirm delete"
              :disabled="isDeleting"
              class="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {{ isDeleting ? 'Deleting...' : 'Delete' }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Invoice Preview Component -->
    <InvoicePreview
      v-if="previewInvoice"
      :invoice-id="previewInvoice.displayId"
      :preview-url="previewInvoice.url"
      :status="previewInvoice.status"
      :deleting="isDeleting"
      @close="closePreview"
      @finalize="finalizePreview"
      @delete="openDeleteFromPreview"
    />
  </div>
</template>

<style scoped>
.slide-enter-active,
.slide-leave-active {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}
.slide-enter-from,
.slide-leave-to {
  opacity: 0;
  transform: translateY(-8px);
}
</style>