<script setup lang="ts">
import { ref } from "vue";
import { VesselVisit } from "../types/vessel-visit";
import {
  FileDown,
  ArrowRight,
  Edit,
  ClipboardList,
  Lock,
  BarChart2,
  Calendar,
  Search,
  Filter,
  Plus,
  Eye,
  X,
} from "lucide-vue-next";
import AdvancedFilter from "./AdvancedFilter.vue";
import VesselVisitForm from "./VesselVisitForm.vue";

import { useVesselVisit } from "../composables/use.vessel-visit";
const { visits } = useVesselVisit();
const selectedVisit = ref<VesselVisit | null>(null);
const showModal = ref(false);
const modalType = ref<"preview" | "edit" | "event">("preview");
const showForm = ref(false);

const handleFilter = (filters: any[]) => {
  console.log("Applying filters:", filters);
  // Implement filter logic here
};

const formatDateTime = (dateString: string | null) => {
  if (!dateString) return "-";
  return new Date(dateString).toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

const getPhaseClasses = (phase: string) => {
  const baseClasses = "px-2 py-1 text-xs font-medium rounded-full";
  switch (phase) {
    case "Created":
      return `${baseClasses} bg-blue-100 text-blue-800`;
    case "Active":
      return `${baseClasses} bg-green-100 text-green-800`;
    case "Completed":
      return `${baseClasses} bg-gray-100 text-gray-800`;
    case "Canceled":
      return `${baseClasses} bg-red-100 text-red-800`;
    default:
      return baseClasses;
  }
};

const handleNewVisit = () => {
  showForm.value = true;
};

const handleFormSubmit = (formData: Omit<VesselVisit, "id">) => {
  const newVisit: VesselVisit = {
    ...formData,
    id: (visits.value.length + 1).toString(),
    ata: null,
    atd: null,
    startWorkTime: null,
    endWorkTime: null,
  };

  visits.value.push(newVisit);
  showForm.value = false;
};

const handleFormCancel = () => {
  showForm.value = false;
};

const handleAction = (type: "preview" | "edit" | "event", visit: VesselVisit) => {
  selectedVisit.value = visit;
  modalType.value = type;
  showModal.value = true;
};
</script>

<template>
  <div>
    <!-- List View -->
    <div v-if="!showForm" class="bg-white shadow rounded-lg">
      <!-- Header -->
      <div class="px-6 py-4 border-b border-gray-200">
        <div class="flex justify-between items-center">
          <h2 class="text-lg font-semibold text-gray-900">Vessel Visits</h2>
          <div class="flex space-x-4">
            <div class="relative">
              <input
                type="text"
                placeholder="Search visits..."
                class="w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
              <Search class="h-5 w-5 text-gray-400 absolute left-3 top-2.5" />
            </div>
            <button
              @click="handleNewVisit"
              class="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
            >
              <Plus class="h-4 w-4 mr-2" />
              New Visit
            </button>
          </div>
        </div>
      </div>

      <!-- Actions Toolbar -->
      <div class="p-4 border-b border-gray-200">
        <div class="flex flex-wrap gap-2">
          <button
            class="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <FileDown class="mr-2" :size="18" />
            Export
          </button>
          <button
            class="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <ArrowRight class="mr-2" :size="18" />
            Advance Visit
          </button>
          <button
            class="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <Edit class="mr-2" :size="18" />
            Edit Details
          </button>
          <button
            class="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <ClipboardList class="mr-2" :size="18" />
            Record Event
          </button>
          <button
            class="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <Lock class="mr-2" :size="18" />
            Update Holds
          </button>
          <button
            class="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <BarChart2 class="mr-2" :size="18" />
            Statistics
          </button>
          <button
            class="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <Calendar class="mr-2" :size="18" />
            Extract Events
          </button>
        </div>
      </div>

      <!-- Advanced Filter -->
      <AdvancedFilter type="vessels" @filter="handleFilter" />

      <!-- Table -->
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th
                v-for="header in [
                  'Vessel Name',
                  'Visit Ref',
                  'Phase',
                  'Service',
                  'POL/POD',
                  'ETA/ATA',
                  'ETD/ATD',
                  'Final Dest.',
                  'Actions',
                ]"
                :key="header"
                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                {{ header }}
              </th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <tr v-for="visit in visits" :key="visit.id" class="hover:bg-gray-50">
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm font-medium text-gray-900">
                  {{ visit.vesselName }}
                </div>
                <div class="text-sm text-gray-500">{{ visit.vesselId }}</div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {{ visit.visitReference }}
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <span :class="getPhaseClasses(visit.phase)">
                  {{ visit.phase }}
                </span>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900">{{ visit.service }}</div>
                <div class="text-sm text-gray-500">{{ visit.serviceName }}</div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900">POL: {{ visit.pol }}</div>
                <div class="text-sm text-gray-500">POD: {{ visit.pod }}</div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900">
                  ETA: {{ formatDateTime(visit.eta) }}
                </div>
                <div class="text-sm text-gray-500">
                  ATA: {{ formatDateTime(visit.ata) }}
                </div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900">
                  ETD: {{ formatDateTime(visit.etd) }}
                </div>
                <div class="text-sm text-gray-500">
                  ATD: {{ formatDateTime(visit.atd) }}
                </div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {{ visit.finalDestination }}
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <button
                  @click="handleAction('preview', visit)"
                  class="text-blue-600 hover:text-blue-900 mr-3"
                >
                  <Eye class="h-5 w-5" />
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Form View -->
    <VesselVisitForm v-else @submit="handleFormSubmit" @cancel="handleFormCancel" />

    <!-- Preview Modal -->
    <Teleport to="body">
      <div
        v-if="showModal && selectedVisit"
        class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50"
      >
        <div class="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden">
          <div
            class="px-6 py-4 border-b border-gray-200 flex justify-between items-center"
          >
            <h3 class="text-lg font-medium text-gray-900">
              {{ selectedVisit.vesselName }} - {{ selectedVisit.visitReference }}
            </h3>
            <button @click="showModal = false" class="text-gray-400 hover:text-gray-500">
              <X class="h-6 w-6" />
            </button>
          </div>

          <div class="px-6 py-4 overflow-y-auto">
            <div class="grid grid-cols-2 gap-4">
              <template v-for="(value, key) in selectedVisit" :key="key">
                <div v-if="key !== 'id'" class="col-span-1">
                  <label class="block text-sm font-medium text-gray-700">
                    {{ key.replace(/([A-Z])/g, " $1").trim() }}
                  </label>
                  <p class="mt-1 text-sm text-gray-900">
                    {{
                      typeof value === "string" && value.includes("T")
                        ? formatDateTime(value)
                        : value || "-"
                    }}
                  </p>
                </div>
              </template>
            </div>
          </div>

          <div class="px-6 py-4 border-t border-gray-200 flex justify-end space-x-3">
            <button
              @click="showModal = false"
              class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>
