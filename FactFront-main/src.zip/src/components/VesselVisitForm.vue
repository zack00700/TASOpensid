<script setup lang="ts">
import { X } from "lucide-vue-next";
import { VesselVisit } from "../types/vessel-visit";

import { useVesselVisit } from "../composables/use.vessel-visit";

const { formData, validateForm, errors, addVesselVisit } = useVesselVisit();

defineProps<{
  editMode?: boolean;
  initialData?: VesselVisit;
}>();

const emit = defineEmits<{
  (e: "submit", data: VesselVisit): void;
  (e: "cancel"): void;
}>();

const handleSubmit = () => {
  if (!validateForm()) {
    return;
  }

  addVesselVisit();
  emit("submit", formData.value);
};

const facilities = ["Terminal A", "Terminal B", "Terminal C"];
const services = [
  { code: "WCCA", name: "West Coast Central America" },
  { code: "ECSA", name: "East Coast South America" },
  { code: "MED", name: "Mediterranean Service" },
];

const getInputClasses = (fieldName: keyof VesselVisit) => {
  return {
    "mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500": true,
    "border-red-300": errors.value[fieldName],
  };
};
</script>

<template>
  <div class="bg-white shadow rounded-lg">
    <div class="px-6 py-4 border-b border-gray-200">
      <div class="flex justify-between items-center">
        <h2 class="text-lg font-semibold text-gray-900">
          {{ editMode ? "Edit Vessel Visit" : "New Vessel Visit" }}
        </h2>
        <button @click="emit('cancel')" class="text-gray-400 hover:text-gray-500">
          <X class="h-6 w-6" />
        </button>
      </div>
    </div>

    <form @submit.prevent="handleSubmit" class="p-6 space-y-6">
      <!-- Vessel Information -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Vessel Information</h3>
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <label class="block text-sm font-medium text-gray-700">
              Vessel Name <span class="text-red-500">*</span>
            </label>
            <input
              v-model="formData.vesselName"
              type="text"
              :class="getInputClasses('vesselName')"
            />
            <p v-if="errors.vesselName" class="mt-1 text-sm text-red-600">
              {{ errors.vesselName }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Vessel ID <span class="text-red-500">*</span>
            </label>
            <input
              v-model="formData.vesselId"
              type="text"
              :class="getInputClasses('vesselId')"
            />
            <p v-if="errors.vesselId" class="mt-1 text-sm text-red-600">
              {{ errors.vesselId }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Service <span class="text-red-500">*</span>
            </label>
            <select
              v-model="formData.service"
              :class="getInputClasses('service')"
              @change="
                formData.serviceName =
                  services.find((s) => s.code === formData.service)?.name || ''
              "
            >
              <option value="">Select service</option>
              <option
                v-for="service in services"
                :key="service.code"
                :value="service.code"
              >
                {{ service.code }} - {{ service.name }}
              </option>
            </select>
            <p v-if="errors.service" class="mt-1 text-sm text-red-600">
              {{ errors.service }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700"> Facility </label>
            <select v-model="formData.facility" :class="getInputClasses('facility')">
              <option value="">Select facility</option>
              <option v-for="facility in facilities" :key="facility" :value="facility">
                {{ facility }}
              </option>
            </select>
          </div>
        </div>
      </div>

      <!-- Port Information -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Port Information</h3>
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-3">
          <div>
            <label class="block text-sm font-medium text-gray-700">
              Port of Loading (POL) <span class="text-red-500">*</span>
            </label>
            <input
              v-model="formData.pol"
              type="text"
              placeholder="UNLOCODE"
              :class="getInputClasses('pol')"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Port of Discharge (POD) <span class="text-red-500">*</span>
            </label>
            <input
              v-model="formData.pod"
              type="text"
              placeholder="UNLOCODE"
              :class="getInputClasses('pod')"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Final Destination
            </label>
            <input
              v-model="formData.finalDestination"
              type="text"
              placeholder="UNLOCODE"
              :class="getInputClasses('finalDestination')"
            />
          </div>
        </div>
      </div>

      <!-- Schedule Information -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Schedule Information</h3>
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <label class="block text-sm font-medium text-gray-700">
              ETA <span class="text-red-500">*</span>
            </label>
            <input
              v-model="formData.eta"
              type="datetime-local"
              :class="getInputClasses('eta')"
            />
            <p v-if="errors.eta" class="mt-1 text-sm text-red-600">
              {{ errors.eta }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              ETD <span class="text-red-500">*</span>
            </label>
            <input
              v-model="formData.etd"
              type="datetime-local"
              :min="formData.eta"
              :class="getInputClasses('etd')"
            />
            <p v-if="errors.etd" class="mt-1 text-sm text-red-600">
              {{ errors.etd }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700"> ATA </label>
            <input
              v-model="formData.ata"
              type="datetime-local"
              :class="getInputClasses('ata')"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700"> ATD </label>
            <input
              v-model="formData.atd"
              type="datetime-local"
              :class="getInputClasses('atd')"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700"> Begin Receive </label>
            <input
              v-model="formData.beginReceive"
              type="datetime-local"
              :class="getInputClasses('beginReceive')"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700"> Empty Pickup </label>
            <input
              v-model="formData.emptyPickup"
              type="datetime-local"
              :class="getInputClasses('emptyPickup')"
            />
          </div>
        </div>
      </div>

      <!-- Cut-off Times -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Cut-off Times</h3>
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-3">
          <div>
            <label class="block text-sm font-medium text-gray-700">
              Dry Cargo Cut-off
            </label>
            <input
              v-model="formData.dryCutoff"
              type="datetime-local"
              :class="getInputClasses('dryCutoff')"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Reefer Cut-off
            </label>
            <input
              v-model="formData.reeferCutoff"
              type="datetime-local"
              :class="getInputClasses('reeferCutoff')"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Hazardous Cut-off
            </label>
            <input
              v-model="formData.hazCutoff"
              type="datetime-local"
              :class="getInputClasses('hazCutoff')"
            />
          </div>
        </div>
      </div>

      <!-- Voyage Information -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Voyage Information</h3>
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <label class="block text-sm font-medium text-gray-700">
              Inbound Voyage
            </label>
            <input
              v-model="formData.inboundVoyage"
              type="text"
              :class="getInputClasses('inboundVoyage')"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Outbound Voyage
            </label>
            <input
              v-model="formData.outboundVoyage"
              type="text"
              :class="getInputClasses('outboundVoyage')"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Inbound Captain
            </label>
            <input
              v-model="formData.inboundCaptain"
              type="text"
              :class="getInputClasses('inboundCaptain')"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Outbound Captain
            </label>
            <input
              v-model="formData.outboundCaptain"
              type="text"
              :class="getInputClasses('outboundCaptain')"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700"> Line Operator </label>
            <input
              v-model="formData.lineOperator"
              type="text"
              :class="getInputClasses('lineOperator')"
            />
          </div>
        </div>
      </div>

      <!-- Additional Information -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Additional Information</h3>
        <div>
          <label class="block text-sm font-medium text-gray-700"> Notes </label>
          <textarea
            v-model="formData.notes"
            rows="3"
            :class="getInputClasses('notes')"
          ></textarea>
        </div>
      </div>

      <!-- Form Actions -->
      <div class="flex justify-end space-x-3">
        <button
          type="button"
          @click="emit('cancel')"
          class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
        >
          Cancel
        </button>
        <button
          type="submit"
          class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          {{ editMode ? "Save Changes" : "Create Visit" }}
        </button>
      </div>
    </form>
  </div>
</template>
