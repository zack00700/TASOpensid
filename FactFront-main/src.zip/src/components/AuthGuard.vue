<script setup lang="ts">
import { computed } from 'vue';
import { useAuth } from '../composables/useAuth';
import { ShieldAlert, Lock } from 'lucide-vue-next';

interface Props {
  requireRole?: string;
  fallbackMessage?: string;
  showIcon?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  requireRole: '',
  fallbackMessage: 'Vous n\'avez pas les permissions nécessaires pour accéder à cette section.',
  showIcon: true
});

const { isAuthenticated, userRole, hasRole, isAdmin, requireAuth } = useAuth();

// Vérifier l'authentification au montage
requireAuth();

// Vérifier les permissions de rôle
const hasPermission = computed(() => {
  if (!isAuthenticated.value) return false;
  if (!props.requireRole) return true; // Pas de rôle requis
  
  // Vérifications spéciales pour les rôles connus
  if (props.requireRole === 'admin') {
    return isAdmin();
  }
  
  // Vérification générique
  return hasRole(props.requireRole) || userRole.value === props.requireRole;
});

const canShowContent = computed(() => isAuthenticated.value && hasPermission.value);
</script>

<template>
  <!-- Contenu autorisé -->
  <div v-if="canShowContent">
    <slot />
  </div>
  
  <!-- Message d'accès refusé -->
  <div v-else-if="isAuthenticated && !hasPermission" class="flex items-center justify-center min-h-[400px]">
    <div class="text-center max-w-md mx-auto p-6">
      <div class="bg-amber-50 border border-amber-200 rounded-lg p-6">
        <div class="flex justify-center mb-4" v-if="showIcon">
          <div class="flex-shrink-0">
            <ShieldAlert class="h-12 w-12 text-amber-500" />
          </div>
        </div>
        
        <div>
          <h3 class="text-lg font-medium text-amber-800 mb-2">
            Accès restreint
          </h3>
          
          <p class="text-sm text-amber-700 mb-4">
            {{ fallbackMessage }}
          </p>
          
          <div class="bg-amber-100 rounded-md p-3">
            <div class="flex items-center text-xs text-amber-700">
              <Lock class="h-4 w-4 mr-2" />
              <div class="text-left">
                <div><strong>Rôle requis:</strong> {{ requireRole || 'Aucun rôle spécifique' }}</div>
                <div><strong>Votre rôle:</strong> {{ userRole || 'Non défini' }}</div>
              </div>
            </div>
          </div>
          
          <p class="text-xs text-amber-600 mt-3">
            Contactez un administrateur si vous pensez que c'est une erreur.
          </p>
        </div>
      </div>
    </div>
  </div>
  
  <!-- État de chargement ou non authentifié -->
  <div v-else class="flex items-center justify-center min-h-[400px]">
    <div class="text-center">
      <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
      <p class="text-sm text-gray-600">Vérification des permissions...</p>
    </div>
  </div>
</template>