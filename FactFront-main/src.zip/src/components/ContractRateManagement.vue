<script setup lang="ts">
import { ref, computed, watch } from "vue";
import { v4 as uuidv4 } from "uuid";
import {
  Plus,
  Trash2,
  DollarSign,
  Star,
  AlertCircle,
  X,
} from "lucide-vue-next";

interface Rate {
  id: string;
  amount: number;
  currency: string;
  defaultRate: boolean;
  priority: number;

  // Quantity fields
  startQuantity?: number;
  endQuantity?: number;
  unitOfMeasurement?: string;

  // Date fields
  startDate?: string;
  endDate?: string;
}

const props = defineProps<{
  contractId?: string;
  calculationType?: string;
  rates?: Rate[];
}>();

const emit = defineEmits<{
  (e: "update:rates", rates: Rate[]): void;
}>();

const rates = ref<Rate[]>([]);

watch(
  () => props.rates,
  (newRates) => {
    rates.value = [...(newRates || [])];
  },
  { immediate: true }
);
const showAddRate = ref(false);
const editingRate = ref<Rate | null>(null);
const showDeleteConfirm = ref(false);
const rateToDelete = ref<Rate | null>(null);

const currencies = ["USD", "EUR", "GBP"];
const unitsOfMeasurement = ["Items", "Hours", "Days", "Kilograms", "TEU", "Cubic Meters"];

const newRate = ref<Rate>({
  id: "",
  amount: 0,
  currency: "USD",
  defaultRate: false,
  priority: 0,
});

const errors = ref<Record<string, string>>({});

const sortedRates = computed(() => {
  return [...rates.value].sort((a, b) => {
    if (a.defaultRate !== b.defaultRate) {
      return a.defaultRate ? -1 : 1;
    }
    return b.priority - a.priority;
  });
});

const validateRate = (rate: Rate): boolean => {
  errors.value = {};
  let isValid = true;

  if (rate.amount <= 0) {
    errors.value.amount = "Amount must be greater than 0";
    isValid = false;
  }

  if (rate.startQuantity === undefined || rate.startQuantity < 0) {
    errors.value.startQuantity = "Start quantity is required and must be >= 0";
    isValid = false;
  }
  if (rate.endQuantity === undefined || rate.endQuantity <= rate.startQuantity!) {
    errors.value.endQuantity = "End quantity must be greater than start quantity";
    isValid = false;
  }
  if (!rate.unitOfMeasurement) {
    errors.value.unitOfMeasurement = "Unit of measurement is required";
    isValid = false;
  }

  if (!rate.startDate) {
    errors.value.startDate = "Start date is required";
    isValid = false;
  }
  if (!rate.endDate) {
    errors.value.endDate = "End date is required";
    isValid = false;
  }
  if (
    rate.startDate &&
    rate.endDate &&
    new Date(rate.endDate) <= new Date(rate.startDate)
  ) {
    errors.value.endDate = "End date must be after start date";
    isValid = false;
  }

  return isValid;
};

const checkOverlap = (rate: Rate): boolean => {
  return rates.value.some((r) => {
    if (r.id === rate.id) return false;

    const quantityOverlap =
      rate.startQuantity !== undefined &&
      rate.endQuantity !== undefined &&
      r.startQuantity !== undefined &&
      r.endQuantity !== undefined &&
      ((rate.startQuantity >= r.startQuantity &&
        rate.startQuantity <= r.endQuantity) ||
        (rate.endQuantity >= r.startQuantity &&
          rate.endQuantity <= r.endQuantity));

    const dateOverlap =
      rate.startDate &&
      rate.endDate &&
      r.startDate &&
      r.endDate &&
      ((new Date(rate.startDate) >= new Date(r.startDate) &&
        new Date(rate.startDate) <= new Date(r.endDate)) ||
        (new Date(rate.endDate) >= new Date(r.startDate) &&
          new Date(rate.endDate) <= new Date(r.endDate)));

    return quantityOverlap || dateOverlap;
  });
};

const handleAddRate = () => {
  newRate.value = {
    id: "",
    amount: 0,
    currency: "USD",
    defaultRate: false,
    priority: rates.value.length,
  };
  showAddRate.value = true;
};

const handleSaveRate = () => {
  if (!validateRate(newRate.value)) {
    return;
  }

  if (checkOverlap(newRate.value)) {
    errors.value.overlap = "This rate overlaps with an existing rate";
    return;
  }

  const rateToSave = {
    ...newRate.value,
    id: editingRate.value?.id || uuidv4(),
  };

  if (editingRate.value) {
    const index = rates.value.findIndex((r) => r.id === editingRate.value!.id);
    rates.value[index] = rateToSave;
  } else {
    rates.value.push(rateToSave);
  }

  emit("update:rates", rates.value);
  showAddRate.value = false;
  editingRate.value = null;
};

const handleEditRate = (rate: Rate) => {
  editingRate.value = rate;
  newRate.value = { ...rate };
  showAddRate.value = true;
};

const handleDeleteRate = (rate: Rate) => {
  rateToDelete.value = rate;
  showDeleteConfirm.value = true;
};

const confirmDelete = () => {
  if (rateToDelete.value) {
    rates.value = rates.value.filter((r) => r.id !== rateToDelete.value!.id);
    emit("update:rates", rates.value);
    showDeleteConfirm.value = false;
    rateToDelete.value = null;
  }
};

const getInputClasses = (fieldName: string) => {
  return {
    "mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500": true,
    "border-red-300": errors.value[fieldName],
  };
};
</script>

<template>
  <div class="space-y-6">
    <div class="flex justify-between items-center">
      <h3 class="text-lg font-medium text-gray-900">Rate Management</h3>
      <button
        type="button"
        @click="handleAddRate"
        class="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
      >
        <Plus class="h-4 w-4 mr-2" />
        Add Rate
      </button>
    </div>

    <!-- Rate List -->
    <div v-if="rates.length > 0" class="space-y-4">
      <div
        v-for="rate in sortedRates"
        :key="rate.id"
        class="bg-white border rounded-lg shadow-sm hover:shadow-md transition-shadow"
      >
        <div class="p-4">
          <div class="flex justify-between items-start">
            <div class="flex items-center space-x-2">
              <Star v-if="rate.defaultRate" class="h-5 w-5 text-yellow-400" />
              <div>
                <h4 class="text-sm font-medium text-gray-900">
                  {{ rate.startQuantity }} - {{ rate.endQuantity }}
                  {{ rate.unitOfMeasurement }},
                  {{ rate.startDate
                    ? new Date(rate.startDate).toLocaleDateString()
                    : "" }}
                  -
                  {{ rate.endDate
                    ? new Date(rate.endDate).toLocaleDateString()
                    : "" }}
                </h4>
                <p class="text-sm text-gray-500">
                  {{ rate.amount }} {{ rate.currency }} per
                  {{ rate.unitOfMeasurement }}
                </p>
              </div>
            </div>
            <div class="flex space-x-2">
              <button
                type="button"
                @click="handleEditRate(rate)"
                class="text-blue-600 hover:text-blue-900"
              >
                Edit
              </button>
              <button
                type="button"
                @click="handleDeleteRate(rate)"
                class="text-red-600 hover:text-red-900"
              >
                <Trash2 class="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-else class="text-center py-6 bg-gray-50 rounded-lg">
      <DollarSign class="mx-auto h-12 w-12 text-gray-400" />
      <h3 class="mt-2 text-sm font-medium text-gray-900">No rates</h3>
      <p class="mt-1 text-sm text-gray-500">Get started by adding a new rate.</p>
    </div>

    <!-- Add/Edit Rate Modal -->
    <Teleport to="body">
      <div
        v-if="showAddRate"
        class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50"
      >
        <div class="bg-white rounded-lg p-6 max-w-2xl w-full">
          <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium text-gray-900">
              {{ editingRate ? "Edit Rate" : "Add New Rate" }}
            </h3>
            <button
              @click="showAddRate = false"
              class="text-gray-400 hover:text-gray-500"
            >
              <X class="h-6 w-6" />
            </button>
          </div>

          <form @submit.prevent="handleSaveRate" class="space-y-6">
            <!-- Rate Amount -->
            <div class="grid grid-cols-2 gap-4">
              <div>
                <label class="block text-sm font-medium text-gray-700"> Amount </label>
                <div class="mt-1 relative rounded-md shadow-sm">
                  <div
                    class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"
                  >
                    <DollarSign class="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    v-model.number="newRate.amount"
                    type="number"
                    step="0.01"
                    class="pl-10 block w-full rounded-md border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <p v-if="errors.amount" class="mt-1 text-sm text-red-600">
                  {{ errors.amount }}
                </p>
              </div>

              <div>
                <label class="block text-sm font-medium text-gray-700"> Currency </label>
                <select v-model="newRate.currency" :class="getInputClasses('currency')">
                  <option
                    v-for="currency in currencies"
                    :key="currency"
                    :value="currency"
                  >
                    {{ currency }}
                  </option>
                </select>
              </div>
            </div>

            <!-- Quantity Fields -->
            <div class="grid grid-cols-2 gap-4">
              <div>
                <label class="block text-sm font-medium text-gray-700">
                  Start Quantity
                </label>
                <input
                  v-model.number="newRate.startQuantity"
                  type="number"
                  min="0"
                  :class="getInputClasses('startQuantity')"
                />
                <p v-if="errors.startQuantity" class="mt-1 text-sm text-red-600">
                  {{ errors.startQuantity }}
                </p>
              </div>

              <div>
                <label class="block text-sm font-medium text-gray-700">
                  End Quantity
                </label>
                <input
                  v-model.number="newRate.endQuantity"
                  type="number"
                  :min="newRate.startQuantity"
                  :class="getInputClasses('endQuantity')"
                />
                <p v-if="errors.endQuantity" class="mt-1 text-sm text-red-600">
                  {{ errors.endQuantity }}
                </p>
              </div>
            </div>

            <div>
              <label class="block text-sm font-medium text-gray-700">
                Unit of Measurement
              </label>
              <select
                v-model="newRate.unitOfMeasurement"
                :class="getInputClasses('unitOfMeasurement')"
              >
                <option value="">Select unit</option>
                <option v-for="unit in unitsOfMeasurement" :key="unit" :value="unit">
                  {{ unit }}
                </option>
              </select>
              <p v-if="errors.unitOfMeasurement" class="mt-1 text-sm text-red-600">
                {{ errors.unitOfMeasurement }}
              </p>
            </div>

            <!-- Date Fields -->
            <div class="grid grid-cols-2 gap-4">
              <div>
                <label class="block text-sm font-medium text-gray-700">
                  Start Date
                </label>
                <input
                  v-model="newRate.startDate"
                  type="date"
                  :class="getInputClasses('startDate')"
                />
                <p v-if="errors.startDate" class="mt-1 text-sm text-red-600">
                  {{ errors.startDate }}
                </p>
              </div>

              <div>
                <label class="block text-sm font-medium text-gray-700">
                  End Date
                </label>
                <input
                  v-model="newRate.endDate"
                  type="date"
                  :min="newRate.startDate"
                  :class="getInputClasses('endDate')"
                />
                <p v-if="errors.endDate" class="mt-1 text-sm text-red-600">
                  {{ errors.endDate }}
                </p>
              </div>
            </div>

            <!-- Rate Priority -->
            <div class="flex items-center space-x-4">
              <div class="flex items-center">
                <input
                  v-model="newRate.defaultRate"
                  type="checkbox"
                  class="h-4 w-4 text-blue-600 border-gray-300 rounded"
                />
                <label class="ml-2 text-sm text-gray-700"> Set as default rate </label>
              </div>

              <div class="flex items-center">
                <label class="text-sm text-gray-700 mr-2">Priority:</label>
                <input
                  v-model.number="newRate.priority"
                  type="number"
                  min="0"
                  class="w-20 rounded-md border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>

            <div v-if="errors.overlap" class="rounded-md bg-red-50 p-4">
              <div class="flex">
                <AlertCircle class="h-5 w-5 text-red-400" />
                <div class="ml-3">
                  <h3 class="text-sm font-medium text-red-800">Rate Overlap Detected</h3>
                  <div class="mt-2 text-sm text-red-700">
                    <p>{{ errors.overlap }}</p>
                  </div>
                </div>
              </div>
            </div>

            <div class="flex justify-end space-x-3">
              <button
                type="button"
                @click="showAddRate = false"
                class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
              >
                {{ editingRate ? "Save Changes" : "Add Rate" }}
              </button>
            </div>
          </form>
        </div>
      </div>
    </Teleport>

    <!-- Delete Confirmation Modal -->
    <Teleport to="body">
      <div
        v-if="showDeleteConfirm"
        class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50"
      >
        <div class="bg-white rounded-lg p-6 max-w-md w-full">
          <div class="text-center">
            <AlertCircle class="mx-auto h-12 w-12 text-red-500" />
            <h3 class="mt-4 text-lg font-medium text-gray-900">Delete Rate</h3>
            <p class="mt-2 text-sm text-gray-500">
              Are you sure you want to delete this rate? This action cannot be undone.
            </p>
          </div>
          <div class="mt-6 flex justify-end space-x-3">
            <button
              @click="showDeleteConfirm = false"
              class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              @click="confirmDelete"
              class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>
