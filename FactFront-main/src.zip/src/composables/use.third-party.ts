import { inject, ref, onMounted, watch } from "vue";
import { ThirdPartyUser } from "../types/third-party";

/**
 * Ensure a single shared instance across components so that updates
 * performed in one component propagate to all others.
 */
let sharedState: ReturnType<typeof createThirdPartyStore> | null = null;

export function useThirdParty() {
    if (!sharedState) {
        const $axios = inject('$axios');
        sharedState = createThirdPartyStore($axios);
    }
    return sharedState;
}

function createThirdPartyStore($axios: any) {
    const formData = ref<Omit<ThirdPartyUser, 'id' | 'createdAt' | 'updatedAt'>>({
        version: 0,
        fullName: '',
        jobTitle: '',
        contactNumber: '',
        email: '',
        companyName: '',
        companyAddress: '',
        industryType: '',
        companyContactPerson: '',
        companyContactEmail: '',
        accessType: '',
        modulesRequired: [],
        identificationType: '',
        identificationNumber: ''
    });

    const errors = ref<Record<string, string>>({});
    const users = ref<ThirdPartyUser[]>([]);
    const pendingPatch = ref<any[]>([]);
    const originalData = ref<ThirdPartyUser | null>(null);
    const currentViewId = ref<string | null>(null);

    const validateForm = (currentId?: string) => {
        errors.value = {};
        let isValid = true;

        // Personal Information Validation
        if (!formData.value.fullName) {
            errors.value.fullName = "Full name is required";
            isValid = false;
        } else if (users.value.some(u => u.fullName === formData.value.fullName && u.id !== currentId)) {
            errors.value.fullName = "Full name must be unique";
            isValid = false;
        }

        if (!formData.value.contactNumber) {
            errors.value.contactNumber = "Contact number is required";
            isValid = false;
        }

        if (!formData.value.email) {
            errors.value.email = "Email is required";
            isValid = false;
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.value.email)) {
            errors.value.email = "Invalid email format";
            isValid = false;
        }

        // Company Information Validation
        if (!formData.value.companyName) {
            errors.value.companyName = "Company name is required";
            isValid = false;
        }

        if (!formData.value.companyAddress) {
            errors.value.companyAddress = "Company address is required";
            isValid = false;
        }

        if (formData.value.companyContactPerson && !formData.value.companyContactEmail) {
            errors.value.companyContactEmail =
            "Contact email is required when contact person is specified";
            isValid = false;
        }

        // Access Information Validation
        if (!formData.value.accessType) {
            errors.value.accessType = "Access type is required";
            isValid = false;
        }

        if (formData.value.modulesRequired.length === 0) {
            errors.value.modulesRequired = "At least one module must be selected";
            isValid = false;
        }

        // Security and Compliance Validation
        if (!formData.value.identificationType) {
            errors.value.identificationType = "Identification type is required";
            isValid = false;
        }

        if (!formData.value.identificationNumber) {
            errors.value.identificationNumber = "Identification number is required";
            isValid = false;
        }

        return isValid;
    };

    async function addThirdPartyUser() {
        try {
            await $axios.post('/third-party', formData.value)
            await fetchThirdPartyUsers();
        } catch (exception) {
            console.error(exception)
        }
    }

    async function updateThirdPartyUser(id: string) {
        try {
            await $axios.put(`/third-party/${id}`, formData.value)
            await fetchThirdPartyUsers();
        } catch (exception) {
            console.error(exception)
        }
    }

    function buildPatch(original: ThirdPartyUser, updated: Omit<ThirdPartyUser, 'id'>) {
        const ops: any[] = [];
        Object.keys(updated).forEach((key) => {
            const k = key as keyof ThirdPartyUser;
            if (updated[k] !== (original as any)[k]) {
                ops.push({ op: 'replace', path: `/${k}`, value: (updated as any)[k] });
            }
        });
        return ops;
    }

    async function patchThirdPartyUser(id: string, version: number) {
        try {
            await $axios.patch(
                `/third-party/${id}`,
                pendingPatch.value,
                {
                    headers: {
                        'Content-Type': 'application/json-patch+json',
                        'If-Match': version.toString(),
                    },
                },
            );
            pendingPatch.value = [];
            await fetchThirdPartyUsers();
            originalData.value = { ...formData.value, id } as ThirdPartyUser;
        } catch (exception: any) {
            if (exception.response && exception.response.status === 409) {
                alert('Conflit – recharger ou fusionner');
            } else {
                console.error(exception);
            }
        }
    }

    async function validateThirdPartyUser() {
        try {
            await $axios.post('/third-party/validate', formData.value)
        } catch (exception) {
            console.error(exception)
        }
    }

    watch(
        formData,
        (newVal) => {
            if (originalData.value) {
                pendingPatch.value = buildPatch(originalData.value, newVal);
            }
        },
        { deep: true }
    );

    async function fetchThirdPartyUsers() {
        try {
            // Query the local API for third-party users
            const response = await $axios.get('/third-party');
            users.value = response.data;
        } catch (exception) {
            console.error('Failed to fetch third-party users:', exception);
        }
    }
    
    onMounted(() => {
        fetchThirdPartyUsers();
    });
    
    return {
        formData,
        errors,
        validateForm,
        addThirdPartyUser,
        updateThirdPartyUser,
        patchThirdPartyUser,
        validateThirdPartyUser,
        fetchThirdPartyUsers,
        pendingPatch,
        users,
        originalData,
        currentViewId
    }
}