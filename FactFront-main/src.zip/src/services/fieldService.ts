import api from '../plugin/axios';
import type { Field } from '../types/field';

export interface LanguagePayload {
  code: string;
}

export interface TranslationPayload {
  value: string;
}

export const getFields = async (): Promise<Field[]> => {
  const response = await api.get('/fields');
  return response.data;
};

export const addLanguage = async (payload: LanguagePayload): Promise<void> => {
  await api.post('/languages', payload);
};

export const updateTranslation = async (
  fieldKey: string,
  lang: string,
  value: string,
): Promise<void> => {
  await api.put(`/fields/${fieldKey}/translations/${lang}`, { value });
};

export default {
  getFields,
  addLanguage,
  updateTranslation,
};
