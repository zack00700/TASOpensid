<script setup lang="ts">
import { ref, onMounted } from 'vue';
import {
  Search,
  Filter,
  Download,
  Plus,
  Pencil,
  Trash2,
  FileText,
  Package,
  Link,
  X,
  Eye,
  Receipt,
  Loader2
} from 'lucide-vue-next';
import AdvancedFilter from './AdvancedFilter.vue';
import BillOfLadingForm from './BillOfLadingForm.vue';
import InvoicePreview from './InvoicePreview.vue';
import billOfLadingService from '../services/billOfLadingService';
import invoiceService from '../services/invoiceService';
import { formatUtcDate } from '../utils/date';

interface Commodity {
  description: string;
  weightKg: number;
  volumeM3: number;
  packagesNumber: number;
  hazardous: boolean;
  hazardClass?: string;
  unNumber?: string;
}

interface Item {
  id?: string;
  clientId?: string;
  type: 'container' | 'breakbulk' | 'vehicle';
  itemNumber: string;
  status: string;
}

interface BillOfLading {
  id: string;
  blNumber: string;
  status: 'Draft' | 'Final' | 'Cancelled';
  shipper: string;
  consignee: string;
  notifyParty: string;
  transportType: 'Vessel' | 'Train' | 'Truck';
  vessel: string;
  voyage: string;
  portOfLoading: string;
  portOfDischarge: string;
  placeOfDelivery: string;
  driver: string;
  trainNumber: string;
  truckNumber: string;
  commodity: Commodity;
  items: Item[];
  transportSnapshot?: any;
  createdAt: string;
  updatedAt: string;
}

const bills = ref<BillOfLading[]>([]);

const fetchBills = async () => {
  bills.value = await billOfLadingService.list();
};

onMounted(fetchBills);

const showForm = ref(false);
const editingBL = ref<BillOfLading | null>(null);
const showDeleteConfirm = ref(false);
const blToDelete = ref<BillOfLading | null>(null);
const showItemsModal = ref(false);
const selectedBL = ref<BillOfLading | null>(null);

const handleFilter = (filters: any[]) => {
  console.log('Applying filters:', filters);
  // Implement filter logic here
};

const getStatusBadgeClasses = (status: string) => {
  const baseClasses = "px-2 py-1 text-xs font-medium rounded-full";
  switch (status) {
    case 'Final':
      return `${baseClasses} bg-green-100 text-green-800`;
    case 'Draft':
      return `${baseClasses} bg-yellow-100 text-yellow-800`;
    case 'Cancelled':
      return `${baseClasses} bg-red-100 text-red-800`;
    default:
      return baseClasses;
  }
};

const handleAdd = () => {
  editingBL.value = null;
  showForm.value = true;
};

const handleEdit = (bl: BillOfLading) => {
  editingBL.value = bl;
  showForm.value = true;
};

const handleDelete = (bl: BillOfLading) => {
  blToDelete.value = bl;
  showDeleteConfirm.value = true;
};

const confirmDelete = async () => {
  if (blToDelete.value) {
    await billOfLadingService.delete(blToDelete.value.id);
    await fetchBills();
    showDeleteConfirm.value = false;
    blToDelete.value = null;
  }
};

const handleViewItems = (bl: BillOfLading) => {
  selectedBL.value = bl;
  showItemsModal.value = true;
};

const handleFormSubmit = async (
  formData: Omit<BillOfLading, 'id' | 'createdAt' | 'updatedAt'> | {},
) => {
  try {
    // If formData is empty (items diff was applied), just refresh the list
    if (editingBL.value && Object.keys(formData).length === 0) {
      // Items were updated via applyItemsDiff, just refresh
      await fetchBills();
      showForm.value = false;
      editingBL.value = null;
      return;
    }
    
    if (editingBL.value) {
      await billOfLadingService.update(editingBL.value.id, formData as Omit<BillOfLading, 'id' | 'createdAt' | 'updatedAt'>);
    } else {
      await billOfLadingService.create(formData as Omit<BillOfLading, 'id' | 'createdAt' | 'updatedAt'>);
    }
    await fetchBills();
    showForm.value = false;
    editingBL.value = null;
  } catch (e: any) {
    console.error(e);
    showToast(e?.response?.data || 'Failed to save bill of lading.', 'error');
  }
};

const handleFormCancel = () => {
  showForm.value = false;
  editingBL.value = null;
};

const toast = ref<{ message: string; type: 'success' | 'error' | 'warning' } | null>(null);
const showToast = (message: string, type: 'success' | 'error' | 'warning' = 'success') => {
  toast.value = { message, type };
  setTimeout(() => (toast.value = null), 3000);
};

// Track loading and recently generated invoices
const invoicing = ref<Record<string, boolean>>({});
const recentlyInvoiced = ref<Record<string, number>>({});
const invoiceConflict = ref<Record<string, boolean>>({});
const INVOICE_GUARD_MS = 10000; // 10 seconds

const previewInvoice = ref<{ id: string; url: string } | null>(null);

const isInvoicing = (bl: BillOfLading) => !!invoicing.value[bl.id];
const attemptGenerateInvoice = (bl: BillOfLading) => {
  if (invoiceConflict.value[bl.id]) {
    return;
  }
  handleGenerateInvoice(bl);
};

const handleGenerateInvoice = async (bl: BillOfLading) => {
  const last = recentlyInvoiced.value[bl.id];
  if (last && Date.now() - last < INVOICE_GUARD_MS) {
    return;
  }
  invoicing.value[bl.id] = true;
  try {
    const { invoiceId } = await invoiceService.generateDraft(
      bl.id,
      bl.shipper
    );
    showToast('Invoice generated.', 'success');
    recentlyInvoiced.value[bl.id] = Date.now();
    if (invoiceId) {
      previewInvoice.value = {
        id: invoiceId,
        url: invoiceService.getInvoicePreviewUrl(invoiceId),
      };
    }
  } catch (e: any) {
    console.error(e);
    if (e?.response?.status === 409) {
      showToast('Invoice already exists for this bill of lading.', 'warning');
      invoiceConflict.value[bl.id] = true;
    } else {
      showToast(e?.response?.data || 'Failed to generate invoice.', 'error');
    }
  } finally {
    invoicing.value[bl.id] = false;
  }
};
</script>

<template>
  <div>
    <!-- List View -->
    <div v-if="!showForm" class="bg-white shadow rounded-lg">
      <!-- Header -->
      <div class="px-6 py-4 border-b border-gray-200">
        <div class="flex justify-between items-center">
          <h2 class="text-lg font-semibold text-gray-900">Bills of Lading</h2>
          <div class="flex space-x-4">
            <div class="relative">
              <input
                type="text"
                placeholder="Search bills..."
                class="w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
              <Search class="h-5 w-5 text-gray-400 absolute left-3 top-2.5" />
            </div>
            <button class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
              <Download class="h-4 w-4 mr-2" />
              Export
            </button>
            <button 
              @click="handleAdd"
              class="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
            >
              <Plus class="h-4 w-4 mr-2" />
              New Bill of Lading
            </button>
          </div>
        </div>
      </div>

      <!-- Advanced Filter -->
      <AdvancedFilter type="bills" @filter="handleFilter" />

      <!-- Table -->
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th
                v-for="header in ['BL Number', 'Status', 'Vessel/Voyage', 'Shipper', 'Items', 'Created', 'Actions']"
                :key="header"
                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                {{ header }}
              </th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <tr v-for="bl in bills" :key="bl.id" class="hover:bg-gray-50">
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="flex items-center">
                  <FileText class="h-5 w-5 text-gray-400 mr-2" />
                  <div class="text-sm font-medium text-gray-900">{{ bl.blNumber }}</div>
                </div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <span :class="getStatusBadgeClasses(bl.status)">
                  {{ bl.status }}
                </span>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900">{{ bl.vessel }}</div>
                <div class="text-sm text-gray-500">{{ bl.voyage }}</div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {{ bl.shipper }}
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <button
                  @click="handleViewItems(bl)"
                  class="inline-flex items-center text-sm text-blue-600 hover:text-blue-900"
                >
                  <Package class="h-4 w-4 mr-1" />
                  {{ bl.items?.length ?? 0 }} items
                </button>
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {{ formatUtcDate(bl.createdAt) }}
              </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button
                    v-if="!invoiceConflict[bl.id]"
                    @click="attemptGenerateInvoice(bl)"
                    :disabled="isInvoicing(bl)"
                    class="text-green-600 hover:text-green-900 mr-3 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                    aria-label="Generate invoice"
                    title="Generate invoice"
                  >
                    <Loader2 v-if="isInvoicing(bl)" class="h-5 w-5 animate-spin" />
                    <Receipt v-else class="h-5 w-5" />
                  </button>
                  <button
                  @click="handleEdit(bl)"
                  class="text-blue-600 hover:text-blue-900 mr-3"
                >
                  <Pencil class="h-5 w-5" />
                </button>
                <button
                  v-if="bl.status === 'Draft'"
                  @click="handleDelete(bl)"
                  class="text-red-600 hover:text-red-900"
                >
                  <Trash2 class="h-5 w-5" />
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Form View -->
    <BillOfLadingForm
      v-else
      :edit-mode="!!editingBL"
      :initial-data="editingBL"
      @submit="handleFormSubmit"
      @cancel="handleFormCancel"
    />

    <!-- Items Modal -->
    <Teleport to="body">
      <div v-if="showItemsModal && selectedBL" class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg p-6 max-w-2xl w-full">
          <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium text-gray-900">
              Items for BL {{ selectedBL.blNumber }}
            </h3>
            <button
              @click="showItemsModal = false"
              class="text-gray-400 hover:text-gray-500"
            >
              <X class="h-6 w-6" />
            </button>
          </div>

          <div class="mt-4">
            <h4 class="text-sm font-medium text-gray-700 mb-2">Commodity Details</h4>
            <div class="bg-gray-50 p-4 rounded-lg">
              <dl class="grid grid-cols-2 gap-4">
                <div>
                  <dt class="text-sm font-medium text-gray-500">Description</dt>
                  <dd class="mt-1 text-sm text-gray-900">{{ selectedBL.commodity.description }}</dd>
                </div>
                <div>
                  <dt class="text-sm font-medium text-gray-500">Weight</dt>
                  <dd class="mt-1 text-sm text-gray-900">{{ selectedBL.commodity.weightKg }} kg</dd>
                </div>
                <div>
                  <dt class="text-sm font-medium text-gray-500">Volume</dt>
                  <dd class="mt-1 text-sm text-gray-900">{{ selectedBL.commodity.volumeM3 }} m³</dd>
                </div>
                <div>
                  <dt class="text-sm font-medium text-gray-500">Packages</dt>
                  <dd class="mt-1 text-sm text-gray-900">{{ selectedBL.commodity.packagesNumber }}</dd>
                </div>
              </dl>
            </div>
          </div>

          <div class="mt-6">
            <div class="flex justify-between items-center mb-4">
              <h4 class="text-sm font-medium text-gray-700">Linked Items</h4>
              <button class="inline-flex items-center text-sm text-blue-600 hover:text-blue-900">
                <Link class="h-4 w-4 mr-1" />
                Link New Item
              </button>
            </div>
            
            <div class="bg-white shadow overflow-hidden border border-gray-200 sm:rounded-lg">
              <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                  <tr>
                    <th v-for="header in ['Type', 'Number', 'Status', 'Actions']" 
                        :key="header"
                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      {{ header }}
                    </th>
                  </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                  <tr v-for="item in selectedBL.items ?? []" :key="item.id">
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {{ item.type }}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {{ item.itemNumber }}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {{ item.status }}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button class="text-blue-600 hover:text-blue-900">
                        <Eye class="h-5 w-5" />
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div class="mt-6 flex justify-end">
            <button
              @click="showItemsModal = false"
              class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Delete Confirmation Modal -->
    <Teleport to="body">
      <div v-if="showDeleteConfirm" class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg p-6 max-w-md w-full">
          <div class="text-center">
            <FileText class="mx-auto h-12 w-12 text-red-500" />
            <h3 class="mt-4 text-lg font-medium text-gray-900">Delete Bill of Lading</h3>
            <p class="mt-2 text-sm text-gray-500">
              Are you sure you want to delete {{ blToDelete?.blNumber }}? This action cannot be undone.
            </p>
          </div>
          <div class="mt-6 flex justify-end space-x-3">
            <button
              @click="showDeleteConfirm = false"
              class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              @click="confirmDelete"
              class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </Teleport>

    <Teleport to="body">
      <div
        v-if="toast"
        :class="[
          'fixed top-4 right-4 px-4 py-2 rounded shadow text-white',
          toast.type === 'success'
            ? 'bg-green-500'
            : toast.type === 'error'
            ? 'bg-red-500'
            : 'bg-yellow-500'
        ]"
      >
        {{ toast.message }}
      </div>
    </Teleport>
    <InvoicePreview
      v-if="previewInvoice"
      :invoice-id="previewInvoice.id"
      :preview-url="previewInvoice.url"
      status="Draft"
      @close="previewInvoice = null"
    />
  </div>
</template>