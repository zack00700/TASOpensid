import { useAuth } from '../composables/useAuth';

/**
 * Middleware pour protéger les routes qui nécessitent une authentification
 * À appeler au début de vos composants ou pages protégées
 */
export function useRouteGuard() {
  const { requireAuth } = useAuth();
  
  // Vérifier l'authentification au montage du composant
  const checkAuthentication = () => {
    return requireAuth();
  };
  
  return {
    checkAuthentication
  };
}

/**
 * Fonction utilitaire pour vérifier l'authentification de manière synchrone
 * Utile pour les vérifications rapides dans les composants
 */
export function isUserAuthenticated(): boolean {
  const { isAuthenticated } = useAuth();
  return isAuthenticated.value;
}

/**
 * Fonction à appeler au démarrage de l'application pour vérifier l'auth
 * À intégrer dans votre App.vue ou main.ts
 */
export function initializeAuthGuard() {
  // Vérifier si on est sur la page de login
  const isLoginPage = window.location.pathname === '/login';
  
  // Si pas sur la page de login, vérifier l'authentification
  if (!isLoginPage) {
    const { requireAuth } = useAuth();
    requireAuth();
  }
}

/**
 * Directive Vue pour protéger des éléments selon l'authentification
 * Usage: v-auth ou v-auth:role="'admin'"
 */
export const authDirective = {
  mounted(el: HTMLElement, binding: any) {
    const { isAuthenticated, userRole } = useAuth();
    
    // Si pas authentifié, masquer l'élément
    if (!isAuthenticated.value) {
      el.style.display = 'none';
      return;
    }
    
    // Si un rôle spécifique est requis
    if (binding.arg === 'role' && binding.value) {
      const requiredRole = binding.value;
      if (userRole.value !== requiredRole) {
        el.style.display = 'none';
        return;
      }
    }
    
    // Afficher l'élément si toutes les conditions sont remplies
    el.style.display = '';
  },
  
  updated(el: HTMLElement, binding: any) {
    // Réexécuter la logique lors des mises à jour
    authDirective.mounted(el, binding);
  }
};