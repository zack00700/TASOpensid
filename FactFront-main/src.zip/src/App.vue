<script setup lang="ts">
import { onMounted } from 'vue';
import { useAuth } from './composables/useAuth';
import AskAiFab from './components/AskAiFab.vue';
import SidebarMenu from './components/SidebarMenu.vue';
import Login from './components/Login.vue';

const { isAuthenticated, checkAuth, loading } = useAuth();

// Vérifier l'authentification au montage
onMounted(() => {
  checkAuth();
});
</script>

<template>
  <!-- Écran de chargement -->
  <div v-if="loading" class="min-h-screen bg-gray-50 flex items-center justify-center">
    <div class="text-center">
      <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
      <p class="text-gray-600">Chargement...</p>
    </div>
  </div>

  <!-- Page de connexion -->
  <Login v-else-if="!isAuthenticated" />

  <!-- Application principale (si authentifié) -->
  <div v-else class="flex min-h-[100dvh] bg-gray-50">
    <!-- Sidebar Navigation -->
    <SidebarMenu />

    <!-- Main Content -->
    <div class="flex-1 flex flex-col min-w-0">
      <!-- Header -->
      <header class="bg-white shadow sticky top-0 z-10">
        <div class="px-4 py-6">
          <h1 class="text-3xl font-bold text-gray-900">Terminal Billing System</h1>
        </div>
      </header>

      <main class="flex-1 min-w-0 overflow-y-auto overflow-x-hidden px-4 py-6">
        <router-view />
      </main>
      <AskAiFab />
    </div>
  </div>
</template>