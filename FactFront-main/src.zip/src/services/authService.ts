interface LoginCredentials {
    username: string;
    password: string;
  }
  
  interface LoginResponse {
    token: string;
    user: {
      id: string;
      username: string;
      email?: string;
      fullName?: string;
      roles: string[]; // Tableau de rôles de votre backend
      role?: string; // Rôle simplifié ajouté par le service
    };
    expiresIn?: number;
  }
  
  class AuthService {
    private readonly TOKEN_KEY = 'terminal_billing_token';
    private readonly USER_KEY = 'terminal_billing_user';
    private readonly API_BASE_URL = 'http://localhost:8080/api';
  
    /**
     * Connexion utilisateur
     */
    async login(credentials: LoginCredentials): Promise<LoginResponse> {
      try {
        const loginUrl = `${this.API_BASE_URL}/auth/login`;
        console.log('🔍 API_BASE_URL:', this.API_BASE_URL);
        console.log('🌐 Login URL complète:', loginUrl);
        
        const response = await fetch(loginUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(credentials)
        });
  
        console.log('📡 Response status:', response.status);
  
        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          const error = new Error(errorData.message || 'Erreur de connexion');
          (error as any).status = response.status;
          throw error;
        }
  
        const data: LoginResponse = await response.json();
        console.log('📦 Response data:', data);
        
        // Adapter selon la structure de votre réponse
        let userData = data.user;
        if (!userData && data.username) {
          // Si les données user sont directement dans data
          userData = {
            id: data.id || data.userId || '1',
            username: data.username,
            email: data.email,
            role: data.role || data.userRole || 'user'
          };
        }
        
        // Stocker les données d'authentification
        this.setToken(data.token);
        if (userData) {
          this.setUser(userData);
          console.log('👤 User stored:', userData);
        }
  
        return { ...data, user: userData };
      } catch (error) {
        console.error('❌ Erreur dans authService.login:', error);
        if (error instanceof Error && 'status' in error) {
          throw error;
        }
        throw new Error('Erreur de connexion au serveur');
      }
    }
  
    /**
     * Déconnexion
     */
    async logout(): Promise<void> {
      try {
        // Optionnel: appeler l'API de déconnexion
        const token = this.getToken();
        if (token) {
          await fetch(`${this.API_BASE_URL}/auth/logout`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json',
            }
          }).catch(() => {
            // Ignorer les erreurs de déconnexion côté serveur
          });
        }
      } finally {
        // Toujours nettoyer le stockage local
        this.clearAuth();
        window.location.href = '/login';
      }
    }
  
    /**
     * Vérifier si l'utilisateur est connecté
     */
    isAuthenticated(): boolean {
      const token = this.getToken();
      if (!token) return false;
  
      // Vérifier si le token n'est pas expiré
      try {
        const payload = this.parseJWT(token);
        if (payload.exp && payload.exp * 1000 < Date.now()) {
          this.clearAuth();
          return false;
        }
        return true;
      } catch {
        return !!token; // Fallback si le token n'est pas JWT
      }
    }
  
    /**
     * Obtenir le token stocké
     */
    getToken(): string | null {
      return localStorage.getItem(this.TOKEN_KEY);
    }
  
    /**
     * Stocker le token
     */
    private setToken(token: string): void {
      localStorage.setItem(this.TOKEN_KEY, token);
    }
  
    /**
     * Obtenir les données utilisateur
     */
    getUser(): any | null {
      const userData = localStorage.getItem(this.USER_KEY);
      return userData ? JSON.parse(userData) : null;
    }
  
    /**
     * Stocker les données utilisateur
     */
    private setUser(user: any): void {
      localStorage.setItem(this.USER_KEY, JSON.stringify(user));
    }
  
    /**
     * Nettoyer les données d'authentification
     */
    private clearAuth(): void {
      localStorage.removeItem(this.TOKEN_KEY);
      localStorage.removeItem(this.USER_KEY);
    }
  
    /**
     * Parser un token JWT (optionnel)
     */
    private parseJWT(token: string): any {
      try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(
          atob(base64)
            .split('')
            .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
            .join('')
        );
        return JSON.parse(jsonPayload);
      } catch {
        throw new Error('Token invalide');
      }
    }
  
    /**
     * Obtenir les en-têtes d'autorisation pour les requêtes API
     */
    getAuthHeaders(): HeadersInit {
      const token = this.getToken();
      return token ? { 'Authorization': `Bearer ${token}` } : {};
    }
  
    /**
     * Wrapper pour les requêtes authentifiées
     */
    async authenticatedFetch(url: string, options: RequestInit = {}): Promise<Response> {
      const headers = {
        'Content-Type': 'application/json',
        ...this.getAuthHeaders(),
        ...options.headers,
      };
  
      const response = await fetch(url, {
        ...options,
        headers,
      });
  
      // Si non autorisé, déconnecter automatiquement
      if (response.status === 401) {
        this.clearAuth();
        window.location.href = '/login';
        throw new Error('Session expirée');
      }
  
      return response;
    }
  }
  
  // Export d'une instance singleton
  const authService = new AuthService();
  export default authService;