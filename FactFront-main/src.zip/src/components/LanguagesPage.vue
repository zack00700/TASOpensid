<template>
  <div class="max-w-7xl mx-auto p-6 space-y-6">
    <!-- Header with Breadcrumb -->
    <div class="border-b border-gray-200 pb-4">
      <div class="flex items-center gap-2 text-sm text-gray-600 mb-2">
        <button 
          @click="resetNavigation" 
          class="hover:text-blue-600 transition-colors"
          :class="{ 'text-blue-600 font-medium': !selectedLanguage }"
        >
          Languages
        </button>
        <template v-if="selectedLanguage">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
          </svg>
          <button 
            @click="selectedEntity = null" 
            class="hover:text-blue-600 transition-colors"
            :class="{ 'text-blue-600 font-medium': selectedLanguage && !selectedEntity }"
          >
            {{ selectedLanguage.name }} Entities
          </button>
          <template v-if="selectedEntity">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
            </svg>
            <span class="text-blue-600 font-medium">{{ selectedEntity.name }} Fields</span>
          </template>
        </template>
      </div>
      
      <h1 class="text-2xl font-semibold text-gray-900">
        <span v-if="!selectedLanguage">Languages</span>
        <span v-else-if="!selectedEntity">{{ selectedLanguage.name }} - Entities</span>
        <span v-else>{{ selectedEntity.name }} - Fields</span>
      </h1>
    </div>

    <!-- Languages View -->
    <div v-if="!selectedLanguage" class="space-y-6">
      <!-- Controls -->
      <div class="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div class="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
          <div class="relative">
            <input 
              v-model="search" 
              placeholder="Search languages..." 
              class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200 w-64"
            />
            <svg class="absolute left-3 top-2.5 h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          
          <label class="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
            <input type="checkbox" v-model="enabledOnly" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            Show enabled only
          </label>
        </div>
        
        <button 
          @click="openLanguageModal" 
          class="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all duration-200"
        >
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Add Language
        </button>
      </div>

      <!-- Languages Table -->
      <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full">
            <thead class="bg-gray-50 border-b border-gray-200">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Language</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Entities</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <tr v-for="lang in languages" :key="lang.code" class="hover:bg-gray-50 transition-colors duration-150">
                <td class="px-6 py-4">
                  <div class="flex items-center gap-3">
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                      {{ lang.code }}
                    </span>
                    <span class="text-sm font-medium text-gray-900">{{ lang.name }}</span>
                  </div>
                </td>
                <td class="px-6 py-4">
                  <span :class="[
                    'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
                    lang.enabled ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  ]">
                    {{ lang.enabled ? 'Enabled' : 'Disabled' }}
                  </span>
                </td>
                <td class="px-6 py-4">
                  <span class="text-sm text-gray-600">{{ lang.entities?.length || 0 }} entities</span>
                </td>
                <td class="px-6 py-4">
                  <div class="flex items-center gap-2">
                    <button 
                      @click="viewLanguageEntities(lang)" 
                      class="inline-flex items-center gap-1 px-3 py-1.5 text-sm text-blue-700 bg-blue-50 border border-blue-200 rounded-md hover:bg-blue-100 transition-all duration-200"
                    >
                      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                      </svg>
                      Manage
                    </button>
                    <button 
                      @click="editLanguage(lang)" 
                      class="inline-flex items-center gap-1 px-3 py-1.5 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-all duration-200"
                    >
                      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                      </svg>
                      Edit
                    </button>
                    <button 
                      @click="deleteLanguage(lang)" 
                      class="inline-flex items-center gap-1 px-3 py-1.5 text-sm text-red-700 bg-white border border-red-300 rounded-md hover:bg-red-50 transition-all duration-200"
                    >
                      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Entities View -->
    <div v-else-if="!selectedEntity" class="space-y-6">
      <div class="flex justify-between items-center">
        <div class="text-sm text-gray-600">
          Managing entities for <strong>{{ selectedLanguage.name }}</strong>
        </div>
        <button 
          @click="openEntityModal" 
          class="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-4 focus:ring-blue-200 transition-all duration-200"
        >
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Add Entity {{ showEntityModal ? '(Modal Open)' : '' }}
        </button>
      </div>

      <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <div 
          v-for="entity in selectedLanguage.entities" 
          :key="entity.entity"
          class="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-md transition-all duration-200"
        >
          <div class="flex items-start justify-between mb-4">
            <div>
              <h3 class="text-lg font-semibold text-gray-900">{{ entity.name }}</h3>
              <p class="text-sm text-gray-600">{{ entity.entity }}</p>
            </div>
            <div class="flex items-center gap-1">
              <button 
                @click="editEntity(entity)" 
                class="p-1.5 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
              </button>
              <button 
                @click="deleteEntity(entity)" 
                class="p-1.5 text-gray-400 hover:text-red-600 transition-colors"
              >
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
              </button>
            </div>
          </div>
          
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">{{ entity.fields?.length || 0 }} fields</span>
            <button 
              @click="viewEntityFields(entity)" 
              class="inline-flex items-center gap-1 px-3 py-1.5 text-sm text-blue-700 bg-blue-50 rounded-md hover:bg-blue-100 transition-all duration-200"
            >
              Manage Fields
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Fields View -->
    <div v-else class="space-y-6">
      <div class="flex justify-between items-center">
        <div class="text-sm text-gray-600">
          Managing fields for <strong>{{ selectedEntity.name }}</strong> in {{ selectedLanguage.name }}
        </div>
        <button 
          @click="openFieldModal" 
          class="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all duration-200"
        >
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Add Field
        </button>
      </div>

      <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full">
            <thead class="bg-gray-50 border-b border-gray-200">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Field</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Required</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <tr v-for="field in selectedEntity.fields" :key="field.field" class="hover:bg-gray-50 transition-colors duration-150">
                <td class="px-6 py-4">
                  <span class="font-mono text-sm text-gray-900">{{ field.field }}</span>
                </td>
                <td class="px-6 py-4 text-sm text-gray-900">{{ field.name }}</td>
                <td class="px-6 py-4">
                  <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    {{ field.type }}
                  </span>
                </td>
                <td class="px-6 py-4">
                  <span :class="[
                    'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
                    field.required ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'
                  ]">
                    {{ field.required ? 'Required' : 'Optional' }}
                  </span>
                </td>
                <td class="px-6 py-4">
                  <div class="flex items-center gap-2">
                    <button 
                      @click="editField(field)" 
                      class="inline-flex items-center gap-1 px-3 py-1.5 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-all duration-200"
                    >
                      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                      </svg>
                      Edit
                    </button>
                    <button 
                      @click="deleteField(field)" 
                      class="inline-flex items-center gap-1 px-3 py-1.5 text-sm text-red-700 bg-white border border-red-300 rounded-md hover:bg-red-50 transition-all duration-200"
                    >
                      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Error Display -->
    <div v-if="error" class="bg-red-50 border border-red-200 rounded-lg p-4">
      <div class="flex items-center gap-3">
        <svg class="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p class="text-red-800">{{ error }}</p>
      </div>
    </div>

    <!-- Language Modal -->
    <div v-if="showLanguageModal" class="fixed inset-0 z-50 overflow-y-auto">
      <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" @click="closeLanguageModal"></div>
        
        <div class="inline-block align-bottom bg-white rounded-xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
          <div class="bg-white px-6 pt-6 pb-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-6">
              {{ editingLanguage ? 'Edit Language' : 'Add New Language' }}
            </h3>
            
            <!-- General Error -->
            <div v-if="validationErrors.general" class="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
              <p class="text-red-800 text-sm">{{ validationErrors.general }}</p>
            </div>
            
            <div class="space-y-5">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                  Language Code *
                </label>
                <input 
                  v-model="languageForm.code" 
                  :disabled="editingLanguage"
                  :class="[
                    'block w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200',
                    validationErrors.code ? 'border-red-300' : 'border-gray-300',
                    editingLanguage ? 'bg-gray-50 text-gray-500' : ''
                  ]"
                  placeholder="e.g. en, fr, es"
                />
                <p v-if="validationErrors.code" class="mt-1 text-xs text-red-600">{{ validationErrors.code }}</p>
                <p v-else class="mt-1 text-xs text-gray-500">Two-letter language code (ISO 639-1)</p>
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                  Language Name *
                </label>
                <input 
                  v-model="languageForm.name" 
                  :class="[
                    'block w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200',
                    validationErrors.name ? 'border-red-300' : 'border-gray-300'
                  ]"
                  placeholder="e.g. English, Français, Español"
                />
                <p v-if="validationErrors.name" class="mt-1 text-xs text-red-600">{{ validationErrors.name }}</p>
              </div>
              
              <div class="flex items-center">
                <input 
                  v-model="languageForm.enabled" 
                  type="checkbox" 
                  class="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-3"
                />
                <div>
                  <label class="text-sm font-medium text-gray-700">Enable this language</label>
                  <p class="text-xs text-gray-500">Users will be able to select this language</p>
                </div>
              </div>
            </div>
          </div>
          
          <div class="bg-gray-50 px-6 py-4 flex justify-end gap-3">
            <button 
              @click="closeLanguageModal" 
              class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
            >
              Cancel
            </button>
            <button 
              @click="saveLanguage" 
              class="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
            >
              {{ editingLanguage ? 'Update Language' : 'Create Language' }}
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Entity Modal -->
    <div v-if="showEntityModal" class="fixed inset-0 z-50 overflow-y-auto">
      <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" @click="closeEntityModal"></div>
        
        <div class="inline-block align-bottom bg-white rounded-xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
          <div class="bg-white px-6 pt-6 pb-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-6">
              {{ editingEntity ? 'Edit Entity' : 'Add New Entity' }}
            </h3>
            
            <!-- General Error -->
            <div v-if="validationErrors.general" class="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
              <p class="text-red-800 text-sm">{{ validationErrors.general }}</p>
            </div>
            
            <div class="space-y-5">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                  Entity Key *
                </label>
                <input 
                  v-model="entityForm.entity" 
                  :disabled="editingEntity"
                  :class="[
                    'block w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200 font-mono text-sm',
                    validationErrors.entity ? 'border-red-300' : 'border-gray-300',
                    editingEntity ? 'bg-gray-50 text-gray-500' : ''
                  ]"
                  placeholder="e.g. user, product, order"
                />
                <p v-if="validationErrors.entity" class="mt-1 text-xs text-red-600">{{ validationErrors.entity }}</p>
                <p v-else class="mt-1 text-xs text-gray-500">Unique identifier for this entity (camelCase recommended)</p>
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                  Display Name *
                </label>
                <input 
                  v-model="entityForm.name" 
                  :class="[
                    'block w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200',
                    validationErrors.name ? 'border-red-300' : 'border-gray-300'
                  ]"
                  placeholder="e.g. User Profile, Product Catalog, Order Management"
                />
                <p v-if="validationErrors.name" class="mt-1 text-xs text-red-600">{{ validationErrors.name }}</p>
                <p v-else class="mt-1 text-xs text-gray-500">Human-readable name for this entity</p>
              </div>

              <div class="bg-blue-50 p-4 rounded-lg">
                <div class="flex items-center gap-2 mb-2">
                  <svg class="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <h4 class="text-sm font-medium text-blue-900">Next Steps</h4>
                </div>
                <p class="text-xs text-blue-700">After creating this entity, you can add fields to define its structure and data types.</p>
              </div>
            </div>
          </div>
          
          <div class="bg-gray-50 px-6 py-4 flex justify-end gap-3">
            <button 
              @click="closeEntityModal" 
              class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
            >
              Cancel
            </button>
            <button 
              @click="saveEntity" 
              class="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
            >
              {{ editingEntity ? 'Update Entity' : 'Create Entity' }}
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Field Modal -->
    <div v-if="showFieldModal" class="fixed inset-0 z-50 overflow-y-auto">
      <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" @click="closeFieldModal"></div>
        
        <div class="inline-block align-bottom bg-white rounded-xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
          <div class="bg-white px-6 pt-6 pb-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-6">
              {{ editingField ? 'Edit Field' : 'Add New Field' }}
            </h3>
            
            <!-- General Error -->
            <div v-if="validationErrors.general" class="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
              <p class="text-red-800 text-sm">{{ validationErrors.general }}</p>
            </div>
            
            <div class="space-y-5">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                  Field Key *
                </label>
                <input 
                  v-model="fieldForm.field" 
                  :disabled="editingField"
                  :class="[
                    'block w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200 font-mono text-sm',
                    validationErrors.field ? 'border-red-300' : 'border-gray-300',
                    editingField ? 'bg-gray-50 text-gray-500' : ''
                  ]"
                  placeholder="e.g. firstName, email, birthDate"
                />
                <p v-if="validationErrors.field" class="mt-1 text-xs text-red-600">{{ validationErrors.field }}</p>
                <p v-else class="mt-1 text-xs text-gray-500">Unique field identifier (camelCase recommended)</p>
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                  Display Name *
                </label>
                <input 
                  v-model="fieldForm.name" 
                  :class="[
                    'block w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200',
                    validationErrors.name ? 'border-red-300' : 'border-gray-300'
                  ]"
                  placeholder="e.g. First Name, Email Address, Date of Birth"
                />
                <p v-if="validationErrors.name" class="mt-1 text-xs text-red-600">{{ validationErrors.name }}</p>
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                  Field Type *
                </label>
                <select 
                  v-model="fieldForm.type" 
                  :class="[
                    'block w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200',
                    validationErrors.type ? 'border-red-300' : 'border-gray-300'
                  ]"
                >
                  <option v-for="type in fieldTypes" :key="type.value" :value="type.value">
                    {{ type.label }}
                  </option>
                </select>
                <p v-if="validationErrors.type" class="mt-1 text-xs text-red-600">{{ validationErrors.type }}</p>
              </div>

              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                  Default Value
                </label>
                <input 
                  v-model="fieldForm.default" 
                  class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200"
                  placeholder="Optional default value"
                />
                <p class="mt-1 text-xs text-gray-500">Default value when field is not provided</p>
              </div>
              
              <div class="space-y-3">
                <div class="flex items-center">
                  <input 
                    v-model="fieldForm.required" 
                    type="checkbox" 
                    class="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-3"
                  />
                  <div>
                    <label class="text-sm font-medium text-gray-700">Required field</label>
                    <p class="text-xs text-gray-500">This field must have a value</p>
                  </div>
                </div>
                
                <div class="flex items-center">
                  <input 
                    v-model="fieldForm.deprecated" 
                    type="checkbox" 
                    class="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-3"
                  />
                  <div>
                    <label class="text-sm font-medium text-gray-700">Deprecated</label>
                    <p class="text-xs text-gray-500">Mark this field as deprecated (discouraged for new usage)</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="bg-gray-50 px-6 py-4 flex justify-end gap-3">
            <button 
              @click="closeFieldModal" 
              class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
            >
              Cancel
            </button>
            <button 
              @click="saveField" 
              class="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
            >
              {{ editingField ? 'Update Field' : 'Create Field' }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useI18nFieldsStore } from '../stores/i18nFieldsStore'

const store = useI18nFieldsStore()

// Navigation state
const selectedLanguage = ref(null)
const selectedEntity = ref(null)

// Search and filters
const search = ref('')
const enabledOnly = ref(false)
const page = ref(1)
const perPage = 10

// Computed properties
const languages = computed(() => store.languages?.value || [])
const loading = computed(() => store.loading?.value || false)
const error = computed(() => store.error?.value || null)

// Navigation functions
function resetNavigation() {
  selectedLanguage.value = null
  selectedEntity.value = null
}

function viewLanguageEntities(language) {
  selectedLanguage.value = language
  selectedEntity.value = null
}

function viewEntityFields(entity) {
  selectedEntity.value = entity
}

// CRUD functions for languages
function openLanguageModal() {
  // Implementation for language modal
  console.log('Open language modal')
}

function editLanguage(language) {
  // Implementation for edit language
  console.log('Edit language:', language)
}

async function deleteLanguage(language) {
  if (confirm(`Delete language "${language.name}"?`)) {
    try {
      await store.deleteLanguage(language.code)
      await loadData()
    } catch (err) {
      console.error('Error deleting language:', err)
    }
  }
}

// CRUD functions for entities
function openEntityModal() {
  // Implementation for entity modal
  console.log('Open entity modal')
}

function editEntity(entity) {
  // Implementation for edit entity
  console.log('Edit entity:', entity)
}

async function deleteEntity(entity) {
  if (confirm(`Delete entity "${entity.name}"?`)) {
    try {
      await store.deleteEntity(selectedLanguage.value.code, entity.entity)
      await loadData()
      // Refresh the selected language data
      const updatedLang = languages.value.find(l => l.code === selectedLanguage.value.code)
      if (updatedLang) {
        selectedLanguage.value = updatedLang
      }
    } catch (err) {
      console.error('Error deleting entity:', err)
    }
  }
}

// CRUD functions for fields
function openFieldModal() {
  // Implementation for field modal
  console.log('Open field modal')
}

function editField(field) {
  // Implementation for edit field
  console.log('Edit field:', field)
}

async function deleteField(field) {
  if (confirm(`Delete field "${field.name}"?`)) {
    try {
      await store.deleteField(selectedLanguage.value.code, selectedEntity.value.entity, field.field)
      await loadData()
      // Refresh the selected language and entity data
      const updatedLang = languages.value.find(l => l.code === selectedLanguage.value.code)
      if (updatedLang) {
        selectedLanguage.value = updatedLang
        const updatedEntity = updatedLang.entities?.find(e => e.entity === selectedEntity.value.entity)
        if (updatedEntity) {
          selectedEntity.value = updatedEntity
        }
      }
    } catch (err) {
      console.error('Error deleting field:', err)
    }
  }
}

// Load data function
async function loadData() {
  try {
    await store.fetchLanguages({
      q: search.value || undefined,
      enabled: enabledOnly.value || undefined,
      limit: perPage,
      offset: (page.value - 1) * perPage
    })
  } catch (err) {
    console.error('Error loading languages:', err)
  }
}

// Watchers
watch([search, enabledOnly, page], () => {
  if (!selectedLanguage.value) {
    loadData()
  }
})

// Initial load
onMounted(loadData)
</script>