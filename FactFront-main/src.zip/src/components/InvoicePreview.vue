<script setup lang="ts">
import { ref, watch } from 'vue';

interface Props {
  invoiceId: string;
  previewUrl?: string;
  status?: string;
  deleting?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  invoiceId: '',
  deleting: false,
});
const emit = defineEmits(['close', 'finalize', 'delete']);

const frame = ref<HTMLIFrameElement | null>(null);
const loading = ref(true);

watch(
  () => props.previewUrl,
  () => {
    loading.value = true;
  }
);

function print() {
  frame.value?.contentWindow?.print();
}

function handleLoad() {
  loading.value = false;
}
</script>

<template>
  <Teleport to="body">
    <div
      class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
      role="dialog"
      aria-modal="true"
    >
      <div class="bg-white w-full h-full md:max-w-[1024px] md:h-[90vh] md:rounded-lg shadow-lg flex flex-col">
        <header class="flex items-center justify-between p-4 border-b">
          <div class="flex items-center gap-2">
            <h2 class="text-lg font-semibold">Invoice {{ invoiceId }}</h2>
            <span v-if="status" class="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">{{ status }}</span>
          </div>
          <div class="flex items-center gap-2">
            <button
              v-if="status === 'DRAFT'"
              class="px-3 py-1 border rounded text-red-600"
              @click="emit('delete')"
              aria-label="Delete invoice"
              :title="'Delete draft (irreversible)'"
              :disabled="deleting"
              :class="deleting ? 'opacity-50 cursor-not-allowed' : ''"
            >
              Delete
            </button>
            <button
              v-if="status === 'DRAFT'"
              class="px-3 py-1 border rounded"
              @click="emit('finalize')"
              aria-label="Finalize invoice"
            >
              Finalize
            </button>
            <button
              class="px-3 py-1 border rounded"
              @click="print"
              aria-label="Print invoice"
            >
              Print
            </button>
            <a
              class="px-3 py-1 border rounded"
              :href="previewUrl"
              target="_blank"
              rel="noopener"
              aria-label="Open invoice in new tab"
            >
              Open
            </a>
            <button
              class="px-3 py-1 border rounded"
              @click="emit('close')"
              aria-label="Close preview"
            >
              Close
            </button>
          </div>
        </header>
        <section class="flex-1 bg-gray-50 relative">
          <div
            v-if="loading"
            class="absolute inset-0 flex items-center justify-center bg-gray-100 animate-pulse"
          >
            <div class="w-16 h-16 bg-gray-200 rounded" />
          </div>
          <iframe
            v-if="previewUrl"
            :src="previewUrl"
            ref="frame"
            class="w-full h-full border-0"
            @load="handleLoad"
          />
        </section>
      </div>
    </div>
  </Teleport>
</template>

<style scoped>
</style>
