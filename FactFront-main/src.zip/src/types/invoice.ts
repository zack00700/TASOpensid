export interface Invoice {
  id: string;
  draftNumber: string;
  finalNumber: string | null;
  status: 'DRAFT' | 'FINAL' | 'CANCELLED';
  customerName: string;
  amount: number;
  totalAmount?: number;
  TotalAmount?: number;
  facility: string;
  createdDate: string;
}

/**
 * Represents a single line within an invoice.  These lines are displayed in
 * the invoice HTML preview and include basic pricing information that can be
 * summarised to a grand total.
 */
export interface InvoiceLineDto {
  /**
   * Human readable description of the line item, e.g. the event name or a
   * contract line label.
   */
  description: string;
  /** Quantity for the line (days, units, etc.). */
  quantity: number;
  /** Unit of measure associated with the quantity. */
  uom: string;
  /** Agreed rate for the item. */
  unitPrice: number;
  /** Calculated amount (quantity * unitPrice). */
  amount: number;
}

/**
 * Invoice enriched with line items.  The backend rendering logic can use this
 * structure when building the HTML preview so that the template has a list to
 * iterate over.
 */
export interface InvoiceWithLines extends Invoice {
  lines: InvoiceLineDto[];
}
