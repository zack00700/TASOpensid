import { inject, reactive, computed } from 'vue';
import type { Invoice } from '../types/invoice';

// Types for filter state
export interface InvoiceFilters {
  status: string[];
  customerName: string;
  facility: string;
  draftNumber: string;
  finalNumber: string;
  createdDateFrom: string | null;
  createdDateTo: string | null;
}

interface InvoiceState {
  filters: InvoiceFilters;
  page: number;
  pageSize: number;
  sort: string;
  items: Invoice[];
  totalCount: number;
  totalAmount: number;
  statusCounts: Record<string, number>;
  statusAmounts: Record<string, number>;
  trends: {
    totalAmount: number;
    status: Record<string, number>;
    displayed: number;
  };
  loading: boolean;
  error: string | null;
  updatedAt: Date | null;
}

const defaultFilters: InvoiceFilters = {
  status: [],
  customerName: '',
  facility: '',
  draftNumber: '',
  finalNumber: '',
  createdDateFrom: null,
  createdDateTo: null,
};

const DEFAULT_SORT = 'createdDate:desc';

// Mapping of UI sort fields to API sort keys
export const SORT_FIELD_MAP: Record<string, string> = {
  createdDate: 'createdDate',
  TotalAmount: 'TotalAmount',
  customerName: 'customerName',
  facility: 'facility',
  status: 'status',
  draftNumber: 'draftNumber',
  finalNumber: 'finalNumber',
};

export const SORTABLE_FIELDS = Object.keys(SORT_FIELD_MAP);

const API_TO_UI_SORT_FIELD_MAP = Object.fromEntries(
  Object.entries(SORT_FIELD_MAP).map(([ui, api]) => [api, ui])
);

// simple store using reactive state
const state: InvoiceState = reactive({
  filters: { ...defaultFilters },
  page: 1,
  pageSize: 50,
  sort: DEFAULT_SORT,
  items: [],
  totalCount: 0,
  totalAmount: 0,
  statusCounts: { DRAFT: 0, FINAL: 0 },
  statusAmounts: { DRAFT: 0, FINAL: 0 },
  trends: { totalAmount: 0, status: { DRAFT: 0, FINAL: 0 }, displayed: 0 },
  loading: false,
  error: null,
  updatedAt: null,
});

// computed helper to expose displayed count
const displayedCount = computed(() => state.items.length);

let $axios: any;

function normalizeSort(value: string): string {
  if (!value) return DEFAULT_SORT;
  let normalized = value.replace(',', ':');
  const parts = normalized.split(':');
  let changed = normalized !== value;

  let field = parts[0];
  let dir = parts[1];

  if (!dir) {
    changed = true;
    dir = 'asc';
  }

  dir = dir.toLowerCase();
  if (dir !== 'asc' && dir !== 'desc') {
    changed = true;
    dir = 'asc';
  }

  // Convert API field names to UI field names if necessary
  const mappedField = API_TO_UI_SORT_FIELD_MAP[field];
  if (mappedField && mappedField !== field) {
    field = mappedField;
    changed = true;
  }

  if (!SORTABLE_FIELDS.includes(field)) {
    changed = true;
    const [defaultField, defaultDir] = DEFAULT_SORT.split(':');
    field = defaultField;
    dir = defaultDir;
  }

  normalized = `${field}:${dir}`;
  if (changed) console.warn(`Malformed sort "${value}" corrected to "${normalized}"`);
  return normalized;
}

/**
 * Build query params from current state
 */
function buildParams() {
  state.sort = normalizeSort(state.sort);
  const [field, dir] = state.sort.split(':');
  const apiField = SORT_FIELD_MAP[field] || field;
  const params: Record<string, string> = {
    page: String(state.page),
    pageSize: String(state.pageSize),
    sort: `${apiField}:${dir}`,
  };

  const f = state.filters;
  if (f.status.length) params.status = f.status.join(',');
  if (f.customerName) params.customerName = f.customerName;
  if (f.facility) params.facility = f.facility;
  if (f.draftNumber) params.draftNumber = f.draftNumber;
  if (f.finalNumber) params.finalNumber = f.finalNumber;
  if (f.createdDateFrom) params.createdDateFrom = f.createdDateFrom;
  if (f.createdDateTo) params.createdDateTo = f.createdDateTo;
  return params;
}

function hydrateFromUrl(search: string = window.location.search) {
  const params = new URLSearchParams(search);
  const f = state.filters;
  if (params.get('status')) f.status = params.get('status')!.split(',');
  f.customerName = params.get('customerName') || '';
  f.facility = params.get('facility') || '';
  f.draftNumber = params.get('draftNumber') || '';
  f.finalNumber = params.get('finalNumber') || '';
  f.createdDateFrom = params.get('createdDateFrom');
  f.createdDateTo = params.get('createdDateTo');
  state.page = Number(params.get('page') || '1');
  state.pageSize = Number(
    params.get('pageSize') || params.get('size') || state.pageSize
  );
  const sortParam = params.get('sort');
  if (sortParam) state.sort = normalizeSort(sortParam);
}

/**
 * Fetch invoices from the API using the current state as query params.
 */
async function fetchInvoices() {
  if (!$axios) {
    state.error = 'Axios plugin not found';
    return;
  }

  state.loading = true;
  state.error = null;
  try {
    const params = buildParams();
    const { data } = await $axios.get('/invoices', { params });
    state.items = (data.items || []).map((inv: any) => ({
      ...inv,
      id: inv.id ?? inv.invoiceId,
      amount: Number(inv.totalAmount ?? inv.TotalAmount ?? inv.amount ?? 0),
    })) as Invoice[];
    state.totalCount = data.totalCount || 0;
    state.totalAmount = data.aggregates?.totalAmount || 0;
    state.statusCounts =
      data.statusCounts ||
      state.items.reduce(
        (acc: Record<string, number>, inv: Invoice) => {
          acc[inv.status] = (acc[inv.status] || 0) + 1;
          return acc;
        },
        { DRAFT: 0, FINAL: 0 }
      );
    state.statusAmounts =
      data.statusAmounts ||
      state.items.reduce(
        (acc: Record<string, number>, inv: Invoice) => {
          acc[inv.status] =
            (acc[inv.status] || 0) + (inv.amount ?? 0);
          return acc;
        },
        { DRAFT: 0, FINAL: 0 }
      );
    state.trends =
      data.trends || { totalAmount: 0, status: { DRAFT: 0, FINAL: 0 }, displayed: 0 };
    state.updatedAt = new Date();
  } catch (err: any) {
    let message = 'Failed to fetch invoices';
    if (err?.response) {
      const data = err.response.data;
      message = data?.message || data?.error || message;
      if (!message && Array.isArray(data?.errors)) message = data.errors.join(', ');
      else if (!message && typeof data === 'string') message = data;
      if (err.response.status === 400) {
        console.error('fetchInvoices 400 error', err.response);
      }
    } else if (err?.message) {
      message = err.message;
    }
    state.error = message;
    state.items = [];
    state.totalCount = 0;
    state.totalAmount = 0;
    state.statusCounts = { DRAFT: 0, FINAL: 0 };
    state.statusAmounts = { DRAFT: 0, FINAL: 0 };
    state.trends = { totalAmount: 0, status: { DRAFT: 0, FINAL: 0 }, displayed: 0 };
  } finally {
    state.loading = false;
  }
}

// reset filters and page
function clearFilters() {
  Object.assign(state.filters, defaultFilters);
  state.page = 1;
}

export function useInvoice() {
  $axios = inject<any>('$axios');
  return {
    state,
    displayedCount,
    fetchInvoices,
    clearFilters,
    hydrateFromUrl,
  };
}

