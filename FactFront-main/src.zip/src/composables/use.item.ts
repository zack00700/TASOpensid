import { inject, onBeforeMount, ref } from 'vue';
import { Item, ItemFormData } from '../types/item';

export function useItem() {

    const $axios = inject('$axios');
    const formData = ref<ItemFormData>({
        _id: "",
        itemNumber: "",
        itemType: "container",
        type: "",
        ownerId: "",
        position: "",
        status: "Available",
        lastInspection: "",
        nextInspection: "",
        notes: "",
        lifeCycles: [],
    });
    
    const errors = ref<Record<string, string>>({});
    const items = ref<Item[] | null>([]);

    async function getItems() {
        try {
            const response = await $axios.get('/item');
            items.value = response.data;
        } catch (error) {
            console.error(error);
        }
    }

    const validateForm = () => {
        errors.value = {};
        let isValid = true;

        if (!formData.value.itemNumber) {
            errors.value.itemNumber = "Item number is required";
            isValid = false;
        }

        if (!formData.value.type) {
            errors.value.type = "Type is required";
            isValid = false;
        }

        if (!formData.value.ownerId) {
            errors.value.ownerId = "Owner ID is required"; // Fixed typo: was ownerid
            isValid = false;
        }

        if (formData.value.lastInspection && formData.value.nextInspection) {
            const last = new Date(formData.value.lastInspection);
            const next = new Date(formData.value.nextInspection);
            if (next <= last) {
            errors.value.nextInspection = "Next inspection date must be after last inspection";
            isValid = false;
            }
        }

        return isValid;
    };

    async function addItem() {
        try {
            await $axios.post('/item', formData.value)
        } catch (error) {
            console.error(error)
        }
    }

    // Add this new function for updating items
    // Replace your updateItem function with this debug version

// Replace your entire updateItem function in use.item.ts with this:
async function updateItem() {
    console.log("=== UPDATE ITEM DEBUG ===");
    console.log("Form data:", formData.value);
    console.log("Item ID:", formData.value._id);
    
    try {
        if (!formData.value._id) {
            console.error("❌ No _id found in form data!");
            throw new Error("Item ID is required for updating");
        }
        
        console.log("🔍 Item ID found:", formData.value._id);
        
        // Helper function to convert date string to Date object or null
        const parseDate = (dateString: string) => {
            if (!dateString) return null;
            return new Date(dateString).toISOString();
        };
        
        // Map frontend itemType to backend enum format
        const mapItemType = (frontendType: string) => {
            const mapping = {
                'container': 'CONTAINER',
                'breakbulk': 'BREAKBULK', 
                'vehicle': 'VEHICLE'
            };
            return mapping[frontendType.toLowerCase()] || frontendType.toUpperCase();
        };
        
        // Create patch operations with correct field names matching Item.java
        const patchOperations = [
            { op: "replace", path: "/itemType", value: mapItemType(formData.value.itemType) },
            { op: "replace", path: "/type", value: formData.value.type },
            { op: "replace", path: "/ownerId", value: formData.value.ownerId },
            { op: "replace", path: "/position", value: formData.value.position },
            { op: "replace", path: "/status", value: formData.value.status },
            { op: "replace", path: "/lastInspectionDate", value: parseDate(formData.value.lastInspection) },
            { op: "replace", path: "/nextInspectionDate", value: parseDate(formData.value.nextInspection) },
            { op: "replace", path: "/notes", value: formData.value.notes },
            { op: "replace", path: "/lifeCycles", value: formData.value.lifeCycles || [] }
        ].filter(op => op.value !== undefined); // Remove undefined values

        console.log("📝 Patch operations:", patchOperations);
        console.log("🌐 Making PATCH request to:", `/item/${formData.value._id}`);

        const response = await $axios.patch(`/item/${formData.value._id}`, patchOperations, {
            headers: {
                'Content-Type': 'application/json-patch+json'
            }
        });
        
        console.log("✅ PATCH response status:", response.status);
        console.log("✅ PATCH response data:", response.data);
        console.log("✅ Full PATCH response:", response);
        
    } catch (error) {
        console.error("❌ updateItem error:", error);
        console.error("❌ Error response:", error.response);
        throw error;
    }
}

    async function draftInvoice(itemId : string[], customer : string) {
        try {
            await $axios.post('/invoice/' + itemId + '/draft/customer/' + customer);
        } catch (error) {
            console.error(error);
            throw error;
        }
    }

    onBeforeMount(() => {
        getItems();
    })

    return {
        items,
        formData,
        errors,
        validateForm,
        addItem,
        updateItem, // Export the new updateItem function
        draftInvoice,
        getItems
    }
}