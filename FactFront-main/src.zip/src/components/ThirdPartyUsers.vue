<script setup lang="ts">
import { ref } from "vue";
import ThirdPartyUserForm from "./ThirdPartyUserForm.vue";
import ThirdPartyHistory from "./ThirdPartyHistory.vue";
import { Search, Download, Plus, Pencil, Trash2, XCircle, History, X } from "lucide-vue-next";
import AdvancedFilter from "./AdvancedFilter.vue";
import { useThirdParty } from "../composables/use.third-party";
interface ThirdPartyUser {
  id: string;
  fullName: string;
  email: string;
  companyName: string;
  accessType: string;
  status: "Active" | "Inactive" | "Pending";
  createdAt: string;
  updatedAt: string;
}

const showForm = ref(false);
const editingUser = ref<ThirdPartyUser | null>(null);
const formViewOnly = ref(false);
const showDeleteConfirm = ref(false);
const userToDelete = ref<ThirdPartyUser | null>(null);
const showHistory = ref(false);
const historyUser = ref<ThirdPartyUser | null>(null);

const { users, fetchThirdPartyUsers } = useThirdParty();

const handleFilter = (filters: any[]) => {
  console.log("Applying filters:", filters);
  // Implement filter logic here
};

const getStatusBadgeClasses = (status: string) => {
  const baseClasses = "px-2 py-1 text-xs font-medium rounded-full";
  switch (status) {
    case "Active":
      return `${baseClasses} bg-green-100 text-green-800`;
    case "Inactive":
      return `${baseClasses} bg-gray-100 text-gray-800`;
    case "Pending":
      return `${baseClasses} bg-yellow-100 text-yellow-800`;
    default:
      return baseClasses;
  }
};

const handleAdd = () => {
  editingUser.value = null;
  showForm.value = true;
  formViewOnly.value = false;
};

const handleEdit = (user: ThirdPartyUser) => {
  editingUser.value = user;
  showForm.value = true;
  formViewOnly.value = true;
};

const handleDelete = (user: ThirdPartyUser) => {
  userToDelete.value = user;
  showDeleteConfirm.value = true;
};

const handleShowHistory = (user: ThirdPartyUser) => {
  historyUser.value = user;
  showHistory.value = true;
};

const confirmDelete = () => {
  if (userToDelete.value) {
    users.value = users.value.filter((u) => u.id !== userToDelete.value?.id);
    showDeleteConfirm.value = false;
    userToDelete.value = null;
  }
};

const handleFormSubmit = async (formData: any) => {
  try {
    // In a real application, this would send the data to the server
    console.log("Form submitted:", formData);
    await fetchThirdPartyUsers();
    showForm.value = false;
    editingUser.value = null;
    formViewOnly.value = false;
  } catch (error) {
    console.error("Failed to save user:", error);
    alert("Failed to save user");
  }
};

const handleFormCancel = () => {
  showForm.value = false;
  editingUser.value = null;
  formViewOnly.value = false;
};

const closeHistory = () => {
  showHistory.value = false;
  historyUser.value = null;
};
</script>

<template>
  <div>
    <!-- List View -->
    <div v-if="!showForm" class="bg-white shadow rounded-lg">
      <!-- Header -->
      <div class="px-6 py-4 border-b border-gray-200">
        <div class="flex justify-between items-center">
          <h2 class="text-lg font-semibold text-gray-900">Third-Party Users</h2>
          <div class="flex space-x-4">
            <div class="relative">
              <input
                type="text"
                placeholder="Search users..."
                class="w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
              <Search class="h-5 w-5 text-gray-400 absolute left-3 top-2.5" />
            </div>
            <button
              class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
            >
              <Download class="h-4 w-4 mr-2" />
              Export
            </button>
            <button
              @click="handleAdd"
              class="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
            >
              <Plus class="h-4 w-4 mr-2" />
              Add User
            </button>
          </div>
        </div>
      </div>

      <!-- Advanced Filter -->
      <AdvancedFilter type="users" @filter="handleFilter" />

      <!-- Table -->
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th
                v-for="header in [
                  'User',
                  'Company',
                  'Access Type',
                  'Status',
                  'Created',
                  'Updated',
                  'Actions',
                ]"
                :key="header"
                class="Continuing with the ThirdPartyUsers.vue template and remaining components... px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                {{ header }}
              </th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <tr v-for="user in users" :key="user.id" class="hover:bg-gray-50">
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm font-medium text-gray-900">{{ user.fullName }}</div>
                <div class="text-sm text-gray-500">{{ user.email }}</div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {{ user.companyName }}
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {{ user.accessType }}
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <span :class="getStatusBadgeClasses(user.status)">
                  {{ user.status }}
                </span>
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {{ new Date(user.createdAt).toLocaleDateString() }}
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {{ new Date(user.updatedAt).toLocaleDateString() }}
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <button
                  @click="handleEdit(user)"
                  class="text-blue-600 hover:text-blue-900 mr-3"
                >
                  <Pencil class="h-5 w-5" />
                </button>
                <button
                  @click="handleShowHistory(user)"
                  class="text-blue-600 hover:text-blue-900 mr-3"
                >
                  <History class="h-5 w-5" />
                </button>
                <button
                  @click="handleDelete(user)"
                  class="text-red-600 hover:text-red-900"
                >
                  <Trash2 class="h-5 w-5" />
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Form View -->
    <ThirdPartyUserForm
      v-else
      :edit-mode="!!editingUser"
      :initial-data="editingUser"
      :view-only="formViewOnly"
      @submit="handleFormSubmit"
      @cancel="handleFormCancel"
    />
    <ThirdPartyHistory
      v-if="editingUser"
      :id="editingUser.id"
      class="mt-4"
    />

    <!-- History Modal -->
    <Teleport to="body">
      <div
        v-if="showHistory"
        class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50"
      >
        <div class="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium text-gray-900">History</h3>
            <button @click="closeHistory" class="text-gray-400 hover:text-gray-500">
              <X class="h-6 w-6" />
            </button>
          </div>
          <ThirdPartyHistory v-if="historyUser" :id="historyUser.id" />
        </div>
      </div>
    </Teleport>

    <!-- Delete Confirmation Modal -->
    <Teleport to="body">
      <div
        v-if="showDeleteConfirm"
        class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50"
      >
        <div class="bg-white rounded-lg p-6 max-w-md w-full">
          <div class="text-center">
            <XCircle class="mx-auto h-12 w-12 text-red-500" />
            <h3 class="mt-4 text-lg font-medium text-gray-900">Delete User</h3>
            <p class="mt-2 text-sm text-gray-500">
              Are you sure you want to delete {{ userToDelete?.fullName }}? This action
              cannot be undone.
            </p>
          </div>
          <div class="mt-6 flex justify-end space-x-3">
            <button
              @click="showDeleteConfirm = false"
              class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              @click="confirmDelete"
              class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>
