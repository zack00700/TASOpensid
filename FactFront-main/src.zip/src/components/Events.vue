<script setup lang="ts">
import { ref, computed } from 'vue';
import { Search, Download } from 'lucide-vue-next';
import AdvancedFilter from './AdvancedFilter.vue';
import EventTable from './EventTable.vue';
import { Event } from '../types/item';

// Sample data
const events = ref<Event[]>([
  {
    id: '1',
    timestamp: '2024-03-15T10:00:00Z',
    type: 'IN',
    itemId: 'CMAU5984269',
    lifecycleId: 'LC001',
    location: 'Gate-In',
    notes: 'Container arrived at terminal'
  },
  {
    id: '2',
    timestamp: '2024-03-15T14:30:00Z',
    type: 'INTERMEDIATE',
    itemId: 'CMAU5984269',
    lifecycleId: 'LC001',
    location: 'Yard-A12',
    notes: 'Moved to storage location'
  }
]);

const showFilters = ref(false);
const selectedDateRange = ref<'today' | 'week' | 'month' | 'custom'>('today');
const customStartDate = ref('');
const customEndDate = ref('');

const filteredEvents = computed(() => {
  // Implement date filtering logic here
  return events.value;
});

const handleFilter = (filters: any[]) => {
  console.log('Applying filters:', filters);
  // Implement filter logic here
};

const exportEvents = () => {
  // Implement export logic
  console.log('Exporting events...');
};
</script>

<template>
  <div class="bg-white shadow rounded-lg">
    <!-- Header -->
    <div class="px-6 py-4 border-b border-gray-200">
      <div class="flex justify-between items-center">
        <h2 class="text-lg font-semibold text-gray-900">Event Log</h2>
        <div class="flex space-x-4">
          <div class="relative">
            <input
              type="text"
              placeholder="Search events..."
              class="w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
            />
            <Search class="h-5 w-5 text-gray-400 absolute left-3 top-2.5" />
          </div>
          <button 
            @click="exportEvents"
            class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <Download class="h-4 w-4 mr-2" />
            Export
          </button>
        </div>
      </div>
    </div>

    <!-- Quick Filters -->
    <div class="px-6 py-4 border-b border-gray-200">
      <div class="flex items-center space-x-4">
        <span class="text-sm font-medium text-gray-700">Time Range:</span>
        <div class="flex space-x-2">
          <button
            v-for="range in ['today', 'week', 'month', 'custom']"
            :key="range"
            @click="selectedDateRange = range"
            :class="[
              'px-3 py-2 text-sm font-medium rounded-md',
              selectedDateRange === range
                ? 'bg-blue-100 text-blue-700'
                : 'text-gray-700 hover:bg-gray-100'
            ]"
          >
            {{ range.charAt(0).toUpperCase() + range.slice(1) }}
          </button>
        </div>
      </div>

      <!-- Custom Date Range -->
      <div v-if="selectedDateRange === 'custom'" class="mt-4 flex items-center space-x-4">
        <div>
          <label class="block text-sm font-medium text-gray-700">Start Date</label>
          <input
            v-model="customStartDate"
            type="date"
            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700">End Date</label>
          <input
            v-model="customEndDate"
            type="date"
            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>
    </div>

    <!-- Advanced Filter -->
    <AdvancedFilter type="events" @filter="handleFilter" />

    <!-- Events Table -->
    <div class="p-6">
      <EventTable :events="filteredEvents" />
    </div>
  </div>
</template>