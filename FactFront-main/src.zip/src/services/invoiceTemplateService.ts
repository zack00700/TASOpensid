import api from '../plugin/axios';

export interface InvoiceTemplate {
  id?: string;
  name: string;
  expressDesignId?: string;
  bindings?: Record<string, any>;
  pageSettings?: Record<string, any>;
  studioProject?: any; // Données complètes du projet GrapesJS
  html?: string; // HTML du template (pour compatibilité)
  css?: string; // CSS du template (pour compatibilité)
  status?: string;
  thumbnailUrl?: string;
  lastModified?: string;
  version?: string;
}

export async function listTemplates(): Promise<InvoiceTemplate[]> {
  const res = await api.get('/invoice-templates');
  return res.data;
}

export async function getTemplate(id: string): Promise<InvoiceTemplate> {
  const res = await api.get(`/invoice-templates/${encodeURIComponent(id)}`);
  return res.data;
}

export async function createTemplate(payload: InvoiceTemplate): Promise<InvoiceTemplate> {
  const res = await api.post('/invoice-templates', payload);
  return res.data;
}

export async function updateTemplate(id: string, payload: InvoiceTemplate): Promise<InvoiceTemplate> {
  const res = await api.put(`/invoice-templates/${encodeURIComponent(id)}`, payload);
  return res.data;
}

export async function previewTemplate(id: string, body: any): Promise<Blob> {
  const res = await api.post(`/invoice-templates/${encodeURIComponent(id)}/preview`, body, {
    responseType: 'blob',
  });
  return res.data;
}

export default {
  listTemplates,
  getTemplate,
  createTemplate,
  updateTemplate,
  previewTemplate,
};