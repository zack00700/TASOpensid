import axios from 'axios';
import authService from '../services/authService';

// Use the VITE_API_URL environment variable when available. Otherwise
// fall back to the local development API.
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8080/api',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Intercepteur pour ajouter automatiquement l'authentification
api.interceptors.request.use(
  (config) => {
    // Utiliser votre service d'auth existant pour obtenir les headers
    const authHeaders = authService.getAuthHeaders();
    
    // Fusionner avec les headers existants
    if (authHeaders) {
      config.headers = { ...config.headers, ...authHeaders };
    }
    
    return config;
  },
  (error) => {
    console.error('Request interceptor error:', error);
    return Promise.reject(error);
  }
);

// Intercepteur pour gérer les réponses d'erreur d'authentification
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Si erreur 401, utiliser la logique existante de votre système d'auth
    if (error.response?.status === 401) {
      console.warn('Authentication failed (401)');
      
      // Utiliser votre système existant pour gérer la déconnexion
      authService.logout();
      
      // Émettre un événement pour que votre composable useAuth puisse réagir
      window.dispatchEvent(new CustomEvent('auth-error', { 
        detail: { message: 'Session expired', status: 401 } 
      }));
    }
    
    return Promise.reject(error);
  }
);

export default api;