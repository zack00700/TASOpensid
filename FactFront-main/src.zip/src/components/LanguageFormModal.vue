<script setup lang="ts">
import { ref, watch } from 'vue';
import type { Language } from '../types/i18nFields';

interface Props {
  modelValue: boolean;
  language?: Partial<Language> | null;
}
const props = defineProps<Props>();
const emit = defineEmits<{
  (e: 'update:modelValue', v: boolean): void;
  (e: 'save', lang: Partial<Language>): void;
}>();

const code = ref('');
const name = ref('');
const enabled = ref(true);

watch(
  () => props.modelValue,
  (v) => {
    if (v) {
      code.value = props.language?.code || '';
      name.value = props.language?.name || '';
      enabled.value = props.language?.enabled ?? true;
    }
  },
  { immediate: true },
);

function close() {
  emit('update:modelValue', false);
}
function submit() {
  emit('save', { code: code.value, name: name.value, enabled: enabled.value });
}
</script>

<template>
  <div v-if="modelValue" class="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
    <div class="bg-white p-4 rounded w-96">
      <h3 class="text-lg font-bold mb-2">{{ language?.code ? 'Edit' : 'Add' }} Language</h3>
      <div class="space-y-2">
        <label class="block">
          <span class="text-sm">Code</span>
          <input v-model="code" :disabled="!!language?.code" class="border p-1 w-full" />
        </label>
        <label class="block">
          <span class="text-sm">Name</span>
          <input v-model="name" class="border p-1 w-full" />
        </label>
        <label class="inline-flex items-center gap-2">
          <input type="checkbox" v-model="enabled" />
          <span>Enabled</span>
        </label>
      </div>
      <div class="mt-4 flex justify-end gap-2">
        <button class="px-3 py-1 border" @click="close">Cancel</button>
        <button class="px-3 py-1 bg-blue-500 text-white" @click="submit">Save</button>
      </div>
    </div>
  </div>
</template>
