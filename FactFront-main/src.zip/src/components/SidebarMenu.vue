<template>
  <div class="flex shrink-0 h-full">
    <aside
      v-if="isOpen"
      class="w-72 shrink-0 bg-gradient-to-b from-slate-50 to-white border-r border-slate-200/60 flex flex-col h-full shadow-sm backdrop-blur-sm"
    >
      <!-- Header with User Info -->
      <div class="p-6 border-b border-slate-200/50">
        <div
          class="flex items-center space-x-3 p-4 rounded-xl bg-gradient-to-r from-slate-50 to-white hover:from-slate-100 hover:to-slate-50 transition-all duration-200 cursor-pointer shadow-sm"
        >
          <div
            class="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center shadow-md"
          >
            <User class="w-6 h-6 text-white" />
          </div>
          <div class="flex-1 min-w-0">
            <p class="text-lg font-semibold text-slate-800 truncate">Admin User</p>
            <p class="text-sm text-slate-500 truncate">admin@factfront.com</p>
          </div>
          <button
            class="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100/70 transition-all duration-200"
          >
            <Settings class="w-5 h-5" />
          </button>
        </div>
      </div>

      <!-- Sidebar Navigation -->
      <nav class="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        <section
          v-for="section in sections"
          :key="section.key"
          class="mb-6 last:mb-0"
        >
          <button
            :data-test="`section-${section.title}`"
            @click="toggleSection(section)"
            class="flex items-center w-full px-3 py-3 text-slate-700 hover:bg-slate-100/70 focus:outline-none focus:ring-2 focus:ring-blue-500/20 rounded-xl transition-all duration-200 group"
            :aria-expanded="section.open"
            :aria-controls="`section-${section.key}-list`"
          >
            <div
              class="flex items-center justify-center w-9 h-9 rounded-lg bg-gradient-to-br from-slate-100 to-slate-200/50 group-hover:from-slate-200 group-hover:to-slate-300/50 transition-all duration-200 mr-3"
            >
              <component :is="section.icon" class="w-4 h-4 text-slate-600" />
            </div>
            <span class="flex-1 text-sm font-medium text-left">{{ section.title }}</span>

            <ChevronRight
              class="w-4 h-4 transition-all duration-300 text-slate-400"
              :class="{ 'rotate-90 text-slate-600': section.open }"
              :aria-label="`Toggle ${section.title}`"
            />
          </button>

          <!-- Menu Items -->
          <div
            :id="`section-${section.key}-list`"
            class="overflow-hidden transition-all duration-300 ease-out"
            :class="section.open ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'"
          >
            <ul class="mt-2 ml-3 pl-6 border-l border-slate-200/60 space-y-1">
              <li v-for="item in section.items" :key="item.name">
                <button
                  @click="setActive(item)"
                  :data-active="activeItem === item.name"
                  :data-test="`menu-item-${item.name.toLowerCase().replace(/\s+/g, '-')}`"
                  class="flex items-center w-full px-3 py-2.5 text-sm rounded-lg transition-all duration-200 group relative"
                  :class="
                    activeItem === item.name
                      ? 'bg-gradient-to-r from-blue-50 to-indigo-50 text-blue-700 shadow-sm border border-blue-200/50'
                      : 'text-slate-600 hover:bg-slate-100/50 hover:text-slate-700'
                  "
                >
                  <!-- Active indicator -->
                  <div
                    v-if="activeItem === item.name"
                    class="absolute left-0 top-1/2 transform -translate-y-1/2 w-1 h-6 bg-gradient-to-b from-blue-500 to-indigo-600 rounded-full -ml-3"
                  ></div>

                  <div
                    class="flex items-center justify-center w-7 h-7 rounded-md mr-3 transition-all duration-200"
                    :class="
                      activeItem === item.name
                        ? 'bg-blue-100/70 text-blue-600'
                        : 'text-slate-500 group-hover:text-slate-600'
                    "
                  >
                    <component :is="item.icon" class="w-4 h-4" />
                  </div>
                  <span class="font-medium">{{ item.name }}</span>
                </button>
              </li>
            </ul>
          </div>
        </section>
      </nav>
    </aside>

    <!-- Minimal, centered, auto-hiding Toggle -->
    <div
      class="fixed top-1/2 -translate-y-1/2 z-50 transition-all duration-300"
      :class="isOpen ? 'left-[288px]' : 'left-3'"
      @mouseenter="showToggle = true"
      @mouseleave="scheduleHide()"
    >
      <button
        @click="isOpen = !isOpen; scheduleHide(true)"
        class="relative flex items-center justify-center w-9 h-9 rounded-full bg-white/90 backdrop-blur border border-slate-200/60 shadow-sm transition-opacity duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30 hover:bg-white"
        :class="[
          showToggle ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        ]"
        :aria-label="isOpen ? 'Close sidebar' : 'Open sidebar'"
        :aria-hidden="!showToggle"
        :tabindex="showToggle ? 0 : -1"
      >
        <ChevronLeft v-if="isOpen" class="w-5 h-5 text-slate-700" />
        <ChevronRight v-else class="w-5 h-5 text-slate-700" />
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, onMounted, onUnmounted } from 'vue';
import { useRouter, useRoute } from '../router';
import {
  FileText,
  Package,
  Settings as SettingsIcon,
  Ship,
  ClipboardList,
  Calendar,
  Users,
  File,
  LayoutTemplate,
  User,
  Settings,
  ChevronRight,
  ChevronLeft,
  Briefcase,
  Cog,
  Languages,
} from 'lucide-vue-next';

interface MenuItem {
  name: string;
  icon: any;
  path: string;
}

interface MenuSection {
  key: string;
  title: string;
  icon: any;
  items: MenuItem[];
  open: boolean;
}

const props = defineProps<{
  operationsIcon?: any;
  configurationIcon?: any;
}>();

const sections = ref<MenuSection[]>([
  {
    key: 'operations',
    title: 'Operations',
    icon: props.operationsIcon || Briefcase,
    open: true,
    items: [
      { name: 'Invoices', icon: FileText, path: '/invoices' },
      { name: 'Items', icon: Package, path: '/items' },
      { name: 'Event Config', icon: SettingsIcon, path: '/events-config' },
      { name: 'Vessel Visits', icon: Ship, path: '/vessels' },
      { name: 'Bill of Lading', icon: ClipboardList, path: '/bills' },
    ],
  },
  {
    key: 'configuration',
    title: 'Configuration',
    icon: props.configurationIcon || Cog,
    open: false,
    items: [
      { name: 'Events', icon: Calendar, path: '/events' },
      { name: 'Vessels', icon: Ship, path: '/vessel-registry' },
      { name: 'Third-Party Users', icon: Users, path: '/users' },
      { name: 'Contracts', icon: File, path: '/contracts' },
      { name: 'Template Designer', icon: LayoutTemplate, path: '/template-designer' },
      { name: 'Fields', icon: Languages, path: '/i18n/fields' },
    ],
  },
]);

const STORAGE_KEY = 'sidebar:v1';

const activeItem = ref('');

const router = useRouter();
const route = useRoute();

// Function to find menu item name by path
const findItemNameByPath = (path: string): string => {
  for (const section of sections.value) {
    const item = section.items.find((item) => path.startsWith(item.path));
    if (item) return item.name;
  }
  return '';
};

// Set initial active item based on current route
onMounted(() => {
  activeItem.value = findItemNameByPath(route.path);

  const raw = localStorage.getItem(STORAGE_KEY);
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      sections.value.forEach((section) => {
        if (typeof parsed[section.key] === 'boolean') {
          section.open = parsed[section.key];
        }
      });
    } catch {
      /* ignore malformed */
    }
  }

  // Auto-hide initialization
  scheduleHide();
  window.addEventListener('mousemove', handleMouseMove, { passive: true });
  window.addEventListener('keydown', handleKeydown, { passive: true });
});

onUnmounted(() => {
  if (hideTimer) window.clearTimeout(hideTimer);
  window.removeEventListener('mousemove', handleMouseMove);
  window.removeEventListener('keydown', handleKeydown);
});

// Watch route for active item changes
watch(
  () => route.path,
  (newPath) => {
    activeItem.value = findItemNameByPath(newPath);
  }
);

// Watch sections for localStorage persistence
watch(
  sections,
  (newVal) => {
    const state: Record<string, boolean> = {};
    newVal.forEach((sec) => (state[sec.key] = sec.open));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  },
  { deep: true }
);

function toggleSection(section: MenuSection) {
  section.open = !section.open;
}

function setActive(item: MenuItem) {
  activeItem.value = item.name;
  router.push(item.path);
}

const isOpen = ref(true);

// --- Auto-hide toggle logic ---
const showToggle = ref(true);
let hideTimer: number | null = null;

// Hide after a short delay; immediate=true hides sooner after click
function scheduleHide(immediate = false) {
  if (hideTimer) {
    window.clearTimeout(hideTimer);
    hideTimer = null;
  }
  hideTimer = window.setTimeout(() => (showToggle.value = false), immediate ? 900 : 1500);
}

// Show when the cursor nears the left edge (or the sidebar edge if open)
function handleMouseMove(e: MouseEvent) {
  const threshold = isOpen.value ? 304 : 24; // a bit past the sidebar edge / near screen edge
  if (e.clientX <= threshold) {
    if (!showToggle.value) showToggle.value = true;
    scheduleHide();
  }
}

// Keep visible while the button is focused (keyboard users)
function handleKeydown() {
  showToggle.value = true;
  scheduleHide();
}
</script>

<style scoped>
/* No extra styles needed; Tailwind handles visuals */
</style>
