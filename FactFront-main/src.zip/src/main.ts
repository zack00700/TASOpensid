import { createApp } from 'vue';
import App from './App.vue';
import './index.css';
import axios from './plugin/axios';
import router from './router';

const app = createApp(App);
app.provide('$axios', axios);
app.use(router);
app.mount('#app');
