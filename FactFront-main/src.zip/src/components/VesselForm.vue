<script setup lang="ts">
import { ref, toRef, watch } from "vue";
import { X } from "lucide-vue-next";
import { Vessel } from "../types/vessel";
import { useVessel } from "../composables/use.vessel";

const props = defineProps<{
  editMode?: boolean;
  initialData?: Vessel | null;
}>();

const emit = defineEmits<{
  (e: "submit", data: Vessel): void;
  (e: "cancel"): void;
}>();

// Passer initialData au composable
const { formData, errors, validateForm, addVessel, updateVessel } = useVessel(toRef(props, 'initialData'));

const vesselTypes = [
  "Container Ship",
  "Bulk Carrier",
  "Tanker",
  "General Cargo",
  "Ro-Ro",
  "Car Carrier",
  "LNG Carrier",
  "Cruise Ship",
  "Trailing Suction Hopper Dredger",
  "TUG",
  "Offshore Supply Vessel",
  "Fishing Vessel",
  "Other"
];

const handleSubmit = async () => {
  if (!validateForm()) {
    return;
  }

  if (props.editMode) {
    await updateVessel();
  } else {
    await addVessel();
  }
  
  emit("submit", formData.value);
};

const getInputClasses = (fieldName: keyof Vessel) => {
  return {
    "mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500": true,
    "border-red-300": errors.value[fieldName],
  };
};

// Debug : log pour vérifier que les données arrivent
watch(() => props.initialData, (newData) => {
  console.log('VesselForm received initialData:', newData);
}, { immediate: true });

watch(formData, (newFormData) => {
  console.log('VesselForm formData updated:', newFormData);
}, { deep: true });
</script>

<template>
  <div class="bg-white shadow rounded-lg">
    <div class="px-6 py-4 border-b border-gray-200">
      <div class="flex justify-between items-center">
        <h2 class="text-lg font-semibold text-gray-900">
          {{ editMode ? "Edit Vessel" : "New Vessel" }}
        </h2>
        <button @click="emit('cancel')" class="text-gray-400 hover:text-gray-500">
          <X class="h-6 w-6" />
        </button>
      </div>
    </div>

    <form @submit.prevent="handleSubmit" class="p-6 space-y-6">
      <!-- Basic Information -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Basic Information</h3>
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <label class="block text-sm font-medium text-gray-700">
              Vessel Name <span class="text-red-500">*</span>
            </label>
            <input 
              v-model="formData.name" 
              type="text" 
              :class="getInputClasses('name')" 
            />
            <p v-if="errors.name" class="mt-1 text-sm text-red-600">
              {{ errors.name }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              IMO Number <span class="text-red-500">*</span>
            </label>
            <input
              v-model="formData.imoNumber"
              type="text"
              placeholder="IMO1234567"
              :class="getInputClasses('imoNumber')"
            />
            <p v-if="errors.imoNumber" class="mt-1 text-sm text-red-600">
              {{ errors.imoNumber }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Call Sign <span class="text-red-500">*</span>
            </label>
            <input
              v-model="formData.callSign"
              type="text"
              :class="getInputClasses('callSign')"
            />
            <p v-if="errors.callSign" class="mt-1 text-sm text-red-600">
              {{ errors.callSign }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Flag <span class="text-red-500">*</span>
            </label>
            <input 
              v-model="formData.flag" 
              type="text" 
              :class="getInputClasses('flag')" 
            />
            <p v-if="errors.flag" class="mt-1 text-sm text-red-600">
              {{ errors.flag }}
            </p>
          </div>
        </div>
      </div>

      <!-- Owner/Operator Information -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Owner/Operator Information</h3>
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <label class="block text-sm font-medium text-gray-700">
              Owner <span class="text-red-500">*</span>
            </label>
            <input
              v-model="formData.owner"
              type="text"
              :class="getInputClasses('owner')"
            />
            <p v-if="errors.owner" class="mt-1 text-sm text-red-600">
              {{ errors.owner }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700"> Operator </label>
            <input
              v-model="formData.operator"
              type="text"
              :class="getInputClasses('operator')"
            />
          </div>
        </div>
      </div>

      <!-- Vessel Details -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Vessel Details</h3>
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <label class="block text-sm font-medium text-gray-700">
              Vessel Type <span class="text-red-500">*</span>
            </label>
            <select 
              v-model="formData.vesselType" 
              :class="getInputClasses('vesselType')"
            >
              <option value="">Select vessel type</option>
              <option v-for="type in vesselTypes" :key="type" :value="type">
                {{ type }}
              </option>
            </select>
            <p v-if="errors.vesselType" class="mt-1 text-sm text-red-600">
              {{ errors.vesselType }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700"> Status </label>
            <select 
              v-model="formData.status" 
              :class="getInputClasses('status')"
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Form Actions -->
      <div class="flex justify-end space-x-3">
        <button
          type="button"
          @click="emit('cancel')"
          class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
        >
          Cancel
        </button>
        <button
          type="submit"
          class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          {{ editMode ? "Save Changes" : "Create Vessel" }}
        </button>
      </div>
    </form>


  </div>
</template>