// frontend/utils/normalize.ts
export function normalizeItem(doc: any) {
  if (!doc) return doc;
  const oid =
    doc?.id ??
    doc?._id?.$oid ??
    doc?._id ??
    null;

  const { _id, id, ...rest } = doc;
  return { ...rest, id: oid };
}
