export type FieldType =
  | 'text'
  | 'number'
  | 'boolean'
  | 'date'
  | 'datetime'
  | 'currency'
  | 'select'
  | 'multiselect'
  | 'textarea';

export interface FieldDef {
  field: string;
  name: string;
  type: FieldType;
  required: boolean;
  default?: string | number | boolean | string[];
  deprecated?: boolean;
}

export interface EntityDef {
  entity: string;
  name: string;
  fields: FieldDef[];
}

export interface Language {
  code: string; // _id
  name: string;
  enabled: boolean;
  entities: EntityDef[];
  createdAt?: string;
  updatedAt?: string;
}
