// stores/i18nFieldsStore.ts - Simple reactive store using existing service
import { ref, reactive } from 'vue'
import * as service from '../services/i18nFieldsService'
import { normalizeLanguage } from '../utils/i18nFieldsNormalizer'

console.log('🔵 Creating service-based store using existing service...')
console.log('🔵 Service import:', service)
console.log('🔵 Service.fetchLanguages:', service.fetchLanguages)

// Create global reactive state
const state = {
  languages: ref<any[]>([]),
  pagination: reactive({
    total: 0,
    limit: 10,
    offset: 0
  }),
  loading: ref(false),
  error: ref<string | null>(null)
}

async function fetchLanguages(params: { 
  q?: string; 
  enabled?: boolean; 
  limit?: number; 
  offset?: number 
} = {}) {
  console.log('🔵 fetchLanguages called with:', params)
  
  try {
    state.loading.value = true
    state.error.value = null
    
    console.log('🔵 Using existing service to fetch languages...')
    
    // Use your existing service which handles axios configuration
    const response = await service.fetchLanguages(params)
    console.log('🔵 Service response:', response)
    
    // Extract items from the normalized payload (from your service)
    const items = response.items || []
    
    console.log('🔵 Items to normalize:', items)
    
    // Normalize each language using your existing normalizer
    state.languages.value = items.map((item: any) => {
      try {
        return normalizeLanguage(item)
      } catch (normError) {
        console.error('Error normalizing language:', item, normError)
        // Return a basic normalized version on error
        return {
          code: item.code || item.id || 'unknown',
          name: item.name || 'Unknown',
          enabled: Boolean(item.enabled),
          entities: [],
          createdAt: item.createdAt,
          updatedAt: item.updatedAt
        }
      }
    })
    
    // Update pagination from service response
    state.pagination.total = response.total || 0
    state.pagination.limit = response.limit || 10
    state.pagination.offset = response.offset || 0
    
    console.log('✅ Final store state:', {
      languages: state.languages.value,
      pagination: state.pagination
    })
    
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : 'Failed to fetch languages'
    state.error.value = errorMessage
    console.error('❌ Error fetching languages:', err)
    
    // Log more details for debugging
    if (err instanceof Error && 'response' in err) {
      console.error('API Response:', (err as any).response?.data)
      console.error('API Status:', (err as any).response?.status)
      console.error('API URL:', (err as any).config?.url)
    }
    
    // Ensure arrays are still initialized on error
    state.languages.value = []
    state.pagination.total = 0
    state.pagination.limit = 10
    state.pagination.offset = 0
  } finally {
    state.loading.value = false
  }
}

async function createOrUpsertLanguage(payload: any, options: { upsert?: boolean } = {}) {
  console.log('🔵 createOrUpsertLanguage called')
  
  try {
    state.loading.value = true
    state.error.value = null
    
    // Use your existing service
    const result = await service.createOrUpsertLanguage(payload, options.upsert ?? true)
    return normalizeLanguage(result)
  } catch (err) {
    state.error.value = err instanceof Error ? err.message : 'Failed to create/update language'
    throw err
  } finally {
    state.loading.value = false
  }
}

async function updateLanguage(code: string, payload: any) {
  console.log('🔵 updateLanguage called')
  
  try {
    state.loading.value = true
    state.error.value = null
    
    // Use your existing service
    const result = await service.updateLanguage(code, payload)
    return normalizeLanguage(result)
  } catch (err) {
    state.error.value = err instanceof Error ? err.message : 'Failed to update language'
    throw err
  } finally {
    state.loading.value = false
  }
}

async function deleteLanguage(code: string) {
  console.log('🔵 deleteLanguage called')
  
  try {
    state.loading.value = true
    state.error.value = null
    
    // Use your existing service
    await service.deleteLanguage(code)
  } catch (err) {
    state.error.value = err instanceof Error ? err.message : 'Failed to delete language'
    throw err
  } finally {
    state.loading.value = false
  }
}

// Export composable function
export function useI18nFieldsStore() {
  console.log('✅ Simple reactive store accessed')
  
  return {
    languages: state.languages,
    pagination: state.pagination,
    loading: state.loading,
    error: state.error,
    fetchLanguages,
    createOrUpsertLanguage,
    updateLanguage,
    deleteLanguage
  }
}