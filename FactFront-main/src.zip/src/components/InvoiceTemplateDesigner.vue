<script setup lang="ts">
import { ref } from 'vue';
import TemplateList from './TemplateList.vue';
import TemplateEditor from './TemplateEditor.vue';

const enabled = import.meta.env.VITE_FEATURE_ADOBE_EXPRESS === 'true';
const activeId = ref<string | null>(null);

function openEditor(id?: string) {
  activeId.value = id ?? '';
}

function closeEditor() {
  activeId.value = null;
}
</script>

<template>
  <div class="h-full" v-if="enabled">
    <TemplateList v-if="activeId === null" @edit="openEditor" />
    <TemplateEditor v-else :id="activeId" @close="closeEditor" />
  </div>
  <div v-else class="p-4 text-gray-600">Adobe Express template editor disabled.</div>
</template>

<style scoped>
</style>
