import { ref, computed, reactive } from 'vue';
import authService from '../services/authService';

interface User {
  id: string;
  username: string;
  email?: string;
  role?: string;
}

interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  loading: boolean;
  error: string | null;
}

// État global partagé entre toutes les instances du composable
const globalState = reactive<AuthState>({
  isAuthenticated: false,
  user: null,
  loading: false,
  error: null,
});

// Initialiser l'état au chargement
function initializeAuth() {
  globalState.isAuthenticated = authService.isAuthenticated();
  globalState.user = authService.getUser();
}

// Initialiser immédiatement
initializeAuth();

export function useAuth() {
  /**
   * Connexion
   */
  async function login(username: string, password: string): Promise<boolean> {
    console.log('🔍 useAuth.login appelé avec:', username);
    
    globalState.loading = true;
    globalState.error = null;

    try {
      console.log('📞 Appel authService.login...');
      const response = await authService.login({ username, password });
      console.log('✅ authService.login réussi:', response);
      
      globalState.isAuthenticated = true;
      globalState.user = response.user;
      
      return true;
    } catch (error: any) {
      console.error('❌ Erreur dans useAuth.login:', error);
      globalState.error = error.message || 'Erreur de connexion';
      return false;
    } finally {
      globalState.loading = false;
    }
  }

  /**
   * Déconnexion
   */
  async function logout(): Promise<void> {
    globalState.loading = true;
    
    try {
      await authService.logout();
    } catch (error) {
      console.error('Erreur lors de la déconnexion:', error);
    } finally {
      globalState.isAuthenticated = false;
      globalState.user = null;
      globalState.loading = false;
      globalState.error = null;
    }
  }

  /**
   * Vérifier l'authentification
   */
  function checkAuth(): boolean {
    const isAuth = authService.isAuthenticated();
    globalState.isAuthenticated = isAuth;
    
    if (!isAuth) {
      globalState.user = null;
    }
    
    return isAuth;
  }

  /**
   * Rediriger si non authentifié
   */
  function requireAuth(): boolean {
    if (!checkAuth()) {
      redirectToLogin();
      return false;
    }
    return true;
  }

  /**
   * Rediriger vers la page de connexion
   */
  function redirectToLogin(): void {
    // Sauvegarder l'URL actuelle pour redirection après connexion
    const currentPath = window.location.pathname + window.location.search;
    if (currentPath !== '/login') {
      sessionStorage.setItem('redirectAfterLogin', currentPath);
    }
    
    window.location.href = '/login';
  }

  /**
   * Rediriger après connexion réussie
   */
  function redirectAfterLogin(): void {
    // Récupérer l'URL sauvegardée ou rediriger vers la page d'accueil
    const redirectUrl = sessionStorage.getItem('redirectAfterLogin') || '/';
    sessionStorage.removeItem('redirectAfterLogin');
    
    window.location.href = redirectUrl;
  }

  /**
   * Effacer les erreurs
   */
  function clearError(): void {
    globalState.error = null;
  }

  /**
   * Obtenir les en-têtes d'authentification pour les requêtes
   */
  function getAuthHeaders(): HeadersInit {
    return authService.getAuthHeaders();
  }

  /**
   * Wrapper pour les requêtes authentifiées
   */
  async function authenticatedFetch(url: string, options: RequestInit = {}): Promise<Response> {
    return authService.authenticatedFetch(url, options);
  }

  /**
   * Vérifier si l'utilisateur a un rôle spécifique (pour les rôles complexes)
   */
  function hasRole(roleName: string): boolean {
    if (!globalState.user) return false;
    
    // Si l'utilisateur a un tableau de rôles
    if (globalState.user.roles && Array.isArray(globalState.user.roles)) {
      return globalState.user.roles.includes(roleName);
    }
    
    // Fallback sur le rôle simple
    return globalState.user.role === roleName;
  }

  /**
   * Vérifier si l'utilisateur a les permissions d'admin
   */
  function isAdmin(): boolean {
    return hasRole('ROLE_ADMIN') || hasRole('ROLE_TEMPLATES_ADMIN') || userRole.value === 'admin';
  }

  // Propriétés calculées
  const isAuthenticated = computed(() => globalState.isAuthenticated);
  const user = computed(() => globalState.user);
  const loading = computed(() => globalState.loading);
  const error = computed(() => globalState.error);
  const userRole = computed(() => globalState.user?.role);
  const userName = computed(() => globalState.user?.username);
  const userRoles = computed(() => globalState.user?.roles || []); // Nouveau: accès aux rôles complets

  return {
    // État
    isAuthenticated,
    user,
    loading,
    error,
    userRole,
    userName,
    userRoles, // Nouveau
    
    // Actions
    login,
    logout,
    checkAuth,
    requireAuth,
    redirectToLogin,
    redirectAfterLogin,
    clearError,
    getAuthHeaders,
    authenticatedFetch,
    hasRole, // Nouveau
    isAdmin, // Nouveau
  };
}