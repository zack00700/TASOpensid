<script setup lang="ts">
import { ref, inject, computed, watch, reactive } from "vue";
import { v4 as uuidv4 } from "uuid";
import {
  Search,
  Download,
  X,
  Clock,
  Plus,
  Pencil,
  Trash2,
  History,
  MoreVertical,
  BadgeDollarSign,
  Check,
} from "lucide-vue-next";
import AdvancedFilter from "./AdvancedFilter.vue";
import ItemForm from "./ItemForm.vue";
import AddItemEventModal from "./AddItemEventModal.vue";
import ItemEventHistory from "./ItemEventHistory.vue";
import KebabMenu from "./KebabMenu.vue";
import { Item, Event } from "../types/item";
import { ItemService } from "../services/itemService";

const itemService = ItemService.getInstance();
const $axios = inject('$axios');

import { useItem } from "../composables/use.item.ts";
const { items, draftInvoice, getItems } = useItem();

/*const items = ref<Item[]>([
  {
    id: "CMAU5984269",
    itemType: "container",
    type: "40HC",
    ownerId: "50005Q",
    status: "Available",
    currentLifecycleId: undefined,
    lifeCycles: [],
    position: "P-ABJ-1G81G1",
  },
]);*/

const showForm = ref(false);
const editingItem = ref<Item | null>(null);
const showDeleteConfirm = ref(false);
const itemToDelete = ref<Item | null>(null);
const showHistory = ref(false);
const showEventForm = ref(false);
const selectedItemForEvent = ref<Item | null>(null);
const selectedItemForHistory = ref<Item | null>(null);
const historyRef = ref<any>(null);
const showCustomerToBillModal = ref(false);
const selectedItemIds = ref<string[]>([]);
const customerToBill = ref("");

// row actions menu handled per-row by KebabMenu component


const handleFilter = (filters: any[]) => {
  console.log("Applying filters:", filters);
  // Implement filter logic here
};

const handleAdd = () => {
  editingItem.value = null;
  showForm.value = true;
};

const handleEdit = (item: Item) => {
  // Convert Item to ItemFormData format
  const formData = {
    _id: item.id,
    itemNumber: item.itemNumber || "",
    itemType: item.itemType || "",
    type: item.type || "",
    ownerId: item.ownerId || "",
    position: item.position || "",
    status: item.status || "Available",
    lastInspection: item.lastInspectionDate?.toString() || "",
    nextInspection: item.nextInspectionDate?.toString() || "",
    notes: (item as any).notes || "",
    lifeCycles: item.lifeCycles || [],
  };

  editingItem.value = formData;
  showForm.value = true;
};

const handleDelete = (item: Item) => {
  itemToDelete.value = item;
  showDeleteConfirm.value = true;
};

const confirmDelete = () => {
  if (itemToDelete.value) {
    items.value = items.value.filter((i) => i.id !== itemToDelete.value?.id);
    showDeleteConfirm.value = false;
    itemToDelete.value = null;
  }
};

const handleFormSubmit = (formData: any) => {
  if (editingItem.value) {
    const index = items.value.findIndex((i) => i.id === formData._id);
    if (index !== -1) {
      items.value[index] = {
        itemNumber: formData.itemNumber,
        itemType: formData.itemType,
        type: formData.type,
        ownerId: formData.ownerId,
        status: formData.status,
        position: formData.position,
        currentLifecycleId: items.value[index].currentLifecycleId,
        lifeCycles: formData.lifeCycles,
      };
    }
  } else {
    items.value.push({
      itemNumber: formData.itemNumber,
      itemType: formData.itemType,
      type: formData.type,
      ownerId: formData.ownerId,
      status: formData.status,
      position: formData.position,
      currentLifecycleId: undefined,
      lifeCycles: [],
    });
  }

  showForm.value = false;
  editingItem.value = null;
};

const handleFormCancel = () => {
  showForm.value = false;
  editingItem.value = null;
};

const handleViewHistory = (item: Item) => {
  selectedItemForHistory.value = item;
  showHistory.value = true;
};

const handleStartLifecycle = async (item: Item) => {
  try {
    const event: Event = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      type: "IN",
      itemId: item.id,
      lifecycleId: "",
      location: item.position,
    };

    const index = items.value.findIndex((i) => i.id === item.id);
    if (index !== -1) {
      await itemService.addEvent(item, event);
      const response = await $axios.get(`/item/${item.id}`);
      items.value[index] = response.data;
    }
  } catch (error) {
    console.error("Error starting lifecycle:", error);
    // Handle error (show notification, etc.)
  }
};

const handleEndLifecycle = async (item: Item) => {
  try {
    const event: Event = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      type: "OUT",
      itemId: item.id,
      lifecycleId: item.currentLifecycleId!,
      location: item.position,
    };

    const index = items.value.findIndex((i) => i.id === item.id);
    if (index !== -1) {
      await itemService.addEvent(item, event);
      const response = await $axios.get(`/item/${item.id}`);
      items.value[index] = response.data;
    }
  } catch (error) {
    console.error("Error ending lifecycle:", error);
    // Handle error (show notification, etc.)
  }
};

const handleAddEvent = (item: Item) => {
  selectedItemForEvent.value = item;
  showEventForm.value = true;
};

const handleEventSuccess = () => {
  const id = selectedItemForEvent.value?.id;
  showEventForm.value = false;
  selectedItemForEvent.value = null;
  alert('Event added');
  if (showHistory.value && selectedItemForHistory.value?.id === id) {
    historyRef.value?.refresh();
  }
};

const handleEventCancel = () => {
  showEventForm.value = false;
  selectedItemForEvent.value = null;
};

const handleHistoryClose = () => {
  showHistory.value = false;
  selectedItemForHistory.value = null;
};

const handleCustomerToBill = () => {
  showCustomerToBillModal.value = true;
};

const billCustomer = async () => {
  console.log(selectedItemIds.value);
  console.log(customerToBill.value);
  try {
    await draftInvoice(selectedItemIds.value, customerToBill.value);
    await getItems();
    showCustomerToBillModal.value = false;
    alert('Invoice generated');
  } catch (error) {
    console.error('Failed to generate invoice:', error);
    alert('Failed to generate invoice');
  }
};

// --- Invoice handling ---
const invoices = ref<Record<string, any>>({});
const loadingInvoices = reactive(new Set<string>());
const invoiceErrors = reactive(new Set<string>());

async function fetchInvoice(invoiceId: string, force = false) {
  if (!invoiceId) return;
  if (!force && invoices.value[invoiceId]) return;
  if (loadingInvoices.has(invoiceId)) return;

  loadingInvoices.add(invoiceId);
  invoiceErrors.delete(invoiceId);

  try {
    const { data } = await $axios.get(`/invoice/${encodeURIComponent(invoiceId)}`);
    invoices.value[invoiceId] = data;
  } catch (e) {
    invoiceErrors.add(invoiceId);
  } finally {
    loadingInvoices.delete(invoiceId);
  }
}

watch(
  items,
  (newItems) => {
    (newItems ?? []).forEach((it) => {
      const id = (it as any).relatedInvoice;
      if (id) fetchInvoice(id);
    });
  },
  { immediate: true }
);

type InvoiceState = 'DRAFT' | 'FINAL' | 'NONE' | 'LOADING' | 'ERROR';

function deriveInvoice(
  item: Item
): { state: InvoiceState; label: string; tooltip: string } {
  const invoiceId = (item as any).relatedInvoice;
  if (!invoiceId)
    return { state: 'NONE', label: '—', tooltip: 'No invoice' };

  if (loadingInvoices.has(invoiceId))
    return { state: 'LOADING', label: 'Loading...', tooltip: 'Loading invoice...' };

  if (invoiceErrors.has(invoiceId))
    return { state: 'ERROR', label: 'Error', tooltip: 'Failed to load invoice' };

  const inv = invoices.value[invoiceId];
  if (!inv)
    return { state: 'NONE', label: '—', tooltip: 'No invoice' };

  if (inv.status === 'DRAFT')
    return {
      state: 'DRAFT',
      label: 'Draft',
      tooltip: inv.draftNumber ? `Draft invoice: ${inv.draftNumber}` : 'Draft invoice',
    };
  if (inv.status === 'FINAL' || inv.status === 'ISSUED')
    return {
      state: 'FINAL',
      label: 'Invoiced',
      tooltip: inv.finalNumber ? `Final invoice: ${inv.finalNumber}` : 'Final invoice',
    };
  return { state: 'NONE', label: '—', tooltip: 'No invoice' };
}

const viewItems = computed(() =>
  (items.value ?? []).map((it) => ({
    ...it,
    _invoice: deriveInvoice(it as Item),
  }))
);

function invoicePillClass(state: InvoiceState) {
  switch (state) {
    case 'FINAL':
      return 'bg-green-50 text-green-700 ring-green-600/20';
    case 'DRAFT':
      return 'bg-amber-50 text-amber-700 ring-amber-600/20';
    default:
      return 'bg-gray-50 text-gray-600 ring-gray-500/20';
  }
}

const getStatusBadgeClasses = (status: string) => {
  const baseClasses = "px-2 py-1 text-xs font-medium rounded-full";
  switch (status) {
    case "Available":
      return `${baseClasses} bg-green-100 text-green-800`;
    case "In Use":
      return `${baseClasses} bg-blue-100 text-blue-800`;
    case "Maintenance":
      return `${baseClasses} bg-yellow-100 text-yellow-800`;
    case "Out of Service":
      return `${baseClasses} bg-red-100 text-red-800`;
    default:
      return baseClasses;
  }
};

</script>

<template>
  <div>
    <!-- List View -->
    <div v-if="!showForm && !showHistory" class="bg-white shadow rounded-lg">
      <!-- Header -->
      <div class="px-6 py-4 border-b border-gray-200">
        <div class="flex justify-between items-center">
          <div>
            <nav aria-label="Breadcrumb" class="mb-1 text-sm text-gray-500">
              Home / Items
            </nav>
            <h2 class="text-lg font-semibold text-gray-900">Item List</h2>
          </div>
          <div class="flex space-x-4">
            <div class="relative">
              <input
                type="text"
                aria-label="Search items"
                placeholder="Search..."
                class="w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
              <Search class="h-5 w-5 text-gray-400 absolute left-3 top-2.5" />
            </div>
            <button
              @click="handleAdd"
              class="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
            >
              <Plus class="h-4 w-4 mr-2" />
              Add Item
            </button>
            <button
              class="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
              @click="handleCustomerToBill"
            >
              <BadgeDollarSign class="h-4 w-4 mr-2" />
              Make Invoice
            </button>
            <button
              class="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              aria-label="Export items"
            >
              <Download class="h-4 w-4 mr-2" />
              Export
            </button>
          </div>
        </div>
      </div>

      <!-- Advanced Filter -->
      <AdvancedFilter type="items" @filter="handleFilter" />

      <!-- Table -->
      <div class="px-6">
        <div class="overflow-x-auto -mx-6">
          <table class="min-w-[1000px] w-full table-auto divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th></th>
                <th
                  scope="col"
                  class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-48"
                >
                  Item Number
                </th>
                <th
                  scope="col"
                  class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Item Type
                </th>
                <th
                  scope="col"
                  class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Type
                </th>
                <th
                  scope="col"
                  class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-32"
                >
                  Owner Code
                </th>
                <th
                  scope="col"
                  class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Position
                </th>
                <th
                  scope="col"
                  class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Status
                </th>
                <th
                  scope="col"
                  class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Invoice
                </th>
                <th
                  scope="col"
                  class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Actions
                </th>
              </tr>
            </thead>
            <tbody
              v-if="viewItems.length"
              class="bg-white divide-y divide-gray-200"
            >
              <tr
                v-for="it in viewItems"
                :key="it.id"
                class="hover:bg-gray-50 cursor-pointer"
                @dblclick="handleEdit(it)"
              >
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  <input
                    v-if="it._invoice.state === 'NONE'"
                    type="checkbox"
                    :id="it.id"
                    :value="it.id"
                    v-model="selectedItemIds"
                    class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                  />
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {{ it.itemNumber }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {{ it.itemType }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {{ it.type }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {{ it.ownerId }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {{ it.position }}
                </td>

                <td class="px-6 py-4 whitespace-nowrap">
                  <span :class="getStatusBadgeClasses(it.status)">
                    {{ it.status }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <div class="flex items-center space-x-1">
                    <span v-if="it._invoice.state === 'LOADING'">Loading...</span>
                    <span v-else-if="it._invoice.state === 'ERROR'">Error</span>
                    <span
                      v-else-if="it._invoice.state !== 'NONE'"
                      class="inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-medium ring-1 ring-inset"
                      :class="invoicePillClass(it._invoice.state)"
                      :title="it._invoice.tooltip"
                      :aria-label="it._invoice.tooltip"
                    >
                      <component
                        :is="it._invoice.state === 'FINAL' ? Check : Pencil"
                        class="w-3 h-3"
                      />
                      {{ it._invoice.label }}
                    </span>
                    <span v-else>—</span>
                  </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <KebabMenu>
                    <template #trigger="{ toggle, refEl, isOpen }">
                      <button
                        class="text-gray-600 hover:text-gray-900 p-2 rounded hover:bg-gray-100"
                        @click.stop="toggle()"
                        :ref="refEl"
                        aria-label="Item actions"
                        :aria-expanded="isOpen ? 'true' : 'false'"
                      >
                        <MoreVertical class="h-5 w-5" />
                      </button>
                    </template>
                    <template #content="{ close }">
                      <button
                        class="flex w-full items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100"
                        role="menuitem"
                        @click="handleViewHistory(it); close()"
                      >
                        <History class="w-4 h-4" />
                        <span>Event History</span>
                      </button>
                      <button
                        class="flex w-full items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100"
                        role="menuitem"
                        @click="handleAddEvent(it); close()"
                      >
                        <Clock class="w-4 h-4" />
                        <span>Add Event</span>
                      </button>
                      <button
                        class="flex w-full items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100"
                        role="menuitem"
                        @click="handleEdit(it); close()"
                      >
                        <Pencil class="w-4 h-4" />
                        <span>Edit</span>
                      </button>
                      <button
                        class="flex w-full items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-red-600"
                        role="menuitem"
                        @click="handleDelete(it); close()"
                      >
                        <Trash2 class="w-4 h-4" />
                        <span>Delete</span>
                      </button>
                    </template>
                  </KebabMenu>
                </td>
              </tr>
            </tbody>
            <tbody v-else class="bg-white">
              <tr>
                <td
                  colspan="9"
                  class="px-6 py-12 text-center text-sm text-gray-500"
                >
                  No items found.
                  <button
                    @click="handleAdd"
                    class="ml-1 text-blue-600 underline"
                  >
                    Add Item
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Form View -->
    <ItemForm
      v-else-if="showForm"
      :edit-mode="!!editingItem"
      :initial-data="editingItem"
      @submit="handleFormSubmit"
      @cancel="handleFormCancel"
    />

    <!-- Delete Confirmation Modal -->
    <Teleport to="body">
      <div
        v-if="showDeleteConfirm"
        class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50"
      >
        <div class="bg-white rounded-lg p-6 max-w-md w-full">
          <div class="text-center">
            <X class="mx-auto h-12 w-12 text-red-500" />
            <h3 class="mt-4 text-lg font-medium text-gray-900">Delete Item</h3>
            <p class="mt-2 text-sm text-gray-500">
              Are you sure you want to delete {{ itemToDelete?._id }}? This action cannot
              be undone.
            </p>
          </div>
          <div class="mt-6 flex justify-end space-x-3">
            <button
              @click="showDeleteConfirm = false"
              class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              @click="confirmDelete"
              class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Add Event Modal -->
    <Teleport to="body">
      <div
        v-if="showEventForm && selectedItemForEvent"
        class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50"
      >
        <div class="max-w-md w-full">
          <AddItemEventModal
            :item-id="selectedItemForEvent.id"
            @success="handleEventSuccess"
            @cancel="handleEventCancel"
          />
        </div>
      </div>
    </Teleport>

    <!-- Event History Modal -->
    <Teleport to="body">
      <div
        v-if="showHistory && selectedItemForHistory"
        class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50"
      >
        <div class="max-w-2xl w-full">
          <ItemEventHistory
            :item-id="selectedItemForHistory.id"
            ref="historyRef"
            @close="handleHistoryClose"
          />
        </div>
      </div>
    </Teleport>

    <Teleport to="body">
      <div
        v-if="showCustomerToBillModal"
        class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50"
      >
        <div class="bg-white rounded-lg p-6 max-w-2xl w-full">
          <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium text-gray-900">Customer to bill</h3>
            <button
              @click="showCustomerToBillModal = false"
              class="text-gray-400 hover:text-gray-500"
            >
              <X class="h-6 w-6" />
            </button>
          </div>
          <div class="space-y-4">
            <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <input
                v-model="customerToBill"
                type="text"
                placeholder="Customer name"
                class="block w-full text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <button
              @click="billCustomer"
              class="px-3 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
            >
              Make invoice
            </button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>
