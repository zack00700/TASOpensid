<script setup lang="ts">
import { ref, onMounted, watch, inject } from 'vue';
import ContractRateManagement from './ContractRateManagement.vue';
import FilterBuilder from './FilterBuilder.vue';
import { X } from 'lucide-vue-next';
import type { EventConfig } from '../types/event-config';
import type { CalcFilter } from '../types/calc-filter';

interface Contract {
  id: string;
  name: string;
  description: string;
  calculationMode: {
    type: string;
    subType: string;
    eventConfig: EventConfig | null;
    parameters: Record<string, any>;
    filters: CalcFilter[];
  };
  status: 'Active' | 'Disable';
  startDate: string;
  endDate: string;
  rates: any[];
}

const props = defineProps<{
  editMode?: boolean;
  initialData?: Contract;
  loading?: boolean;
}>();

const emit = defineEmits<{
  (e: 'submit', data: any): void;
  (e: 'cancel'): void;
}>();

const $axios = inject<any>('$axios');

const formatDate = (value: string) =>
  value ? new Date(value).toISOString().slice(0, 10) : '';

// Initialize formData with default values including empty arrays
const formData = ref<Contract>({
  id: '',
  name: '',
  description: '',
  calculationMode: {
    type: 'Quantity',
    subType: 'quantity',
    eventConfig: null,
    parameters: {},
    filters: []
  },
  status: 'Active',
  startDate: '',
  endDate: '',
  rates: []
});

const errors = ref<Record<string, string>>({});
const eventSearch = ref('');
const eventSuggestions = ref<EventConfig[]>([]);
const showSuggestions = ref(false);
const highlightedIndex = ref(-1);
const noResults = ref(false);
let searchTimeout: any = null;

const calculationModes = {
  Quantity: [
    { value: 'quantity', label: 'Quantity' },
    { value: 'bl_volume', label: 'BL Volume' },
    { value: 'bl_weight', label: 'BL Weight' },
    { value: 'yard_item_teu', label: 'Yard Item TEU' }
  ],
  Date: [
    { value: 'call_date', label: 'Call Date' },
    { value: 'event_date', label: 'Event Date' },
    { value: 'in_date', label: 'In Date' },
    { value: 'last_sling_date', label: 'Last Sling Date' },
    { value: 'unloading_date', label: 'Unloading Date' },
    { value: 'vessel_arrival_date', label: 'Vessel Arrival Date' },
    { value: 'vessel_availability_date', label: 'Vessel Availability Date' }
  ],
  DateByTEU: [
    { value: 'call_date_teu', label: 'Call Date x TEU' },
    { value: 'event_date_teu', label: 'Event Date x TEU' },
    { value: 'in_date_teu', label: 'In Date x TEU' }
  ],
  Special: [
    { value: 'latest_in_date_bl', label: 'Latest In Date on BL' },
    { value: 'event_date_weight_volume', label: 'Event Date x Weight/Volume Recorded BL' }
  ]
};

onMounted(async () => {
  if (props.editMode && props.initialData) {
    formData.value = {
      ...props.initialData,
      startDate: formatDate(props.initialData.startDate),
      endDate: formatDate(props.initialData.endDate),
      calculationMode: {
        ...props.initialData.calculationMode,
        filters: props.initialData.calculationMode?.filters || []
      },
      rates: props.initialData.rates || []
    };
    if (props.initialData.calculationMode.eventConfig) {
      formData.value.calculationMode.eventConfig = props.initialData.calculationMode.eventConfig;
      if (props.initialData.calculationMode.eventConfig.eventName) {
        eventSearch.value = props.initialData.calculationMode.eventConfig.eventName;
      } else {
        try {
          const res = await $axios.get(`/event/${props.initialData.calculationMode.eventConfig.id}`);
          formData.value.calculationMode.eventConfig = res.data;
          eventSearch.value = res.data.eventName;
        } catch {
          // ignore fetch errors
        }
      }
    }
  }
});

const fetchEvents = async (query: string) => {
  try {
    const response = await $axios.get('/event', { params: { q: query } });
    eventSuggestions.value = response.data;
    noResults.value = response.data.length === 0;
  } catch {
    eventSuggestions.value = [];
    noResults.value = true;
  }
};

watch(eventSearch, (val) => {
  formData.value.calculationMode.eventConfig = null;
  errors.value.eventConfig = '';
  if (searchTimeout) clearTimeout(searchTimeout);
  if (!val) {
    eventSuggestions.value = [];
    noResults.value = false;
    return;
  }
  searchTimeout = setTimeout(() => fetchEvents(val), 300);
});

const selectEvent = (event: EventConfig) => {
  formData.value.calculationMode.eventConfig = event;
  eventSearch.value = event.eventName;
  showSuggestions.value = false;
  highlightedIndex.value = -1;
  noResults.value = false;
  errors.value.eventConfig = '';
};

const handleEventKeydown = (e: KeyboardEvent) => {
  if (!showSuggestions.value || eventSuggestions.value.length === 0) return;
  if (e.key === 'ArrowDown') {
    e.preventDefault();
    highlightedIndex.value = (highlightedIndex.value + 1) % eventSuggestions.value.length;
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    highlightedIndex.value = (highlightedIndex.value - 1 + eventSuggestions.value.length) % eventSuggestions.value.length;
  } else if (e.key === 'Enter') {
    e.preventDefault();
    if (highlightedIndex.value >= 0) {
      selectEvent(eventSuggestions.value[highlightedIndex.value]);
    }
  }
};

const hideSuggestions = () => {
  setTimeout(() => (showSuggestions.value = false), 100);
};

const validateForm = () => {
  errors.value = {};
  let isValid = true;

  if (!formData.value.name) {
    errors.value.name = 'Contract name is required';
    isValid = false;
  }

  if (!formData.value.calculationMode.eventConfig) {
    errors.value.eventConfig = 'Please select a valid event.';
    isValid = false;
  }

  if (!formData.value.startDate) {
    errors.value.startDate = 'Start date is required';
    isValid = false;
  }

  if (!formData.value.endDate) {
    errors.value.endDate = 'End date is required';
    isValid = false;
  }

  if (!formData.value.status || !['Active', 'Disable'].includes(formData.value.status)) {
    errors.value.status = 'Status is required';
    isValid = false;
  }

  if (formData.value.startDate && formData.value.endDate) {
    const start = new Date(formData.value.startDate);
    const end = new Date(formData.value.endDate);
    if (end <= start) {
      errors.value.endDate = 'End date must be after start date';
      isValid = false;
    }
  }

  return isValid;
};

const handleSubmit = () => {
  if (!validateForm()) {
    return;
  }
  const payload = {
    ...formData.value,
    startDate: formatDate(formData.value.startDate),
    endDate: formatDate(formData.value.endDate),
    calculationMode: {
      ...formData.value.calculationMode,
      eventConfig: { id: formData.value.calculationMode.eventConfig?.id }
    }
  };
  emit('submit', payload);
};

const handleRatesUpdate = (newRates: any[]) => {
  formData.value.rates = newRates;
};
const getInputClasses = (fieldName: string) => {
  return {
    'mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500': true,
    'border-red-300': errors.value[fieldName]
  };
};
</script>

<template>
  <div class="bg-white shadow rounded-lg">
    <div class="px-6 py-4 border-b border-gray-200">
      <div class="flex justify-between items-center">
        <h2 class="text-lg font-semibold text-gray-900">
          {{ props.editMode ? 'Edit Contract' : 'New Contract' }}
        </h2>
        <button
          @click="emit('cancel')"
          class="text-gray-400 hover:text-gray-500"
        >
          <X class="h-6 w-6" />
        </button>
      </div>
    </div>

    <form @submit.prevent="handleSubmit" class="p-6 space-y-6">
      <!-- Event Selection -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Event</h3>
        <div class="grid grid-cols-1 gap-4">
          <p class="text-sm text-gray-600">
            Select which event this contract should be applied to
          </p>
          <div class="relative">
            <input
              type="text"
              v-model="eventSearch"
              @focus="showSuggestions = true"
              @input="showSuggestions = true"
              @keydown="handleEventKeydown"
              @blur="hideSuggestions"
              :class="getInputClasses('eventConfig')"
              placeholder="Search events"
            />
            <ul
              v-if="showSuggestions"
              class="absolute z-10 mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-auto"
            >
              <li
                v-for="(event, index) in eventSuggestions"
                :key="event.id"
                @mousedown.prevent="selectEvent(event)"
                :class="['cursor-pointer px-3 py-2', { 'bg-blue-600 text-white': index === highlightedIndex, 'hover:bg-gray-100': index !== highlightedIndex }]"
              >
                {{ event.eventName }}
              </li>
              <li v-if="noResults" class="px-3 py-2 text-sm text-gray-500">
                No results found
              </li>
            </ul>
            <p v-if="errors.eventConfig" class="mt-1 text-sm text-red-600">
              {{ errors.eventConfig }}
            </p>
          </div>
        </div>
      </div>

      <!-- Basic Information -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Basic Information</h3>
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div class="sm:col-span-2">
            <label class="block text-sm font-medium text-gray-700">
              Contract Name <span class="text-red-500">*</span>
            </label>
            <input
              v-model="formData.name"
              type="text"
              :class="getInputClasses('name')"
            />
            <p v-if="errors.name" class="mt-1 text-sm text-red-600">
              {{ errors.name }}
            </p>
          </div>

          <div class="sm:col-span-2">
            <label class="block text-sm font-medium text-gray-700">
              Description
            </label>
            <textarea
              v-model="formData.description"
              rows="3"
              :class="getInputClasses('description')"
            ></textarea>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Start Date <span class="text-red-500">*</span>
            </label>
            <input
              v-model="formData.startDate"
              type="date"
              :class="getInputClasses('startDate')"
            />
            <p v-if="errors.startDate" class="mt-1 text-sm text-red-600">
              {{ errors.startDate }}
            </p>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              End Date <span class="text-red-500">*</span>
            </label>
            <input
              v-model="formData.endDate"
              type="date"
              :min="formData.startDate"
              :class="getInputClasses('endDate')"
            />
            <p v-if="errors.endDate" class="mt-1 text-sm text-red-600">
              {{ errors.endDate }}
            </p>
          </div>

          <div class="sm:col-span-2">
            <label
              class="block text-sm font-medium text-gray-700"
              title="Select contract status"
            >
              Status <span class="text-red-500">*</span>
            </label>
            <select
              v-model="formData.status"
              :class="getInputClasses('status')"
              title="Select contract status"
            >
              <option value="">Select contract status</option>
              <option value="Active">Active</option>
              <option value="Disable">Disable</option>
            </select>
            <p v-if="errors.status" class="mt-1 text-sm text-red-600">
              {{ errors.status }}
            </p>
          </div>
        </div>
      </div>

      <!-- Calculation Mode -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Calculation Mode</h3>
        <div class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700">
              Type
            </label>
            <select
              v-model="formData.calculationMode.type"
              :class="getInputClasses('calculationMode.type')"
            >
              <option v-for="type in Object.keys(calculationModes)" :key="type" :value="type">
                {{ type }}
              </option>
            </select>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">
              Sub Type
            </label>
            <select
              v-model="formData.calculationMode.subType"
              :class="getInputClasses('calculationMode.subType')"
            >
              <option
                v-for="mode in calculationModes[formData.calculationMode.type]"
                :key="mode.value"
                :value="mode.value"
              >
                {{ mode.label }}
              </option>
            </select>
          </div>
        </div>
      </div>

      <!-- Filters -->
      <div>
        <h3 class="text-lg font-medium text-gray-900 mb-4">Filters</h3>
        <FilterBuilder v-model="formData.calculationMode.filters" />
      </div>

      <!-- Rate Management -->
      <ContractRateManagement
        :contract-id="formData.id"
        :calculation-type="formData.calculationMode.type"
        :rates="formData.rates"
        @update:rates="handleRatesUpdate"
      />

      <!-- Form Actions -->
      <div class="flex justify-end space-x-3">
        <button
          type="button"
          @click="emit('cancel')"
          class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
        >
          Cancel
        </button>
        <button
          type="submit"
          :disabled="props.loading"
          :class="[
            'px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white',
            props.loading ? 'bg-blue-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
          ]"
        >
          {{ props.loading ? 'Saving...' : (props.editMode ? 'Save Changes' : 'Create Contract') }}
        </button>
      </div>
    </form>
  </div>
</template>
