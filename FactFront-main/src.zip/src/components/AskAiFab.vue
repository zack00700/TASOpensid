<template>
  <div>
    <button
      class="ask-ai-fab"
      aria-label="Ask AI"
      @click="openModal"
    >
      Ask AI!
    </button>

    <div v-if="isOpen" class="ask-ai-overlay" @click.self="closeModal">
      <div class="ask-ai-modal" role="dialog" aria-modal="true">
        <textarea
          v-model="question"
          class="ask-ai-textarea"
          placeholder="Ask a question..."
          @keydown.ctrl.enter.prevent="submit"
          @keydown.meta.enter.prevent="submit"
        ></textarea>
        <div class="ask-ai-actions">
          <button @click="closeModal" :disabled="loading">Cancel</button>
          <button @click="submit" :disabled="loading || !question.trim()">Send</button>
        </div>
        <p v-if="error" class="ask-ai-error">{{ error }}</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue';

interface AskAiSpec {
  title?: string;
  description?: string;
  answer?: string | null;
  chart?: {
    type?: 'kpi' | string;
    labels?: string[];
    datasets?: { name?: string; data?: number[] }[];
  } | null;
  table?: { columns?: string[]; rows?: (string | number)[][] } | null;
  aggregation?: unknown;
}

const props = withDefaults(defineProps<{
  apiUrl?: string;
  authToken?: string;
}>(), {
  apiUrl: '/api/ask-ai',
});

const isOpen = ref(false);
const question = ref('');
const loading = ref(false);
const error = ref('');

function openModal() {
  isOpen.value = true;
}

function closeModal() {
  isOpen.value = false;
  question.value = '';
  error.value = '';
}

function onEsc(e: KeyboardEvent) {
  if (e.key === 'Escape') closeModal();
}

watch(isOpen, (val) => {
  if (val) window.addEventListener('keydown', onEsc);
  else window.removeEventListener('keydown', onEsc);
});

async function submit() {
  if (loading.value || !question.value.trim()) return;
  loading.value = true;
  error.value = '';
  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (props.authToken) headers.Authorization = `Bearer ${props.authToken}`;
    const res = await fetch(props.apiUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify({ question: question.value }),
    });
    if (!res.ok) throw new Error(await res.text());
    const spec: AskAiSpec = await res.json();
    openResultWindow(spec);
    closeModal();
  } catch (err: any) {
    error.value = err.message || 'Request failed';
  } finally {
    loading.value = false;
  }
}

function openResultWindow(spec: AskAiSpec) {
  const win = window.open('', '_blank');
  if (!win) {
    alert('Please allow popups');
    return;
  }

  const specJson = JSON.stringify(spec).replace(/</g, '\\u003c');

  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>${escapeHtml(spec.title || 'Result')}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <style>
    :root{color-scheme:dark;}
    body{background:#121212;color:#f0f0f0;font-family:Arial,Helvetica,sans-serif;margin:0;padding:2rem;}
    h1{margin-top:0;font-size:1.5rem;}
    .grid{display:grid;grid-template-columns:1fr;gap:1.5rem;}
    @media(min-width:768px){.grid{grid-template-columns:1fr 1fr;}}
    .card{background:#1f1f1f;padding:1rem;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.4);}
    .kpi{display:none;font-size:3rem;font-weight:700;text-align:center;background:linear-gradient(45deg,#9f7aea,#63b3ed);-webkit-background-clip:text;color:transparent;margin-bottom:0.5rem;}
    .kpi-label{font-size:0.9rem;opacity:0.8;text-align:center;margin-top:0.25rem;}
    #chart{width:100%;height:320px;min-height:240px;}
    .table-wrap{overflow:auto; max-height:70vh;}
    table{width:100%;border-collapse:collapse; table-layout:auto; min-width:700px;}
    th,td{padding:0.5rem;border-bottom:1px solid #333;text-align:left;vertical-align:top;}
    th{color:#bbb;font-weight:500; white-space:nowrap;}
    td{word-break:break-word;}
    .mono{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;}
  </style>
</head>
<body>
  <h1 id="title"></h1>
  <p id="desc"></p>
  <p id="answer"></p>
  <div class="grid">
    <div class="card">
      <div id="kpi" class="kpi">
        <div id="kpiValue"></div>
        <div id="kpiLabel" class="kpi-label"></div>
      </div>
      <div id="chart"></div>
      <div id="chartFallback" style="display:none;opacity:0.8;font-size:0.9rem">Chart library failed to load.</div>
    </div>
    <div class="card table-wrap">
      <table id="table"></table>
    </div>
  </div>

  ${'<scr' + 'ipt>'}
  (function(){
    const spec = ${specJson};
    const nf = new Intl.NumberFormat();

    // ---------- Text ----------
    document.getElementById('title').textContent = spec.title || '';
    if (spec.description) document.getElementById('desc').textContent = spec.description;
    if (spec.answer) document.getElementById('answer').textContent = spec.answer;

    // ---------- Utils ----------
    const ci = (s) => (s ?? '').toString().toLowerCase();

    function resolveKey(obj, desired) {
      const want = ci(desired);
      let found = Object.keys(obj).find(k => ci(k) === want);
      if (found) return found;
      const aliases = {
        createddate: ['created_at','created','date','createddate'],
        customername: ['customer','client','customer_name','customername'],
        finalnumber: ['final_no','invoice','invoice_no','finalnumber'],
        amount: ['total','amount_total','sum','amount'],
        status: ['state','status']
      };
      for (const alt of (aliases[want]||[])) {
        found = Object.keys(obj).find(k => ci(k) === ci(alt));
        if (found) return found;
      }
      return desired;
    }

    // Robust date → YYYY-MM-DD
    function toLocalYMD(input) {
      if (input == null) return null;

      // Already Date?
      if (input instanceof Date && !isNaN(input)) {
        const y = input.getFullYear();
        const m = String(input.getMonth()+1).padStart(2,'0');
        const d = String(input.getDate()).padStart(2,'0');
        return \`\${y}-\${m}-\${d}\`;
      }

      const s = String(input);

      // ISO or yyyy-mm-dd prefix
      const iso = s.match(/^(\\d{4})-(\\d{2})-(\\d{2})/);
      if (iso) return \`\${iso[1]}-\${iso[2]}-\${iso[3]}\`;

      // RFC-ish like "Mon Aug 25 02:00:00 CEST 2025"
      const mmm = s.match(/^[A-Za-z]{3}\\s+([A-Za-z]{3})\\s+(\\d{1,2})\\s+\\d{2}:\\d{2}:\\d{2}\\s+[A-Za-z]{2,5}\\s+(\\d{4})/);
      if (mmm) {
        const monthMap = {Jan:'01',Feb:'02',Mar:'03',Apr:'04',May:'05',Jun:'06',Jul:'07',Aug:'08',Sep:'09',Oct:'10',Nov:'11',Dec:'12'};
        const mm = monthMap[mmm[1]] || '01';
        const dd = String(mmm[2]).padStart(2,'0');
        const yy = mmm[3];
        return \`\${yy}-\${mm}-\${dd}\`;
      }

      // Numeric epoch
      if (/^\\d{10,13}$/.test(s)) {
        const n = Number(s);
        const d = new Date(s.length === 13 ? n : n*1000);
        if (!isNaN(d)) {
          const y = d.getFullYear();
          const m = String(d.getMonth()+1).padStart(2,'0');
          const dd = String(d.getDate()).padStart(2,'0');
          return \`\${y}-\${m}-\${dd}\`;
        }
      }

      // Last resort: Date.parse (may fail on some locales)
      const d2 = new Date(s);
      if (!isNaN(d2)) {
        const y = d2.getFullYear();
        const m = String(d2.getMonth()+1).padStart(2,'0');
        const dd = String(d2.getDate()).padStart(2,'0');
        return \`\${y}-\${m}-\${dd}\`;
      }

      return null;
    }

    // ---------- Table (arrays OR objects) ----------
    (function renderTable(){
      if (!spec.table || !spec.table.columns || !spec.table.columns.length) {
        const tbl = document.getElementById('table');
        if (tbl) tbl.style.display = 'none';
        return;
      }
      const columns = spec.table.columns.map(String);
      const rows = spec.table.rows || [];
      const table = document.getElementById('table');

      const thead = table.createTHead();
      const trh = thead.insertRow();
      columns.forEach(col => {
        const th = document.createElement('th');
        th.textContent = col;
        trh.appendChild(th);
      });

      const tbody = table.createTBody();
      rows.forEach(row => {
        const tr = tbody.insertRow();

        if (Array.isArray(row)) {
          columns.forEach((_, idx) => {
            const td = tr.insertCell();
            const val = row[idx];
            td.className = (columns[idx].toLowerCase().includes('number')) ? 'mono' : '';
            td.textContent = typeof val === 'number' ? nf.format(val) : String(val ?? '');
          });
        } else if (row && typeof row === 'object') {
          columns.forEach(col => {
            const td = tr.insertCell();
            const key = resolveKey(row, col);
            const val = row[key];
            td.className = col.toLowerCase().includes('number') ? 'mono' : '';
            td.textContent = (typeof val === 'number') ? nf.format(val) : String(val ?? '');
          });
        } else {
          const td = tr.insertCell();
          td.colSpan = columns.length;
          td.textContent = String(row ?? '');
        }
      });
    })();

    // ---------- KPI + Chart ----------
    function showKPI(val, label, { hideChart = false } = {}) {
      document.getElementById('kpi').style.display = 'block';
      document.getElementById('kpiValue').textContent = nf.format(val ?? 0);
      document.getElementById('kpiLabel').textContent = label || 'Total';
      if (hideChart) document.getElementById('chart').style.display = 'none';
    }

    // Build daily bars from table when needed
    function deriveDailyFromTable() {
      if (!spec.table || !spec.table.columns?.length || !spec.table.rows?.length) return null;

      const cols = spec.table.columns.map(c => c.toString());
      const createdIdx = cols.findIndex(c => ci(c) === 'createddate');
      const amountIdx  = cols.findIndex(c => ci(c) === 'amount');
      if (createdIdx === -1 || amountIdx === -1) return null;

      const totals = new Map(); // yyyy-mm-dd -> sum
      for (const r of spec.table.rows) {
        let createdVal, amountVal;

        if (Array.isArray(r)) {
          createdVal = r[createdIdx];
          amountVal  = r[amountIdx];
        } else if (r && typeof r === 'object') {
          const createdKey = resolveKey(r, cols[createdIdx]);
          const amountKey  = resolveKey(r, cols[amountIdx]);
          createdVal = r[createdKey];
          amountVal  = r[amountKey];
        }

        const day = toLocalYMD(createdVal);
        const amt = Number.parseFloat(String(amountVal ?? '0'));
        if (!day || !Number.isFinite(amt)) continue;
        totals.set(day, (totals.get(day) || 0) + amt);
      }

      const labels = Array.from(totals.keys()).sort();
      const data = labels.map(d => totals.get(d) || 0);
      if (!labels.length) return null;

      return { type: 'bar', labels, datasets: [{ name: 'amount', data }] };
    }

    function renderECharts(echarts){
      const c = document.getElementById('chart');
      if (!c) return;
      c.style.display = 'block';

      const ensureSize = () => {
        if (c.clientWidth === 0 || c.clientHeight === 0) {
          requestAnimationFrame(ensureSize);
          return;
        }
        const ch = spec.chart || {};
        const labels = ch.labels || [];
        const firstSeries = ch.datasets?.[0]?.data || [];
        if (!labels.length || !firstSeries.length) { c.style.display = 'none'; return; }

        const seriesType = (ch.type && ch.type !== 'kpi') ? ch.type : 'bar';
        const chart = echarts.init(c, null, { renderer: 'canvas' });
        chart.setOption({
          tooltip: { trigger: 'axis' },
          xAxis: { type: 'category', data: labels },
          yAxis: { type: 'value' },
          series: [{ type: seriesType, name: ch.datasets?.[0]?.name || 'Series', data: firstSeries }]
        });
        window.addEventListener('resize', () => chart.resize());
      };
      ensureSize();
    }

    function startCharting(){
      let ch = spec.chart || null;

      // Show KPI (do not hide chart yet)
      if (ch && ch.type === 'kpi') {
        const val = ch?.datasets?.[0]?.data?.[0] ?? 0;
        const label = ch?.labels?.[0] || 'Total';
        showKPI(val, label, { hideChart: false });
      }

      // If no multi-point series, derive daily bars from table
      const hasMulti = ch && Array.isArray(ch.labels) && ch.labels.length > 1 &&
                       Array.isArray(ch.datasets?.[0]?.data) && ch.datasets[0].data.length > 1;

      if (!hasMulti) {
        const derived = deriveDailyFromTable();
        if (derived) {
          ch = derived;
          spec.chart = ch;
        }
      }

      if (!ch || !Array.isArray(ch.labels) || !Array.isArray(ch.datasets?.[0]?.data) || !ch.labels.length) {
        document.getElementById('chart').style.display = 'none';
        return;
      }

      if (window.echarts) {
        if (document.readyState === 'complete') {
          requestAnimationFrame(() => renderECharts(window.echarts));
        } else {
          window.addEventListener('load', () => requestAnimationFrame(() => renderECharts(window.echarts)), { once: true });
        }
        return;
      }

      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/echarts@5.5.0/dist/echarts.min.js';
      s.async = true;
      s.onload = () => {
        if (document.readyState === 'complete') {
          requestAnimationFrame(() => renderECharts(window.echarts));
        } else {
          window.addEventListener('load', () => requestAnimationFrame(() => renderECharts(window.echarts)), { once: true });
        }
      };
      s.onerror = () => {
        document.getElementById('chartFallback').style.display = 'block';
        document.getElementById('chart').style.display = 'none';
      };
      document.head.appendChild(s);
    }

    if (document.readyState === 'complete') {
      requestAnimationFrame(startCharting);
    } else {
      window.addEventListener('load', () => requestAnimationFrame(startCharting), { once: true });
    }
  })();
  ${'</scr' + 'ipt>'}
</body>
</html>`;

  win.document.write(html);
  win.document.close();
}




function escapeHtml(str: string) {
  return str.replace(/[&<>"']/g, (c) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[c]!));
}

</script>

<style scoped>
.ask-ai-fab{
  position:fixed;
  bottom:1.5rem;
  right:1.5rem;
  background:linear-gradient(45deg,#9f7aea,#63b3ed);
  color:#fff;
  padding:0.75rem 1.25rem;
  border:none;
  border-radius:9999px;
  box-shadow:0 4px 12px rgba(0,0,0,0.3);
  cursor:pointer;
  transition:transform 0.2s;
}
.ask-ai-fab:hover{transform:translateY(-2px);}
.ask-ai-fab:focus-visible{outline:2px solid #fff;outline-offset:2px;}

.ask-ai-overlay{
  position:fixed;
  inset:0;
  background:rgba(0,0,0,0.6);
  backdrop-filter:blur(4px);
  display:flex;
  align-items:center;
  justify-content:center;
  z-index:1000;
}

.ask-ai-modal{
  background:#1f1f1f;
  color:#f0f0f0;
  padding:1rem;
  border-radius:8px;
  border:1px solid rgba(255,255,255,0.1);
  width:100%;
  max-width:480px;
  display:flex;
  flex-direction:column;
  gap:1rem;
}

.ask-ai-textarea{
  width:100%;
  min-height:120px;
  background:#2a2a2a;
  color:#f0f0f0;
  border:1px solid #444;
  border-radius:4px;
  padding:0.5rem;
  resize:vertical;
}

.ask-ai-actions{
  display:flex;
  justify-content:flex-end;
  gap:0.5rem;
}

.ask-ai-actions button{
  padding:0.5rem 1rem;
  background:#333;
  color:#f0f0f0;
  border:none;
  border-radius:4px;
  cursor:pointer;
}

.ask-ai-actions button:disabled{opacity:0.6;cursor:not-allowed;}

.ask-ai-actions button:focus-visible{outline:2px solid #fff;outline-offset:2px;}

.ask-ai-error{color:#f87171;font-size:0.875rem;}
</style>

