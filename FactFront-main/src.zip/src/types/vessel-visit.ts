export interface VesselVisit {
  vesselName: string;
  vesselId: string;
  visitReference: string;
  phase: 'Created' | 'Active' | 'Completed' | 'Canceled';
  service: string;
  serviceName: string;
  facility: string;
  eta: string;
  etd: string;
  ata: string;
  atd: string;
  pod: string;
  pol: string;
  finalDestination: string;
  beginReceive: string;
  dryCutoff: string;
  reeferCutoff: string;
  hazCutoff: string;
  emptyPickup: string;
  inboundVoyage: string;
  outboundVoyage: string;
  inboundCaptain: string;
  outboundCaptain: string;
  lineOperator: string;
  notes: string;
}
