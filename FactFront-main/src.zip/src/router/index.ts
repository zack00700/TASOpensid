import { ref, computed, h, App } from 'vue';
import Invoices from '../components/Invoices.vue';
import Items from '../components/Items.vue';
import EventsConfiguration from '../components/EventsConfiguration.vue';
import VesselVisits from '../components/VesselVisits.vue';
import BillOfLading from '../components/BillOfLading.vue';
import Events from '../components/Events.vue';
import Vessels from '../components/Vessels.vue';
import ThirdPartyUsers from '../components/ThirdPartyUsers.vue';
import Contracts from '../components/Contracts.vue';
import LanguagesPage from '../components/LanguagesPage.vue';
import LanguageDetailPage from '../components/LanguageDetailPage.vue';
import AuthGuard from '../components/AuthGuard.vue';
import InvoiceTemplateDesigner from '../components/InvoiceTemplateDesigner.vue';

export interface Route {
  path: string;
  component: any;
  props?: boolean;
}

function admin(component: any, message: string) {
  return {
    render() {
      return h(
        AuthGuard,
        { requireRole: 'admin', fallbackMessage: message },
        { default: () => h(component) }
      );
    },
  };
}

export const routes: Route[] = [
  { path: '/invoices', component: Invoices },
  { path: '/items', component: Items },
  {
    path: '/events-config',
    component: admin(
      EventsConfiguration,
      'Seuls les administrateurs peuvent configurer les événements.'
    ),
  },
  { path: '/vessels', component: VesselVisits },
  { path: '/bills', component: BillOfLading },
  { path: '/events', component: Events },
  { path: '/vessel-registry', component: Vessels },
  {
    path: '/users',
    component: admin(
      ThirdPartyUsers,
      'Seuls les administrateurs peuvent gérer les utilisateurs.'
    ),
  },
  { path: '/contracts', component: Contracts },
  {
    path: '/template-designer',
    component: admin(
      InvoiceTemplateDesigner,
      'Seuls les administrateurs peuvent utiliser le designer de templates.'
    ),
  },
  {
    path: '/i18n/fields',
    component: admin(
      LanguagesPage,
      'Seuls les administrateurs peuvent gérer les champs.'
    ),
  },
  { path: '/i18n/fields/:code', component: LanguageDetailPage, props: true },
];

const currentPath = ref('/invoices');
const currentParams = ref<Record<string, string>>({});

function resolve(path: string) {
  for (const r of routes) {
    if (r.path === path) return { route: r, params: {} };
    const match = r.path.match(/^(.*):([^/]+)$/);
    if (match && path.startsWith(match[1])) {
      const value = path.slice(match[1].length);
      return { route: r, params: { [match[2]]: value } };
    }
  }
  return { route: routes[0], params: {} };
}

export function useRouter() {
  return {
    push(path: string) {
      const { params } = resolve(path);
      currentPath.value = path;
      currentParams.value = params;
    },
    currentRoute: computed(() => ({
      path: currentPath.value,
      params: currentParams.value,
    })),
  };
}

export function useRoute() {
  return { path: currentPath.value, params: currentParams.value };
}

export function onBeforeRouteLeave(_fn: Function) {
  // no-op
}

export const RouterView = {
  name: 'RouterView',
  setup() {
    return () => {
      const { route } = resolve(currentPath.value);
      return h(route.component, route.props ? { ...currentParams.value } : {});
    };
  },
};

export default {
  install(app: App) {
    app.component('RouterView', RouterView);
  },
  routes,
};
