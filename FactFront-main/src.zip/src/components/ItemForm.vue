<script setup lang="ts">
import { ref, computed, watch } from "vue";
import { X } from "lucide-vue-next";
import ItemLifecycleView from "./ItemLifecycleView.vue";
import { ItemFormData } from "../types/item";

import { useItem } from "../composables/use.item";
const { formData, errors, validateForm, addItem, updateItem } = useItem();

const props = defineProps<{
  editMode?: boolean;
  initialData?: ItemFormData;
}>();

const emit = defineEmits<{
  (e: "submit", data: ItemFormData): void;
  (e: "cancel"): void;
}>();

const activeTab = ref<"details" | "lifeCycles">("details");

const itemTypes = [
  { value: "container", label: "Container" },
  { value: "breakbulk", label: "Break Bulk" },
  { value: "vehicle", label: "Vehicle" },
];

const containerTypes = ["20DC", "40DC", "40HC", "45HC", "20RF", "40RF", "TANK", "FLAT"];

watch(
  () => props.initialData,
  (newData) => {
    if (props.editMode && newData) {
      // Map backend field names to frontend form field names
      formData.value = { 
        ...formData.value, 
        ...newData,
        // Map date fields from backend to frontend format
        lastInspection: newData.lastInspectionDate ? new Date(newData.lastInspectionDate).toISOString().split('T')[0] : '',
        nextInspection: newData.nextInspectionDate ? new Date(newData.nextInspectionDate).toISOString().split('T')[0] : '',
      };
      console.log("🔄 Mapped data for editing:", formData.value);
    }
  },
  { immediate: true }
);

const handleSubmit = async () => {
  if (!validateForm()) {
    return;
  }

  try {
    if (props.editMode) {
      await updateItem();
    } else {
      await addItem();
    }
    
    emit("submit", formData.value);
  } catch (error) {
    console.error("Failed to save item:", error);
  }
};

const getInputClasses = (fieldName: keyof ItemFormData) => {
  return {
    "w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 bg-white text-gray-900 placeholder-gray-500": true,
    "border-red-300 focus:border-red-500 focus:ring-red-500/20": errors.value[fieldName],
  };
};

const getTabClasses = (tab: string) => {
  const isActive = activeTab.value === tab;
  return {
    "px-6 py-3 text-sm font-medium rounded-xl transition-all duration-200": true,
    "bg-blue-50 text-blue-700 border border-blue-200": isActive,
    "text-gray-600 hover:text-gray-900 hover:bg-gray-50": !isActive,
  };
};

// Convert form data to Item type for lifecycle view
const itemData = computed(() => ({
  id: formData.value.itemNumber,
  type: formData.value.itemType,
  status: formData.value.status,
  ownerCode: formData.value.ownerId,
  currentLifecycleId: formData.value.lifeCycles.find((l) => l.status === "In Progress")
    ?.id,
  lifeCycles: formData.value.lifeCycles,
}));
</script>

<template>
  <div class="bg-white rounded-2xl shadow-sm border border-gray-100">
    <!-- Header -->
    <div class="px-8 py-6 border-b border-gray-100">
      <div class="flex justify-between items-center">
        <div>
          <h2 class="text-2xl font-semibold text-gray-900 mb-1">
            {{ editMode ? "Edit Item" : "New Item" }}
          </h2>
          <p class="text-gray-500 text-sm">
            {{ editMode ? "Update item information and settings" : "Create a new item in the system" }}
          </p>
        </div>
        <button 
          @click="emit('cancel')" 
          class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-all duration-200"
        >
          <X class="h-5 w-5" />
        </button>
      </div>
    </div>

    <!-- Tabs -->
    <div v-if="editMode" class="px-8 pt-6">
      <nav class="flex space-x-3">
        <button @click="activeTab = 'details'" :class="getTabClasses('details')">
          Item Details
        </button>
        <button @click="activeTab = 'lifeCycles'" :class="getTabClasses('lifeCycles')">
          Lifecycles
        </button>
      </nav>
    </div>

    <!-- Item Details Form -->
    <form
      v-if="activeTab === 'details'"
      @submit.prevent="handleSubmit"
      class="p-8 space-y-8"
    >
      <!-- Basic Information -->
      <div class="space-y-6">
        <div class="border-l-4 border-blue-500 pl-4">
          <h3 class="text-lg font-semibold text-gray-900">Basic Information</h3>
          <p class="text-sm text-gray-500 mt-1">Core details about the item</p>
        </div>
        
        <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div class="space-y-2">
            <label class="block text-sm font-medium text-gray-700">
              Item Number
              <span class="text-red-500 ml-1">*</span>
            </label>
            <input
              v-model="formData.itemNumber"
              type="text"
              :class="getInputClasses('itemNumber')"
              :disabled="editMode"
              placeholder="Enter item number"
            />
            <p v-if="errors.itemNumber" class="text-sm text-red-600 mt-1">
              {{ errors.itemNumber }}
            </p>
          </div>

          <div class="space-y-2">
            <label class="block text-sm font-medium text-gray-700">
              Item Type
              <span class="text-red-500 ml-1">*</span>
            </label>
            <select v-model="formData.itemType" :class="getInputClasses('itemType')">
              <option value="">Select item type</option>
              <option v-for="type in itemTypes" :key="type.value" :value="type.value">
                {{ type.label }}
              </option>
            </select>
          </div>

          <div class="space-y-2">
            <label class="block text-sm font-medium text-gray-700">
              Type
              <span class="text-red-500 ml-1">*</span>
            </label>
            <select
              v-if="formData.itemType === 'container'"
              v-model="formData.type"
              :class="getInputClasses('type')"
            >
              <option value="">Select container type</option>
              <option v-for="type in containerTypes" :key="type" :value="type">
                {{ type }}
              </option>
            </select>
            <input
              v-else
              v-model="formData.type"
              type="text"
              :class="getInputClasses('type')"
              :placeholder="
                formData.itemType === 'vehicle' ? 'e.g., Truck, Forklift' : 'Enter type'
              "
            />
            <p v-if="errors.type" class="text-sm text-red-600 mt-1">
              {{ errors.type }}
            </p>
          </div>

          <div class="space-y-2">
            <label class="block text-sm font-medium text-gray-700">
              Owner ID
              <span class="text-red-500 ml-1">*</span>
            </label>
            <input
              v-model="formData.ownerId"
              type="text"
              :class="getInputClasses('ownerId')"
              placeholder="Enter owner ID"
            />
            <p v-if="errors.ownerId" class="text-sm text-red-600 mt-1">
              {{ errors.ownerId }}
            </p>
          </div>

          <div class="space-y-2">
            <label class="block text-sm font-medium text-gray-700">Position</label>
            <input
              v-model="formData.position"
              type="text"
              :class="getInputClasses('position')"
              placeholder="Enter position"
            />
          </div>

          <div class="space-y-2">
            <label class="block text-sm font-medium text-gray-700">Status</label>
            <select v-model="formData.status" :class="getInputClasses('status')">
              <option value="Available">Available</option>
              <option value="In Use">In Use</option>
              <option value="Maintenance">Maintenance</option>
              <option value="Out of Service">Out of Service</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Inspection Information -->
      <div class="space-y-6">
        <div class="border-l-4 border-green-500 pl-4">
          <h3 class="text-lg font-semibold text-gray-900">Inspection Information</h3>
          <p class="text-sm text-gray-500 mt-1">Inspection dates and schedules</p>
        </div>
        
        <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div class="space-y-2">
            <label class="block text-sm font-medium text-gray-700">
              Last Inspection Date
            </label>
            <input
              v-model="formData.lastInspection"
              type="date"
              :class="getInputClasses('lastInspection')"
            />
          </div>

          <div class="space-y-2">
            <label class="block text-sm font-medium text-gray-700">
              Next Inspection Date
            </label>
            <input
              v-model="formData.nextInspection"
              type="date"
              :min="formData.lastInspection"
              :class="getInputClasses('nextInspection')"
            />
            <p v-if="errors.nextInspection" class="text-sm text-red-600 mt-1">
              {{ errors.nextInspection }}
            </p>
          </div>
        </div>
      </div>

      <!-- Additional Information -->
      <div class="space-y-6">
        <div class="border-l-4 border-purple-500 pl-4">
          <h3 class="text-lg font-semibold text-gray-900">Additional Information</h3>
          <p class="text-sm text-gray-500 mt-1">Notes and additional details</p>
        </div>
        
        <div class="space-y-2">
          <label class="block text-sm font-medium text-gray-700">Notes</label>
          <textarea
            v-model="formData.notes"
            rows="4"
            :class="getInputClasses('notes')"
            placeholder="Add any additional notes or comments..."
          ></textarea>
        </div>
      </div>

      <!-- Form Actions -->
      <div class="flex justify-end space-x-4 pt-6 border-t border-gray-100">
        <button
          type="button"
          @click="emit('cancel')"
          class="px-6 py-3 border border-gray-200 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 hover:border-gray-300 transition-all duration-200"
        >
          Cancel
        </button>
        <button
          type="submit"
          class="px-6 py-3 bg-blue-600 border border-blue-600 rounded-xl text-sm font-medium text-white hover:bg-blue-700 hover:border-blue-700 focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 shadow-sm"
        >
          {{ editMode ? "Save Changes" : "Create Item" }}
        </button>
      </div>
    </form>

    <!-- Lifecycles View -->
    <div v-else-if="activeTab === 'lifeCycles'" class="p-8">
      <div class="border-l-4 border-indigo-500 pl-4 mb-6">
        <h3 class="text-lg font-semibold text-gray-900">Item Lifecycles</h3>
        <p class="text-sm text-gray-500 mt-1">Track and manage item lifecycle stages</p>
      </div>
      
      <ItemLifecycleView :item="itemData" />

      <!-- Form Actions -->
      <div class="flex justify-end space-x-4 pt-6 border-t border-gray-100 mt-8">
        <button
          type="button"
          @click="emit('cancel')"
          class="px-6 py-3 border border-gray-200 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 hover:border-gray-300 transition-all duration-200"
        >
          Cancel
        </button>
        <button
          type="button"
          @click="activeTab = 'details'"
          class="px-6 py-3 bg-blue-600 border border-blue-600 rounded-xl text-sm font-medium text-white hover:bg-blue-700 hover:border-blue-700 focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 shadow-sm"
        >
          Back to Details
        </button>
      </div>
    </div>
  </div>
</template>