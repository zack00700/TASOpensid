import { Item, Lifecycle, Event } from '../types/item';
import { EventHandler } from './eventHandler';
import api from '../plugin/axios';
export class ItemService {
  private static instance: ItemService;
  private eventHandler: EventHandler;

  private constructor() {
    this.eventHandler = EventHandler.getInstance();
  }

  public static getInstance(): ItemService {
    if (!ItemService.instance) {
      ItemService.instance = new ItemService();
    }
    return ItemService.instance;
  }

  public getActiveLifecycle(item: Item): Lifecycle | undefined {
    return item.lifeCycles.find(lifecycle => lifecycle.status === 'In Progress');
  }

  public getCompletedLifecycles(item: Item): Lifecycle[] {
    return item.lifeCycles.filter(lifecycle => lifecycle.status === 'Completed');
  }

  public getLifecyclesInDateRange(
    item: Item,
    startDate: Date,
    endDate: Date
  ): Lifecycle[] {
    return item.lifeCycles.filter(lifecycle => {
      const lifecycleStart = new Date(lifecycle.startTime);
      const lifecycleEnd = lifecycle.endTime ? new Date(lifecycle.endTime) : new Date();
      return lifecycleStart >= startDate && lifecycleEnd <= endDate;
    });
  }

  public async addEvent(item: Item, event: Event): Promise<string> {
    try {
      console.debug('addEvent called', { event, item });
      return await this.eventHandler.processEvent(event, item);
    } catch (error) {
      console.error('Error processing event:', error);
      throw error;
    }
  }

  public cancelCurrentLifecycle(item: Item, reason: string): Item {
    if (!item.currentLifecycleId) {
      throw new Error('No active lifecycle to cancel');
    }

    const cancelEvent: Event = {
      id: "1",
      timestamp: new Date().toISOString(),
      eventType: 'OUT',
      itemId: item.id,
      lifecycleId: item.currentLifecycleId,
      notes: reason
    };

    const updatedLifecycles = item.lifeCycles.map(lifecycle => {
      if (lifecycle.id === item.currentLifecycleId) {
        return {
          ...lifecycle,
          endTime: cancelEvent.timestamp,
          status: 'Cancelled',
          events: [...lifecycle.events, cancelEvent]
        };
      }
      return lifecycle;
    });

    return {
      ...item,
      currentLifecycleId: undefined,
      lifeCycles: updatedLifecycles
    };
  }

  public getLifecycleDuration(lifecycle: Lifecycle): number {
    const start = new Date(lifecycle.startTime);
    const end = lifecycle.endTime ? new Date(lifecycle.endTime) : new Date();
    return end.getTime() - start.getTime();
  }

  public getAverageLifecycleDuration(item: Item): number {
    const completedLifecycles = this.getCompletedLifecycles(item);
    if (completedLifecycles.length === 0) return 0;

    const totalDuration = completedLifecycles.reduce(
      (sum, lifecycle) => sum + this.getLifecycleDuration(lifecycle),
      0
    );

    return totalDuration / completedLifecycles.length;
  }
}

interface ItemCreatePayload {
  type: string;
  itemNumber: string;
  status: string;
  billOfLadingId: string;
}

export const create = async (data: ItemCreatePayload): Promise<any> => {
  const response = await api.post('/item', data);
  return response.data;
};

export const get = async (id: string): Promise<Item> => {
  const response = await api.get(`/item/${id}`);
  return response.data;
};

export interface AddEventPayload {
  eventId: string;
  eventDate: string;
}

export const addEventToItem = async (
  itemId: string,
  payload: AddEventPayload,
): Promise<any> => {
  const response = await api.post(`/item/${itemId}/event`, payload);
  return response.data;
};

export const getLifecycles = async (
  itemId: string,
  expandEvents = true,
): Promise<any> => {
  const response = await api.get(`/item/${itemId}/lifecycles`, {
    params: expandEvents ? { expandEvents: true } : {},
  });
  return response.data;
};

export default {
  create,
  get,
  addEventToItem,
  getLifecycles,
};
