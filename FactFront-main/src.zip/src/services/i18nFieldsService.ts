import api from '../plugin/axios';
import type { Language, EntityDef, FieldDef } from '../types/i18nFields';

// Fixed: add /api prefix to match your backend
const base = '/fields-i18n/languages'; // <-- added /api

function normalizeListPayload(data: any, params: { limit?: number; offset?: number } = {}) {
  const items = Array.isArray(data) ? data : (Array.isArray(data?.items) ? data.items : []);
  const total = typeof data?.total === 'number' ? data.total : items.length;
  const limit = params.limit ?? (typeof data?.limit === 'number' ? data.limit : items.length);
  const offset = params.offset ?? (typeof data?.offset === 'number' ? data.offset : 0);
  return { items, total, limit, offset };
}

export async function fetchLanguages(params: { q?: string; enabled?: boolean; limit?: number; offset?: number } = {}) {
  console.log('🔵 Service: fetchLanguages called with URL:', base, 'params:', params);
  console.log('🔵 Service: Full URL will be:', api.defaults.baseURL + base);
  
  try {
    // let 4xx throw (don't hide errors)
    const res = await api.get(base, { params });
    console.log('🔵 Service: API response:', res.data);
    
    const normalized = normalizeListPayload(res.data, params);
    console.log('🔵 Service: Normalized response:', normalized);
    
    return normalized;
  } catch (err) {
    console.error('🔵 Service: API error:', err);
    console.error('🔵 Service: Error response:', err.response?.data);
    console.error('🔵 Service: Error status:', err.response?.status);
    throw err;
  }
}

export async function getLanguage(code: string) {
  const res = await api.get(`${base}/${encodeURIComponent(code)}`);
  return res.data;
}

export async function createOrUpsertLanguage(payload: Partial<Language>, upsert = true) {
  const body = { ...payload, entities: Array.isArray(payload.entities) ? payload.entities : [] };
  const res = await api.post(`${base}?upsert=${upsert}`, body);
  return res.data;
}

export async function updateLanguage(code: string, payload: Partial<Language>) {
  const res = await api.put(`${base}/${encodeURIComponent(code)}`, payload);
  return res.data;
}

export async function patchLanguage(code: string, patch: Partial<Language>, upsert = false) {
  const res = await api.patch(`${base}/${encodeURIComponent(code)}?upsert=${upsert}`, patch);
  return res.data;
}

export async function deleteLanguage(code: string) {
  await api.delete(`${base}/${encodeURIComponent(code)}`);
}

export async function upsertEntity(code: string, entityDef: EntityDef) {
  const res = await api.put(`${base}/${encodeURIComponent(code)}/entities/${encodeURIComponent(entityDef.entity)}`, entityDef);
  return res.data;
}

export async function patchEntity(code: string, entity: string, patch: Partial<EntityDef>) {
  const res = await api.patch(`${base}/${encodeURIComponent(code)}/entities/${encodeURIComponent(entity)}`, patch);
  return res.data;
}

export async function deleteEntity(code: string, entity: string, opts: { hard?: boolean } = {}) {
  const q = opts.hard ? '?hard=true' : '';
  await api.delete(`${base}/${encodeURIComponent(code)}/entities/${encodeURIComponent(entity)}${q}`);
}

export async function bulkUpsertFields(code: string, entity: string, fields: FieldDef[], method: 'PUT'|'PATCH' = 'PATCH') {
  const url = `${base}/${encodeURIComponent(code)}/entities/${encodeURIComponent(entity)}/fields`;
  const res = method === 'PUT' ? await api.put(url, fields) : await api.patch(url, fields);
  return res.data;
}

export async function deleteField(code: string, entity: string, field: string, opts: { hard?: boolean } = {}) {
  const q = opts.hard ? '?hard=true' : '';
  await api.delete(`${base}/${encodeURIComponent(code)}/entities/${encodeURIComponent(entity)}/fields/${encodeURIComponent(field)}${q}`);
}

export default {
  fetchLanguages,
  getLanguage,
  createOrUpsertLanguage,
  updateLanguage,
  patchLanguage,
  deleteLanguage,
  upsertEntity,
  patchEntity,
  deleteEntity,
  bulkUpsertFields,
  deleteField,
};