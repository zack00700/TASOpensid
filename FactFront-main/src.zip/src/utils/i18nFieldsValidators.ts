import type { FieldType } from '../types/i18nFields';

export const codeRegex = /^[a-z]{2,}$/;
export const nameRegex = /^.{1,100}$/;
export const idRegex = /^[A-Za-z][A-Za-z0-9_]*$/;

export function validateCode(code: string): boolean {
  return codeRegex.test(code);
}

export function validateName(name: string): boolean {
  return nameRegex.test(name);
}

export function validateEntityId(id: string): boolean {
  return idRegex.test(id);
}

export const validateFieldKey = validateEntityId;

export function validateDefaultValue(type: FieldType, value: unknown): boolean {
  if (value === undefined) return true;
  switch (type) {
    case 'text':
    case 'textarea':
    case 'select':
      return typeof value === 'string';
    case 'number':
    case 'currency':
      return typeof value === 'number';
    case 'boolean':
      return typeof value === 'boolean';
    case 'date':
    case 'datetime':
      return typeof value === 'string';
    case 'multiselect':
      return Array.isArray(value) && value.every((v) => typeof v === 'string');
    default:
      return false;
  }
}
