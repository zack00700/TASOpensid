// src/utils/i18nFieldsNormalizer.ts
import type { Language, EntityDef, FieldDef } from '../types/i18nFields';

export function normalizeLanguage(input: any): Language {
  const raw = input ?? {};
  const code = String(raw.code ?? raw.id ?? raw._id ?? '').trim();
  const name = String(raw.name ?? code).trim();
  const enabled = Boolean(raw.enabled ?? false);

  const rawEntities = Array.isArray(raw.entities)
    ? raw.entities
    : Array.isArray(raw.entitys)
      ? raw.entitys
      : [];

  const entities: EntityDef[] = rawEntities
    .filter((e: any) => e && typeof e === 'object')
    .map((e: any) => ({
      entity: String(e.entity ?? '').trim(),
      name: String(e.name ?? e.entity ?? '').trim(),
      fields: Array.isArray(e.fields)
        ? e.fields
            .filter((f: any) => f && typeof f === 'object')
            .map((f: any): FieldDef => ({
              field: String(f.field ?? '').trim(),
              name: String(f.name ?? f.field ?? '').trim(),
              type: typeof f.type === 'string' ? f.type : 'text',
              required: Boolean(f.required ?? false),
              default: f.default,
              deprecated: f.deprecated === true ? true : undefined,
            }))
        : [],
    }));

  return {
    code,
    name,
    enabled,
    entities,
    createdAt: typeof raw.createdAt === 'string' ? raw.createdAt : undefined,
    updatedAt: typeof raw.updatedAt === 'string' ? raw.updatedAt : undefined,
  };
}
