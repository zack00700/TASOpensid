<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useRoute, useRouter, onBeforeRouteLeave } from '../router';
import { useI18nFieldsStore } from '../stores/i18nFieldsStore';
import EntityList from './EntityList.vue';

const store = useI18nFieldsStore();
const route = useRoute();
const router = useRouter();
const code = route.params.code as string;
const unsaved = ref(false);

async function load() {
  await store.getLanguage(code);
}

onMounted(load);

onBeforeRouteLeave((to: any, from: any, next: (ok?: boolean) => void) => {
  if (unsaved.value && !confirm('You have unsaved changes. Leave anyway?')) next(false);
  else next();
});

window.addEventListener('beforeunload', (e) => {
  if (unsaved.value) {
    e.preventDefault();
    e.returnValue = '';
  }
});

function markChanged() {
  unsaved.value = true;
}

function exportJson() {
  const data = JSON.stringify(store.current, null, 2);
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${code}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

async function importJson(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0];
  if (!file) return;
  const text = await file.text();
  await store.patchLanguage(code, JSON.parse(text), { upsert: true });
  unsaved.value = false;
  await load();
}
</script>

<template>
  <div v-if="store.current">
    <h2 class="text-xl font-bold mb-2">{{ store.current.name }} ({{ store.current.code }})</h2>
    <div class="mb-2 space-x-2">
      <button class="border px-2 py-1" @click="exportJson">Export</button>
      <label class="border px-2 py-1 cursor-pointer">
        Import
        <input type="file" class="hidden" @change="importJson" />
      </label>
    </div>
    <EntityList :language="store.current" @change="markChanged" />
  </div>
</template>
