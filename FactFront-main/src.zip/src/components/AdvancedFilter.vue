<script setup lang="ts">
import { ref, computed, watch } from "vue";

import { v4 as uuidv4 } from "uuid";
import {
  Search,
  Filter,
  Save,
  Download,
  Trash2,
  Plus,
  X,
  ChevronDown,
  ChevronUp,
  BookmarkPlus,
  Bookmark,
  AlertCircle,
} from "lucide-vue-next";

interface FilterCondition {
  id: string;
  field: string;
  operator: string;
  value: any;
  logicalOperator?: "AND" | "OR";
}

interface FilterGroup {
  id: string;
  conditions: FilterCondition[];
  logicalOperator: "AND" | "OR";
}

interface SavedFilter {
  id: string;
  name: string;
  type: string;
  groups: FilterGroup[];
}

interface FilterField {
  name: string;
  label: string;
  type: "text" | "number" | "date" | "select" | "multiselect";
  operators: string[];
  options?: { label: string; value: any }[];
}

const props = defineProps<{
  type: "contracts" | "items" | "invoices" | "vessels" | "users" | "rates";
}>();

const emit = defineEmits<{
  (e: "filter", filters: FilterGroup[]): void;
}>();

// Filter fields configuration based on type
const filterFields = computed<Record<string, FilterField>>(() => {
  switch (props.type) {
    case "contracts":
      return {
        name: {
          name: "name",
          label: "Contract Name",
          type: "text",
          operators: ["contains", "equals", "starts_with", "ends_with"],
        },
        status: {
          name: "status",
          label: "Status",
          type: "select",
          operators: ["equals", "not_equals"],
          options: [
            { label: "Active", value: "Active" },
            { label: "Inactive", value: "Inactive" },
            { label: "Draft", value: "Draft" },
          ],
        },
        startDate: {
          name: "startDate",
          label: "Start Date",
          type: "date",
          operators: ["equals", "before", "after", "between"],
        },
        endDate: {
          name: "endDate",
          label: "End Date",
          type: "date",
          operators: ["equals", "before", "after", "between"],
        },
        contractValue: {
          name: "contractValue",
          label: "Contract Value",
          type: "number",
          operators: ["equals", "greater_than", "less_than", "between"],
        },
      };
    case "items":
      return {
        itemNumber: {
          name: "itemNumber",
          label: "Item Number",
          type: "text",
          operators: ["contains", "equals", "starts_with"],
        },
        itemType: {
          name: "itemType",
          label: "Item Type",
          type: "select",
          operators: ["equals", "not_equals"],
          options: [
            { label: "Container", value: "container" },
            { label: "Breakbulk", value: "breakbulk" },
            { label: "Vehicle", value: "vehicle" },
          ],
        },
        position: {
          name: "position",
          label: "Position",
          type: "text",
          operators: ["contains", "equals"],
        },
        ownerId: {
          name: "ownerId",
          label: "Owner ID",
          type: "text",
          operators: ["contains", "equals"],
        },
      };
    case "invoices":
      return {
        draftNumber: {
          name: "draftNumber",
          label: "Draft Number",
          type: "text",
          operators: ["contains", "equals", "starts_with"],
        },
        finalNumber: {
          name: "finalNumber",
          label: "Final Number",
          type: "text",
          operators: ["contains", "equals", "starts_with"],
        },
        status: {
          name: "status",
          label: "Status",
          type: "select",
          operators: ["equals", "not_equals"],
          options: [
            { label: "Draft", value: "DRAFT" },
            { label: "Final", value: "FINAL" },
            { label: "Cancelled", value: "CANCELLED" },
          ],
        },
        customerName: {
          name: "customerName",
          label: "Customer Name",
          type: "text",
          operators: ["contains", "equals"],
        },
        amount: {
          name: "amount",
          label: "Amount",
          type: "number",
          operators: ["equals", "greater_than", "less_than", "between"],
        },
        createdDate: {
          name: "createdDate",
          label: "Created Date",
          type: "date",
          operators: ["equals", "before", "after", "between"],
        },
      };
    case "vessels":
      return {
        vesselName: {
          name: "vesselName",
          label: "Vessel Name",
          type: "text",
          operators: ["contains", "equals", "starts_with"],
        },
        visitReference: {
          name: "visitReference",
          label: "Visit Reference",
          type: "text",
          operators: ["contains", "equals"],
        },
        phase: {
          name: "phase",
          label: "Phase",
          type: "select",
          operators: ["equals", "not_equals"],
          options: [
            { label: "Created", value: "Created" },
            { label: "Active", value: "Active" },
            { label: "Completed", value: "Completed" },
            { label: "Canceled", value: "Canceled" },
          ],
        },
        service: {
          name: "service",
          label: "Service",
          type: "text",
          operators: ["contains", "equals"],
        },
        eta: {
          name: "eta",
          label: "ETA",
          type: "date",
          operators: ["equals", "before", "after", "between"],
        },
        etd: {
          name: "etd",
          label: "ETD",
          type: "date",
          operators: ["equals", "before", "after", "between"],
        },
      };
    case "users":
      return {
        fullName: {
          name: "fullName",
          label: "Full Name",
          type: "text",
          operators: ["contains", "equals", "starts_with"],
        },
        companyName: {
          name: "companyName",
          label: "Company Name",
          type: "text",
          operators: ["contains", "equals"],
        },
        accessType: {
          name: "accessType",
          label: "Access Type",
          type: "select",
          operators: ["equals", "not_equals"],
          options: [
            { label: "View Only", value: "View Only" },
            { label: "Data Entry", value: "Data Entry" },
            { label: "Full Access", value: "Full Access" },
          ],
        },
        status: {
          name: "status",
          label: "Status",
          type: "select",
          operators: ["equals", "not_equals"],
          options: [
            { label: "Active", value: "Active" },
            { label: "Inactive", value: "Inactive" },
            { label: "Pending", value: "Pending" },
          ],
        },
        createdAt: {
          name: "createdAt",
          label: "Created Date",
          type: "date",
          operators: ["equals", "before", "after", "between"],
        },
        expiresAt: {
          name: "expiresAt",
          label: "Expiry Date",
          type: "date",
          operators: ["equals", "before", "after", "between"],
        },
      };
    case "rates":
      return {
        rateType: {
          name: "rateType",
          label: "Rate Type",
          type: "select",
          operators: ["equals", "not_equals"],
          options: [
            { label: "Quantity", value: "Quantity" },
            { label: "Date", value: "Date" },
          ],
        },
        amount: {
          name: "amount",
          label: "Amount",
          type: "number",
          operators: ["equals", "greater_than", "less_than", "between"],
        },
        currency: {
          name: "currency",
          label: "Currency",
          type: "select",
          operators: ["equals", "not_equals"],
          options: [
            { label: "USD", value: "USD" },
            { label: "EUR", value: "EUR" },
            { label: "GBP", value: "GBP" },
          ],
        },
        effectiveDate: {
          name: "effectiveDate",
          label: "Effective Date",
          type: "date",
          operators: ["equals", "before", "after", "between"],
        },
      };
    default:
      return {};
  }
});

const isExpanded = ref(false);
const filterGroups = ref<FilterGroup[]>([
  {
    id: uuidv4(),

    conditions: [],
    logicalOperator: "AND",
  },
]);
const savedFilters = ref<SavedFilter[]>([]);
const showSaveFilterModal = ref(false);
const newFilterName = ref("");
const activePreset = ref<string | null>(null);

const operatorLabels: Record<string, string> = {
  contains: "Contains",
  equals: "Equals",
  not_equals: "Not Equals",
  starts_with: "Starts With",
  ends_with: "Ends With",
  greater_than: "Greater Than",
  less_than: "Less Than",
  between: "Between",
  before: "Before",
  after: "After",
};

const addFilterGroup = () => {
  filterGroups.value.push({
    id: uuidv4(),
    conditions: [],
    logicalOperator: "AND",
  });
};

const addCondition = (groupId: string) => {
  const group = filterGroups.value.find((g) => g.id === groupId);
  if (group) {
    group.conditions.push({
      id: uuidv4(),
      field: Object.keys(filterFields.value)[0],
      operator: filterFields.value[Object.keys(filterFields.value)[0]].operators[0],
      value: "",
      logicalOperator: group.conditions.length > 0 ? "AND" : undefined,
    });
  }
};

const removeCondition = (groupId: string, conditionId: string) => {
  const group = filterGroups.value.find((g) => g.id === groupId);
  if (group) {
    group.conditions = group.conditions.filter((c) => c.id !== conditionId);
  }
};

const removeGroup = (groupId: string) => {
  filterGroups.value = filterGroups.value.filter((g) => g.id !== groupId);
};

const saveFilter = () => {
  if (!newFilterName.value) return;

  savedFilters.value.push({
    id: uuidv4(),
    name: newFilterName.value,
    type: props.type,
    groups: JSON.parse(JSON.stringify(filterGroups.value)),
  });

  showSaveFilterModal.value = false;
  newFilterName.value = "";
};

const loadFilter = (filter: SavedFilter) => {
  filterGroups.value = JSON.parse(JSON.stringify(filter.groups));
  activePreset.value = filter.id;
};

const deleteFilter = (filterId: string) => {
  savedFilters.value = savedFilters.value.filter((f) => f.id !== filterId);
  if (activePreset.value === filterId) {
    activePreset.value = null;
  }
};

const applyFilters = () => {
  emit("filter", filterGroups.value);
};

const clearFilters = () => {
  filterGroups.value = [
    {
      id: uuidv4(),
      conditions: [],
      logicalOperator: "AND",
    },
  ];
  activePreset.value = null;
  emit("filter", []);
};

watch(
  filterGroups,
  () => {
    if (activePreset.value) {
      const currentFilter = JSON.stringify(filterGroups.value);
      const savedFilter = savedFilters.value.find((f) => f.id === activePreset.value);
      if (savedFilter && JSON.stringify(savedFilter.groups) !== currentFilter) {
        activePreset.value = null;
      }
    }
  },
  { deep: true }
);
</script>

<template>
  <div class="bg-white shadow rounded-lg">
    <!-- Header -->
    <div class="px-4 py-3 border-b border-gray-200">
      <button
        @click="isExpanded = !isExpanded"
        class="flex items-center text-sm text-gray-700 hover:text-gray-900"
      >
        <Filter class="h-4 w-4 mr-2" />
        Advanced Filter
        <component :is="isExpanded ? ChevronUp : ChevronDown" class="h-4 w-4 ml-2" />
      </button>
    </div>

    <!-- Filter Content -->
    <div v-show="isExpanded" class="p-4">
      <!-- Saved Filters -->
      <div class="mb-4">
        <div class="flex justify-between items-center mb-2">
          <h3 class="text-sm font-medium text-gray-700">Saved Filters</h3>
          <button
            v-if="filterGroups[0].conditions.length > 0"
            @click="showSaveFilterModal = true"
            class="inline-flex items-center text-sm text-blue-600 hover:text-blue-800"
          >
            <BookmarkPlus class="h-4 w-4 mr-1" />
            Save Current
          </button>
        </div>
        <div class="space-y-2">
          <div v-if="savedFilters.length === 0" class="text-sm text-gray-500">
            No saved filters
          </div>
          <div
            v-for="filter in savedFilters"
            :key="filter.id"
            class="flex items-center justify-between p-2 bg-gray-50 rounded-md"
          >
            <button
              @click="loadFilter(filter)"
              :class="[
                'flex items-center text-sm',
                activePreset === filter.id
                  ? 'text-blue-600'
                  : 'text-gray-700 hover:text-gray-900',
              ]"
            >
              <Bookmark class="h-4 w-4 mr-2" />
              {{ filter.name }}
            </button>
            <button
              @click="deleteFilter(filter.id)"
              class="text-gray-400 hover:text-red-600"
            >
              <Trash2 class="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      <!-- Filter Groups -->
      <div class="space-y-4">
        <div
          v-for="group in filterGroups"
          :key="group.id"
          class="p-4 bg-gray-50 rounded-lg"
        >
          <!-- Group Header -->
          <div class="flex justify-between items-center mb-4">
            <div class="flex items-center space-x-4">
              <select
                v-model="group.logicalOperator"
                class="text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="AND">AND</option>
                <option value="OR">OR</option>
              </select>
              <button
                v-if="filterGroups.length > 1"
                @click="removeGroup(group.id)"
                class="text-red-600 hover:text-red-800"
              >
                <Trash2 class="h-4 w-4" />
              </button>
            </div>
          </div>

          <!-- Conditions -->
          <div class="space-y-4">
            <div
              v-for="condition in group.conditions"
              :key="condition.id"
              class="grid grid-cols-12 gap-4 items-start"
            >
              <!-- Logical Operator -->
              <div v-if="condition.logicalOperator" class="col-span-1">
                <select
                  v-model="condition.logicalOperator"
                  class="block w-full text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="AND">AND</option>
                  <option value="OR">OR</option>
                </select>
              </div>
              <div :class="condition.logicalOperator ? 'col-span-11' : 'col-span-12'">
                <div class="flex items-start space-x-4">
                  <!-- Field -->
                  <div class="w-1/4">
                    <select
                      v-model="condition.field"
                      class="block w-full text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option
                        v-for="(field, key) in filterFields"
                        :key="key"
                        :value="key"
                      >
                        {{ field.label }}
                      </option>
                    </select>
                  </div>

                  <!-- Operator -->
                  <div class="w-1/4">
                    <select
                      v-model="condition.operator"
                      class="block w-full text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option
                        v-for="operator in filterFields[condition.field].operators"
                        :key="operator"
                        :value="operator"
                      >
                        {{ operatorLabels[operator] }}
                      </option>
                    </select>
                  </div>

                  <!-- Value -->
                  <div class="flex-1">
                    <template v-if="filterFields[condition.field].type === 'select'">
                      <select
                        v-model="condition.value"
                        class="block w-full text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                      >
                        <option
                          v-for="option in filterFields[condition.field].options"
                          :key="option.value"
                          :value="option.value"
                        >
                          {{ option.label }}
                        </option>
                      </select>
                    </template>

                    <template
                      v-else-if="filterFields[condition.field].type === 'multiselect'"
                    >
                      <select
                        v-model="condition.value"
                        multiple
                        class="block w-full text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                      >
                        <option
                          v-for="option in filterFields[condition.field].options"
                          :key="option.value"
                          :value="option.value"
                        >
                          {{ option.label }}
                        </option>
                      </select>
                    </template>

                    <template v-else-if="filterFields[condition.field].type === 'date'">
                      <div class="flex space-x-2">
                        <input
                          v-model="condition.value"
                          type="date"
                          class="block w-full text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                        />
                        <input
                          v-if="condition.operator === 'between'"
                          v-model="condition.value2"
                          type="date"
                          class="block w-full text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                    </template>

                    <template v-else-if="filterFields[condition.field].type === 'number'">
                      <div class="flex space-x-2">
                        <input
                          v-model.number="condition.value"
                          type="number"
                          class="block w-full text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                        />
                        <input
                          v-if="condition.operator === 'between'"
                          v-model.number="condition.value2"
                          type="number"
                          class="block w-full text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                    </template>

                    <template v-else>
                      <input
                        v-model="condition.value"
                        type="text"
                        class="block w-full text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                      />
                    </template>
                  </div>

                  <!-- Remove Condition -->
                  <button
                    @click="removeCondition(group.id, condition.id)"
                    class="text-red-600 hover:text-red-800"
                  >
                    <Trash2 class="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>

            <!-- Add Condition -->
            <button
              @click="addCondition(group.id)"
              class="inline-flex items-center text-sm text-blue-600 hover:text-blue-800"
            >
              <Plus class="h-4 w-4 mr-1" />
              Add Condition
            </button>
          </div>
        </div>
      </div>

      <!-- Add Group -->
      <div class="mt-4">
        <button
          @click="addFilterGroup"
          class="inline-flex items-center text-sm text-blue-600 hover:text-blue-800"
        >
          <Plus class="h-4 w-4 mr-1" />
          Add Filter Group
        </button>
      </div>

      <!-- Actions -->
      <div class="mt-6 flex justify-end space-x-4">
        <button
          @click="clearFilters"
          class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
        >
          Clear
        </button>
        <button
          @click="applyFilters"
          class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          Apply Filters
        </button>
      </div>
    </div>

    <!-- Save Filter Modal -->
    <Teleport to="body">
      <div
        v-if="showSaveFilterModal"
        class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50"
      >
        <div class="bg-white rounded-lg p-6 max-w-md w-full">
          <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium text-gray-900">Save Filter</h3>
            <button
              @click="showSaveFilterModal = false"
              class="text-gray-400 hover:text-gray-500"
            >
              <X class="h-6 w-6" />
            </button>
          </div>

          <div class="space-y-4">
            <div>
              <label class="block text-sm font-medium text-gray-700"> Filter Name </label>
              <input
                v-model="newFilterName"
                type="text"
                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter a name for this filter"
              />
            </div>

            <div class="flex justify-end space-x-3">
              <button
                @click="showSaveFilterModal = false"
                class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                @click="saveFilter"
                class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>
