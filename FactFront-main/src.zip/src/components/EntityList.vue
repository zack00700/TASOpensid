<script setup lang="ts">
import { ref } from 'vue';
import type { Language, EntityDef, FieldDef } from '../types/i18nFields';
import { useI18nFieldsStore } from '../stores/i18nFieldsStore';
import FieldsTable from './FieldsTable.vue';

const props = defineProps<{ language: Language }>();
const emit = defineEmits<{ (e: 'change'): void }>();
const store = useI18nFieldsStore();

const showForm = ref(false);
const editing = ref<EntityDef | null>(null);
const tmp = ref<EntityDef>({ entity: '', name: '', fields: [] });

function openAdd() {
  editing.value = null;
  tmp.value = { entity: '', name: '', fields: [] };
  showForm.value = true;
}
function openEdit(ent: EntityDef) {
  editing.value = ent;
  tmp.value = { ...ent, fields: [...ent.fields] };
  showForm.value = true;
}
async function save() {
  await store.upsertEntity(props.language.code, tmp.value);
  showForm.value = false;
  emit('change');
}
async function remove(ent: EntityDef) {
  await store.deleteEntity(props.language.code, ent.entity);
  emit('change');
}
</script>

<template>
  <div>
    <div class="flex justify-between mb-2">
      <h3 class="font-semibold">Entities</h3>
      <button class="border px-2 py-1" @click="openAdd">Add Entity</button>
    </div>
    <ul>
      <li v-for="e in language.entities" :key="e.entity" class="mb-4 border p-2">
        <div class="flex justify-between mb-1">
          <strong>{{ e.entity }} - {{ e.name }}</strong>
          <div class="space-x-1">
            <button class="border px-2 py-1" @click="openEdit(e)">Edit</button>
            <button class="border px-2 py-1" @click="remove(e)">Delete</button>
          </div>
        </div>
        <FieldsTable :language-code="language.code" :entity="e" @change="emit('change')" />
      </li>
    </ul>

    <div v-if="showForm" class="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
      <div class="bg-white p-4 rounded w-80">
        <h4 class="font-bold mb-2">{{ editing ? 'Edit' : 'Add' }} Entity</h4>
        <div class="space-y-2">
          <label class="block">
            <span class="text-sm">Entity</span>
            <input v-model="tmp.entity" :disabled="!!editing" class="border p-1 w-full" />
          </label>
          <label class="block">
            <span class="text-sm">Name</span>
            <input v-model="tmp.name" class="border p-1 w-full" />
          </label>
        </div>
        <div class="mt-4 flex justify-end gap-2">
          <button class="px-3 py-1 border" @click="showForm=false">Cancel</button>
          <button class="px-3 py-1 bg-blue-500 text-white" @click="save">Save</button>
        </div>
      </div>
    </div>
  </div>
</template>
