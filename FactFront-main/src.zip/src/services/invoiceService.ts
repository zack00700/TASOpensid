import api from '../plugin/axios';
import { InvoiceLineDto } from '../types/invoice';
import { renderInvoiceLines } from '../utils/invoice-html';

export const generateDraft = async (blId: string, customerName: string): Promise<any> => {
  const encodedName = encodeURIComponent(customerName);
  const response = await api.post(`/invoice/bl/${blId}/draft/customer/${encodedName}`);
  return response.data;
};

export function getInvoicePreviewUrl(id: string): string {
  if (!id) {
    throw new Error('getInvoicePreviewUrl: invoiceId is required');
  }
  return `${window.location.origin}/api/invoice/${encodeURIComponent(id)}/html`;
}

export const fetchInvoiceHtml = async (invoiceId: string): Promise<string> => {
  if (!invoiceId) {
    throw new Error('fetchInvoiceHtml: invoiceId is required');
  }
  const response = await api.get(
    `invoice/${encodeURIComponent(invoiceId)}/html`,
    {
      responseType: 'text',
    }
  );
  return response.data;
};

export const finalize = async (invoiceId: string): Promise<any> => {
  if (!invoiceId) {
    throw new Error('finalize: invoiceId is required');
  }
  const response = await api.put(`/invoice/${encodeURIComponent(invoiceId)}/finalize`);
  return response.data;
};

const remove = async (invoiceId: string): Promise<void> => {
  if (!invoiceId) {
    throw new Error('delete: invoiceId is required');
  }
  await api.delete(`/invoice/${encodeURIComponent(invoiceId)}`);
};

/**
 * Build an HTML table for the provided invoice lines.  This mirrors the output
 * of the backend HTML preview and is primarily used in unit tests where the
 * real API is not available.
 */
export const buildInvoiceLinesHtml = (
  invoiceId: string,
  lines: InvoiceLineDto[],
  currency = 'USD'
): string => {
  return renderInvoiceLines(lines, { id: invoiceId, currency });
};

export default {
  generateDraft,
  getInvoicePreviewUrl,
  fetchInvoiceHtml,
  finalize,
  delete: remove,
  buildInvoiceLinesHtml,
};
