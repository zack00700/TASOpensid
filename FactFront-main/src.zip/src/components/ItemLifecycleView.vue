<script setup lang="ts">
import { ref, computed } from "vue";
import { Item, Lifecycle, Event } from "../types/item";
import { ItemService } from "../services/itemService";
import {
  Clock,
  Calendar,
  AlertCircle,
  ArrowDownCircle,
  ArrowUpCircle,
  CircleDot,
} from "lucide-vue-next";

interface EventConfig {
  id: string;
  name: string;
  eventType: "IN" | "OUT" | "INTERMEDIATE";
  billedEvent: boolean;
}

const props = defineProps<{
  item: Item;
}>();

const itemService = ItemService.getInstance();

// Sample events configuration (in a real app, this would be shared state or fetched from API)
const eventsConfig = ref<EventConfig[]>([
  {
    id: "1",
    name: "Container Gate In",
    eventType: "IN",
    billedEvent: true,
  },
  {
    id: "2",
    name: "Container Gate Out",
    eventType: "OUT",
    billedEvent: true,
  },
  {
    id: "3",
    name: "Container Yard Move",
    eventType: "INTERMEDIATE",
    billedEvent: false,
  },
]);

const activeLifecycle = computed(() => itemService.getActiveLifecycle(props.item));
const completedLifecycles = computed(() =>
  itemService.getCompletedLifecycles(props.item)
);

const formatDate = (date: string) => {
  return new Date(date).toLocaleString();
};

const formatDuration = (milliseconds: number) => {
  const seconds = Math.floor(milliseconds / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days}d ${hours % 24}h`;
  if (hours > 0) return `${hours}h ${minutes % 60}m`;
  return `${minutes}m`;
};

const getEventIcon = (type: string) => {
  switch (type) {
    case "IN":
      return ArrowDownCircle;
    case "OUT":
      return ArrowUpCircle;
    default:
      return CircleDot;
  }
};

const getEventName = (type: string) => {
  const event = eventsConfig.value.find((e) => e.eventType === type);
  return event?.name || type;
};

const getEventTypeClasses = (type: string) => {
  const baseClasses = "flex items-center space-x-1";
  switch (type) {
    case "IN":
      return `${baseClasses} text-green-600`;
    case "OUT":
      return `${baseClasses} text-red-600`;
    case "INTERMEDIATE":
      return `${baseClasses} text-blue-600`;
    default:
      return baseClasses;
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case "In Progress":
      return "text-blue-600";
    case "Completed":
      return "text-green-600";
    case "Cancelled":
      return "text-red-600";
    default:
      return "text-gray-600";
  }
};
</script>

<template>
  <div class="space-y-6">
    <!-- Active Lifecycle -->
    <div v-if="activeLifecycle" class="bg-white shadow rounded-lg p-6">
      <h3 class="text-lg font-medium text-gray-900 mb-4">Active Lifecycle</h3>
      <div class="space-y-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center space-x-2">
            <Clock class="h-5 w-5 text-blue-500" />
            <span class="text-sm text-gray-500">Started:</span>
            <span class="text-sm font-medium">{{
              formatDate(activeLifecycle.startTime)
            }}</span>
          </div>
          <span
            :class="[
              'px-2 py-1 text-xs font-medium rounded-full',
              getStatusColor(activeLifecycle.status),
            ]"
          >
            {{ activeLifecycle.status }}
          </span>
        </div>

        <!-- Timeline -->
        <div class="space-y-4 mt-4">
          <div
            v-for="event in activeLifecycle.events"
            :key="event.id"
            class="flex items-start space-x-3"
          >
            <div
              :class="[
                'flex-shrink-0 h-4 w-4 rounded-full mt-1',
                event.eventType === 'IN'
                  ? 'bg-green-500'
                  : event.type === 'OUT'
                  ? 'bg-red-500'
                  : 'bg-blue-500',
              ]"
            />
            <div class="flex-1">
              <div class="flex items-center justify-between">
                <div :class="getEventTypeClasses(event.type)">
                  <component :is="getEventIcon(event.type)" class="h-4 w-4" />
                  <span class="text-sm font-medium">{{ getEventName(event.type) }}</span>
                  <span v-if="event.location" class="text-sm text-gray-500 ml-2">
                    at {{ event.location }}
                  </span>
                </div>
                <span class="text-sm text-gray-500">
                  {{ formatDate(event.timestamp) }}
                </span>
              </div>
              <p v-if="event.notes" class="mt-1 text-sm text-gray-500">
                {{ event.notes }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Completed Lifecycles -->
    <div class="bg-white shadow rounded-lg p-6">
      <h3 class="text-lg font-medium text-gray-900 mb-4">Lifecycle History</h3>
      <div class="space-y-6">
        <div
          v-for="lifecycle in completedLifecycles"
          :key="lifecycle.id"
          class="border-b border-gray-200 pb-6 last:border-0 last:pb-0"
        >
          <div class="flex items-center justify-between mb-4">
            <div class="flex items-center space-x-2">
              <Calendar class="h-5 w-5 text-gray-400" />
              <span class="text-sm text-gray-500">
                {{ formatDate(lifecycle.startTime) }} -
                {{ formatDate(lifecycle.endTime!) }}
              </span>
            </div>
            <span
              :class="[
                'px-2 py-1 text-xs font-medium rounded-full',
                getStatusColor(lifecycle.status),
              ]"
            >
              {{ lifecycle.status }}
            </span>
          </div>

          <div class="text-sm text-gray-500 mb-4">
            Duration: {{ formatDuration(itemService.getLifecycleDuration(lifecycle)) }}
          </div>

          <!-- Events Timeline -->
          <div class="space-y-4">
            <div
              v-for="event in lifecycle.events"
              :key="event.id"
              class="flex items-start space-x-3"
            >
              <div
                :class="[
                  'flex-shrink-0 h-4 w-4 rounded-full mt-1',
                  event.type === 'IN'
                    ? 'bg-green-500'
                    : event.type === 'OUT'
                    ? 'bg-red-500'
                    : 'bg-blue-500',
                ]"
              />
              <div class="flex-1">
                <div class="flex items-center justify-between">
                  <div :class="getEventTypeClasses(event.type)">
                    <component :is="getEventIcon(event.type)" class="h-4 w-4" />
                    <span class="text-sm font-medium">{{
                      getEventName(event.type)
                    }}</span>
                    <span v-if="event.location" class="text-sm text-gray-500 ml-2">
                      at {{ event.location }}
                    </span>
                  </div>
                  <span class="text-sm text-gray-500">
                    {{ formatDate(event.timestamp) }}
                  </span>
                </div>
                <p v-if="event.notes" class="mt-1 text-sm text-gray-500">
                  {{ event.notes }}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Statistics -->
    <div class="bg-white shadow rounded-lg p-6">
      <h3 class="text-lg font-medium text-gray-900 mb-4">Lifecycle Statistics</h3>
      <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div class="bg-gray-50 p-4 rounded-lg">
          <div class="text-sm font-medium text-gray-500">Total Lifecycles</div>
          <div class="mt-1 text-2xl font-semibold text-gray-900">
            {{ props.item.lifeCycles.length }}
          </div>
        </div>
        <div class="bg-gray-50 p-4 rounded-lg">
          <div class="text-sm font-medium text-gray-500">Completed</div>
          <div class="mt-1 text-2xl font-semibold text-gray-900">
            {{ completedLifecycles.length }}
          </div>
        </div>
        <div class="bg-gray-50 p-4 rounded-lg">
          <div class="text-sm font-medium text-gray-500">Average Duration</div>
          <div class="mt-1 text-2xl font-semibold text-gray-900">
            {{ formatDuration(itemService.getAverageLifecycleDuration(props.item)) }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
```
