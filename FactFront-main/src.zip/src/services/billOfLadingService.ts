import api from '../plugin/axios';
import itemService from './itemService';

export interface Commodity {
  description: string;
  weightKg: number;
  volumeM3: number;
  packagesNumber: number;
  hazardous: boolean;
  hazardClass?: string;
  unNumber?: string;
}

export interface Item {
  id?: string;
  type: string;
  itemNumber: string;
  status: string;
}

export interface BillOfLading {
  id?: string;
  blNumber: string;
  status: string;
  shipper: string;
  consignee: string;
  notifyParty: string;
  transportType: string;
  vessel: string;
  voyage: string;
  portOfLoading: string;
  portOfDischarge: string;
  placeOfDelivery: string;
  driver: string;
  trainNumber: string;
  truckNumber: string;
  commodity: Commodity;
  items: Item[];
  transportSnapshot?: VesselSnapshot | null;
  createdAt?: string;
  updatedAt?: string;
}

export interface VesselSnapshot {
  id?: string;
  vesselName?: string;
  imo?: string;
  callSign?: string;
  voyageIn?: string;
  voyageOut?: string;
  operator?: string;
  port?: string;
  terminal?: string;
  berth?: string;
  eta?: string;
  etd?: string;
  ata?: string | null;
  atd?: string | null;
  capturedAt?: string;
}

export interface TransportUpdateRequest {
  type: 'VESSEL' | 'TRAIN' | 'TRUCK';
  vesselVisitId?: string;
}

export const updateTransport = async (
  bolId: string,
  data: TransportUpdateRequest,
): Promise<VesselSnapshot> => {
  const response = await api.put(`/billoflading/${bolId}/transport`, data);
  return response.data;
};

export const refreshTransport = async (bolId: string): Promise<VesselSnapshot> => {
  const response = await api.put(`/billoflading/${bolId}/transport/refresh`);
  return response.data;
};

export const mapVisitToSnapshot = (visit: any): VesselSnapshot => ({
  id: visit.id,
  vesselName: visit.vesselName,
  imo: visit.imo,
  callSign: visit.callSign,
  voyageIn: visit.voyageIn,
  voyageOut: visit.voyageOut,
  operator: visit.operator,
  port: visit.port,
  terminal: visit.terminal,
  berth: visit.berth,
  eta: visit.eta,
  etd: visit.etd,
  ata: visit.ata,
  atd: visit.atd,
  capturedAt: new Date().toISOString(),
});

export const list = async (): Promise<BillOfLading[]> => {
  const response = await api.get('/billoflading');
  const bills = await Promise.all(
    (response.data as any[]).map(async (bill: any) => {
      const itemIds: string[] = bill.itemIds || [];
      const items = await Promise.all(itemIds.map((id: string) => itemService.get(id)));
      return {
        ...bill,
        items,
      } as BillOfLading;
    }),
  );
  return bills;
};

export const create = async (
  data: Omit<BillOfLading, 'id' | 'createdAt' | 'updatedAt'>,
): Promise<BillOfLading> => {
  const payload = {
    ...data,
    items: data.items.map(({ type, itemNumber, status }) => ({
      type,
      itemNumber,
      status,
    })),
  };
  const response = await api.post('/billoflading', payload);
  return response.data;
};

export const update = async (
  id: string,
  data: Omit<BillOfLading, 'id' | 'createdAt' | 'updatedAt'>,
): Promise<BillOfLading> => {
  // Handle case where items might be undefined
  if (!data.items) {
    const response = await api.put(`/billoflading/${id}`, data);
    return response.data;
  }
  
  const items = await Promise.all(
    data.items.map(async ({ id: itemId, type, itemNumber, status }) => {
      if (!itemId) {
        const created = await itemService.create({
          type,
          itemNumber,
          status,
          billOfLadingId: id,
        });
        return {
          id: created.id,
          type,
          itemNumber,
          status,
        };
      }
      return { id: itemId, type, itemNumber, status };
    }),
  );
  const payload = { ...data, items };
  const response = await api.put(`/billoflading/${id}`, payload);
  return response.data;
};

export type ItemDiffPayload = {
  newItems: Array<Record<string, any>>;
  updatedItems: Array<{ id: string } & Record<string, any>>;
  removedItemIds: string[];
};

export const applyItemsDiff = async (
  billOfLadingId: string,
  payload: ItemDiffPayload,
): Promise<any> => {
  const response = await api.post(
    `/billoflading/${encodeURIComponent(billOfLadingId)}/items:apply-diff`,
    payload,
  );
  return response.data;
};

const remove = async (id: string): Promise<void> => {
  await api.delete(`/billoflading/${id}`);
};

export { remove as delete };

export default {
  list,
  create,
  update,
  delete: remove,
  updateTransport,
  refreshTransport,
  mapVisitToSnapshot,
  applyItemsDiff,
};

