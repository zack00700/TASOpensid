export type EventType = 'IN' | 'OUT' | 'INTERMEDIATE';

export interface EventConfig {
    id: string;
    eventName: string;
    eventType: EventType;
    billedEvent: boolean;
}
