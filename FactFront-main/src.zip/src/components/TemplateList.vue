<script setup lang="ts">
import { ref, onMounted } from 'vue';
import templateService, { InvoiceTemplate } from '../services/invoiceTemplateService';

const templates = ref<InvoiceTemplate[]>([]);
const loading = ref(false);

const emit = defineEmits<{ (e: 'edit', id?: string): void }>();

async function fetchTemplates() {
  loading.value = true;
  try {
    templates.value = await templateService.listTemplates();
  } finally {
    loading.value = false;
  }
}

function edit(t: InvoiceTemplate) {
  emit('edit', t.id);
}

function createNew() {
  emit('edit');
}

async function duplicate(t: InvoiceTemplate) {
  const data = await templateService.getTemplate(t.id!);
  delete (data as any).id;
  await templateService.createTemplate(data);
  await fetchTemplates();
}

async function toggleStatus(t: InvoiceTemplate) {
  const newStatus = t.status === 'archived' ? 'active' : 'archived';
  await templateService.updateTemplate(t.id!, { status: newStatus, name: t.name });
  await fetchTemplates();
}

onMounted(fetchTemplates);
</script>

<template>
  <div>
    <div class="flex justify-between items-center mb-4">
      <h2 class="text-xl font-bold">Invoice Templates</h2>
      <button class="bg-blue-500 text-white px-3 py-1" @click="createNew">New Template</button>
    </div>
    <div v-if="loading">Loading...</div>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div v-for="t in templates" :key="t.id" class="border p-2 rounded">
        <img v-if="t.thumbnailUrl" :src="t.thumbnailUrl" class="w-full h-32 object-cover mb-2" />
        <div class="font-semibold">{{ t.name }}</div>
        <div class="text-sm text-gray-500">{{ t.lastModified }}</div>
        <div class="text-sm text-gray-500" v-if="t.version">v{{ t.version }}</div>
        <div class="mt-2 flex gap-2 text-sm">
          <button class="text-blue-600" @click="edit(t)">Edit</button>
          <button class="text-green-600" @click="duplicate(t)">Duplicate</button>
          <button class="text-red-600" @click="toggleStatus(t)">
            {{ t.status === 'archived' ? 'Activate' : 'Archive' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
</style>
