
// Base Event Types
export type EventType = 'IN' | 'OUT' | 'INTERMEDIATE';
export type ItemStatus = 'Available' | 'In Use' | 'Maintenance' | 'Out of Service';
export type LifecycleStatus = 'In Progress' | 'Completed' | 'Cancelled';

export interface Event {
  id: string;
  timestamp?: string;
  eventType?: EventType;
  itemId?: string;
  lifecycleId?: string;
  location?: string;
  notes?: string;
  metadata?: Record<string, any>;
}

export interface Lifecycle {
  id?: string;
  itemId?: string;
  startTime?: string;
  endTime?: string;
  status?: LifecycleStatus;
  events?: Event[];
}

export interface Item {
  /*id: string;
  type: 'container' | 'breakbulk' | 'vehicle';
  status: ItemStatus;
  ownerCode: string;
  currentLifecycleId?: string;
  lifeCycles: Lifecycle[];*/
  id?: string;
  itemType?: string;
  itemNumber?: string;
  type?: string;
  ownerId?: string;
  position?: string;
  itemStatus?: string;
  lastInspectionDate?: Date;
  nextInspectionDate?: Date;
  notes: String;
  status: String;
  lifeCycles: Lifecycle[];
  relatedInvoiceId?: string | null;
}

export interface ItemFormData {
  _id?: string;
  itemNumber: string;
  itemType: string;
  type: string;
  ownerId: string;
  position: string;
  status: "Available" | "In Use" | "Maintenance" | "Out of Service";
  lastInspection: string;
  nextInspection: string;
  notes: string;
  lifeCycles: Lifecycle[];
}
